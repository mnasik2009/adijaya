<?php
require "config/mysql_mysqli.inc.php";
    $server = "localhost";
    $username = "u1735482_nasikin";
    $password = "nasikin20091980";
    $database = "u1735482_abadijaya";
    mysql_connect($server,$username,$password,$database);
    mysql_select_db($database);
?>
