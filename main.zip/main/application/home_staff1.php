<?php mysql_close();
	  include 'koneksi1.php';
	  ?>
		<a style='color:#000' href='index.php?view=cndi'>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="fa fa-id-card-o"></i></span>
                <div class="info-box-content">
                <?php

				        $piutang = mysql_fetch_array(mysql_query("SELECT SUM(nilai - bayar - reinv) AS total FROM invoice,postinv WHERE invoice.`noinvoice` = postinv.`noinv`
                    AND (postinv.nilai - postinv.bayar - postinv.reinv ) > 0
                    AND invoice.cabang='$_SESSION[cabang]'"));
                $piutang1 = mysql_fetch_array(mysql_query("SELECT SUM(nilai - bayar - reinv) AS total FROM invoice,postinv WHERE invoice.`noinvoice` = postinv.`noinv`
                    AND (postinv.nilai - postinv.bayar - postinv.reinv ) > 0 AND DATEDIFF(CURDATE(),tglinv) > 60
                    AND invoice.cabang='$_SESSION[cabang]'"));?>
                  <span class="info-box-number">Cuti</span>
                  <span class="info-box-text"><?php echo number_format($piutang[total]); ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            </a>

            <a style='color:#000' href='index.php?view=lhtg'>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-green"><i class="fa fa-info-circle"></i></span>
                <div class="info-box-content">
                <?php $hutang = mysql_fetch_array(mysql_query("SELECT SUM(hutang - bayar - hapus) AS total FROM bkk,hutang WHERE bkk.nobkk = hutang.nobkk
								AND (hutang - bayar - hapus ) > 0
								AND bkk.cabang='$_SESSION[cabang]'")); ?>
                  <span class="info-box-number">Leave App</span>
                  <span class="info-box-text"><?php echo number_format($hutang[total]); ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            </a>

            <a style='color:#000' href='index.php?view=cni'>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-yellow"><i class="fa fa-hospital-o"></i></span>
                <div class="info-box-content">
                <?php
				$tahun = date('Ym');
				$tahun1 = date('Ym')-1;
				$tahun2 = date('Ym')-2;
				$bulan = date('m');
				$bulan1 = date('m') - 1;
				$bulan2 = date('m') - 2;
				$upload1 = mysql_fetch_array(mysql_query("SELECT COUNT(nojoa) AS total FROM djoa WHERE MID(nojoa,5,6)='$tahun1' AND LEFT(nojoa,3)='$_SESSION[cabang]'  AND inv='N'"));
				$upload2 = mysql_fetch_array(mysql_query("SELECT COUNT(nojoa) AS total FROM djoa WHERE MID(nojoa,5,6)='$tahun2' AND LEFT(nojoa,3)='$_SESSION[cabang]'  AND inv='N'"));?>
                  <span class="info-box-number">Slip Gaji</span>
                  <span class="info-box-text"><?php echo $upload1[total];?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            </a>

            <a style='color:#000' href='index.php?view=muatan'>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-red"><i class="fa fa-ambulance"></i></span>
                <div class="info-box-content">
                <?php

				$bulan = date('Ym');
				$bulan1 = date('M');
				$tahun = date('Y');
				$jl20 = mysql_fetch_array(mysql_query("SELECT COUNT(nojoa) AS total20 FROM djoa WHERE MID(nojoa,5,6)='$bulan' AND size='20' AND LEFT(nojoa,3)='$_SESSION[cabang]'"));
				$jl40 = mysql_fetch_array(mysql_query("SELECT COUNT(nojoa) AS total40 FROM djoa WHERE MID(nojoa,5,6)='$bulan' AND size='40' AND LEFT(nojoa,3)='$_SESSION[cabang]'"));
				$tl20 = mysql_fetch_array(mysql_query("SELECT COUNT(nojoa) AS total20 FROM djoa WHERE MID(nojoa,5,4)='$tahun' AND size='20' AND LEFT(nojoa,3)='$_SESSION[cabang]'"));
				$tl40 = mysql_fetch_array(mysql_query("SELECT COUNT(nojoa) AS total40 FROM djoa WHERE MID(nojoa,5,4)='$tahun' AND size='40' AND LEFT(nojoa,3)='$_SESSION[cabang]'")); ?>

                  <span class="info-box-number">Kesehatan</span>
				  				<span class="info-box-text"><?php echo ' 20 : ';?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            </a>
