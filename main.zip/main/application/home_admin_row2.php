<section class="col-lg-6 connectedSortable">
    <?php include "laporan/mutasi/lapmutasi1.php"; ?>
</section><!-- /.Left col -->

<section class="col-lg-6 connectedSortable">
    <?php include "laporan/cuti/lapcuti1.php"; ?>
</section><!-- right col -->
