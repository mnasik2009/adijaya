<section class="col-lg-6 connectedSortable">
    <?php include "laporan/cndi/outall.php"; ?>
</section><!-- /.Left col -->

<section class="col-lg-6 connectedSortable">
    <?php include "home_grafik.php"; ?>
</section><!-- right col -->