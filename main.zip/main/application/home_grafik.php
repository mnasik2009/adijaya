<script type="text/javascript" src="plugins/jQuery/jquery.min.js"></script>
<script type="text/javascript">
    $(function () {
        $('#container').highcharts({
            data: {
                table: 'datatable'
            },
            chart: {
                type: 'column'
            },
            title: {
                text: ''
            },
            yAxis: {
                allowDecimals: false,
                title: {
                    text: ''
                }
            },
            tooltip: {
                formatter: function () {
                    return '<b>Cabang ' + this.series.name + '</b><br/>' +
                        'Nilai ' + this.point.y + ' (Rp)';
                }
            }
        });
    });
</script>

<div class="box box-success">
    <div class="box-header">
    <i class="fa fa-th-list"></i>
    <h3 class="box-title">Grafik Pendapatan vs Biaya</h3>
        <div class="box-tools pull-right">
           <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
            <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
        </div>
        </div>

<div class="box-body chat" id="chat-box">
    <script src="plugins/highchart/highcharts.js"></script>
    <script src="plugins/highchart/modules/data.js"></script>
    <script src="plugins/highchart/modules/exporting.js"></script>
    <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>

<table id="datatable" style='display:none'>
    <thead>
        <tr>
            <th></th>
            <th>Surabaya</th>
            <th>Balikpapan</th>
			<th>Samarinda</th>
        </tr>
    </thead>
    <tbody>
    <?php 
		$pen1 = mysql_fetch_array(mysql_query("SELECT SUM(nilai) AS total FROM detinv,invoice
						WHERE invoice.noinvoice = detinv.noinv
						AND YEAR(tglinv)='$tahun' AND cabang='SUB'")); 
		$pen2 = mysql_fetch_array(mysql_query("SELECT SUM(nilai) AS total FROM detinv,invoice
						WHERE invoice.noinvoice = detinv.noinv
						AND YEAR(tglinv)='$tahun' AND cabang='BPN'"));
		$pen3 = mysql_fetch_array(mysql_query("SELECT SUM(nilai) AS total FROM detinv,invoice
						WHERE invoice.noinvoice = detinv.noinv
						AND YEAR(tglinv)='$tahun' AND cabang='SRI'"));
		$subo = mysql_fetch_array(mysql_query("SELECT SUM(nilai*jumlah) AS total FROM dbkk,bkk
						WHERE bkk.nobkk = dbkk.nobkk
						AND YEAR(tgltrans)='$tahun' AND cabang='SUB'")); 
		$bpno = mysql_fetch_array(mysql_query("SELECT SUM(nilai*jumlah) AS total FROM dbkk,bkk
						WHERE bkk.nobkk = dbkk.nobkk
						AND YEAR(tgltrans)='$tahun' AND cabang='BPN'"));  
		$srio = mysql_fetch_array(mysql_query("SELECT SUM(nilai*jumlah) AS total FROM dbkk,bkk
						WHERE bkk.nobkk = dbkk.nobkk
						AND YEAR(tgltrans)='$tahun' AND cabang='SRI'"));
        $grafik = mysql_query("SELECT * FROM rb_psb_aktivasi GROUP BY proses ORDER BY waktu_input");
        //while ($r = mysql_fetch_array($grafik)){
            //$ale = tgl_grafik($r[tanggal]);
            //$siswa = mysql_num_rows(mysql_query("SELECT * FROM rb_psb_aktivasi where proses='0'"));
            //$guru = mysql_num_rows(mysql_query("SELECT * FROM rb_psb_aktivasi where proses='9'"));
            //$superuser = mysql_num_rows(mysql_query("SELECT * FROM rb_psb_aktivasi where proses='1'"));
            echo "<tr>
                    <th>Grafik</th>
                    <td>$pen1[total]</td>
                    <td>$pen2[total]</td>
                    <td>$pen3[total]</td>
                  </tr>";
			echo "<tr>
                    <th>Grafik</th>
                    <td>$subo[total]</td>
                    <td>$bpno[total]</td>
                    <td>$srio[total]</td>
                  </tr>";
        //}
    ?>
    </tbody>
</table>
</div><!-- /.chat -->
</div><!-- /.box (chat box) -->

