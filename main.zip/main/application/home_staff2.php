<section class="col-lg-6 connectedSortable">
    <?php include "home_quick_email.php"; ?>
</section><!-- /.Left col -->

<section class="col-lg-6 connectedSortable">
    <?php include "home_quick_email.php"; ?>
</section><!-- right col -->
