<?php
	  include '../konek.php';
	  ?>
		<a style='color:#000' href='index.php?view=karyawan'>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="fa fa-pie-chart"></i></span>
                <div class="info-box-content">
                <?php

				        $karyawan = mysql_fetch_array(mysql_query("SELECT count(no_id) as jumlah from karyawan_induk where aktif='Y'"));
                ?>
                  <span class="info-box-number">Stock</span>
                  <span class="info-box-text"><?php echo $karyawan['jumlah']; ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            </a>

            <a style='color:#000' href='index.php?view=lapmutasi'>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-green"><i class="fa fa-arrow-circle-down"></i></span>
                <div class="info-box-content">
                <?php
								$tahun = date('Y');
								$hutang = mysql_num_rows(mysql_query("SELECT * from karyawan_mut WHERE year(tgl_mutasi)='$tahun'")); ?>
                  <span class="info-box-number">Order In</span>
                  <span class="info-box-text"><?php echo $hutang; ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            </a>

            <a style='color:#000' href='index.php?view=lapcuti'>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-yellow"><i class="fa fa-arrow-circle-up"></i></span>
                <div class="info-box-content">
                <?php
				$tahun = date('Y');
				$upload1 = mysql_num_rows(mysql_query("SELECT * from cuti where cek='Y' and year(tglmulai)='$tahun' and realisasi='0000-00-00'"));
				?>
                  <span class="info-box-number">Order Out</span>
                  <span class="info-box-text"><?php echo $upload1; ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            </a>

            <a style='color:#000' href='index.php?view=muatan'>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-red"><i class="fa fa-chrome"></i></span>
                <div class="info-box-content">
                <?php

				$sma = mysql_num_rows(mysql_query("SELECT * from karyawan_induk where pendidikan='SMU'"));
				$s1 = mysql_num_rows(mysql_query("SELECT * from karyawan_induk where pendidikan='S1'"));
				$s2 = mysql_num_rows(mysql_query("SELECT * from karyawan_induk where pendidikan='S2'"));?>

                  <span class="info-box-number">Pending</span>
				  				<span class="info-box-text"><?php echo ' 18 '; ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            </a>
