<section class="col-lg-12 connectedSortable">
    <?php include "laporan/idle/idle_vendor.php"; ?>
</section><!-- /.Left col -->
