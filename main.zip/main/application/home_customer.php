<?php mysql_close();
	  include 'koneksi1.php';
	  ?>
		<a style='color:#000' href='#'>
            <div class="col-md-6 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="fa fa-money"></i></span>
                <div class="info-box-content">
                <?php

				        $piutang = mysql_fetch_array(mysql_query("SELECT bkk.*, SUM(dbkk.nilai) AS total FROM bkk,dbkk,hutang WHERE bkk.nobkk = dbkk.nobkk
                          AND bkk.nobkk = hutang.nobkk
                          AND dbkk.vendor = 'MNL001'
                          AND (hutang - bayar - hapus ) > 0"));?>
                  <span class="info-box-text">Piutang</span>
                  <span class="info-box-number"><?php echo number_format($piutang[total]); ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            </a>

            <a style='color:#000' href='#'>
            <div class="col-md-6 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-green"><i class="fa fa-toggle-on"></i></span>
                <div class="info-box-content">
                <?php
                  $hutang = mysql_fetch_array(mysql_query("select count(nocontainer) as total from cont_history where tgltiba<>'' and tglbongkar='' and userid='$_SESSION[username]'"));?>

                  <span class="info-box-text">Not Delivered</span>
                  <span class="info-box-number"><?php echo number_format($hutang[total]); ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            </a>
