<?php
session_start();
include '../../koneksi.php';

$userid = $_SESSION['username'];
$cabang = $_SESSION['cabang'];
$tgltrans = date('Y-m-d',strtotime($_POST['tgltrans']));
$notrans = $_POST['notrans'];
$kodecust = $_POST['kodecust'];
$shipment = date('Y-m-d',strtotime($_POST['shipment']));
$jenisbbm = $_POST['jenisbbm'];
$uom = $_POST['uom'];
$harga = $_POST['harga'];
$oat = $_POST['oat'];
$ppn = $_POST['ppn'];
$pbbkb = $_POST['pbbkb'];
$top = $_POST['top'];
$cofrom = $_POST['cofrom'];
$lokasi = $_POST['lokasi'];
$pocust = $_POST['pocust'];
$spoint = $_POST['spoint'];
$nilai = $_POST['jumlah'] * $_POST['harga'];
$ppn = ($_POST['ppn'] * $nilai ) / 100;
$oat = $_POST['oat'] * $_POST['jumlah'];
$pbbkb = ($_POST['pbbkb'] * $nilai ) / 100;
$total = $nilai + $ppn + $pbbkb + $oat;
$duedate = date('Y-m-d',strtotime($_POST['duedate']));
$bulan = date('m',strtotime($_POST['tgltrans']));
$tahun = date('Y',strtotime($_POST['tgltrans']));
if ($cofrom == 'AJ0001'){
	$kode = 'ABJ';
}else{
	$kode = 'PAJ';
}
if ($bulan == 1) {
	$roma = 'I';
}else if ($bulan == 2) {
	$roma = 'II';
}else if ($bulan == 3) {
	$roma = 'III';
}else if ($bulan == 4) {
	$roma = 'IV';
}else if ($bulan == 5) {
	$roma = 'V';
}else if ($bulan == 6) {
	$roma = 'VI';
}else if ($bulan == 7) {
	$roma = 'VII';
}else if ($bulan == 8) {
	$roma = 'VIII';
}else if ($bulan == 9) {
	$roma = 'IX';
}else if ($bulan == 10) {
	$roma = 'X';
}else if ($bulan == 11) {
	$roma = 'XI';
}else if ($bulan == 12) {
	$roma = 'XII';
}
$nomor = mysql_query("select max(substr(notrans,1,6)) as noref from p_invoice where year(tgltrans)='$tahun' and cabang='$cabang'");

$data1 = mysql_fetch_array($nomor);
$idMax = $data1['noref'];
$idMax++;
$newID = sprintf('%06d',$idMax).'/INV/'.$kode.'-SMD/'.$roma.'/'.$tahun;
$tglinput = date('Y-m-d');

$row = mysql_num_rows(mysql_query("SELECT * FROM p_invoice WHERE notrans='$notrans'"));
if($row>0){
	$text = "UPDATE p_invoice SET tgltrans='$tgltrans',
	 							kodecust='$kodecust',
								shipment = '$shipment',
								jenisbbm='$jenisbbm',
								jumlah = '$jumlah',
								harga='$harga',
								uom='$uom',
								ppn='$ppn',
								pbbkb='$pbbkb',
								oat = '$oat',
								top = '$top',
								cofrom = '$cofrom',
								lokasi='$lokasi',
								pocust='$pocust',
								duedate = '$duedate',
								tglinput = '$tglinput',
								noso = '$noso',
								total = '$total',
								userid = '$userid'
			WHERE notrans='$notrans'";
	mysql_query($text);
	echo "Update Sukses $notrans";
}else{
	$text = "INSERT INTO p_invoice SET notrans='$newID',
								tgltrans='$tgltrans',
								kodecust='$kodecust',
								shipment = '$shipment',
								jenisbbm='$jenisbbm',
								jumlah = '$jumlah',
								harga='$harga',
								uom='$uom',
								ppn='$ppn',
								pbbkb='$pbbkb',
								oat = '$oat',
								top = '$top',
								cofrom = '$cofrom',
								lokasi='$lokasi',
								pocust='$pocust',
								duedate = '$duedate',
								tglinput = '$tglinput',
								noso = '$noso',
								total = '$total',
								userid = '$userid'";
	mysql_query($text);
	echo "Simpan Sukses $newID";
}
?>
