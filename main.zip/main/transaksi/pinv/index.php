<script type="text/javascript">
var url;
function create(){
	$('#dialog-form').dialog('open').dialog('setTitle','Tambah Data');
	$('#form').form('clear');
}
function save(){
	var notrans = $("#notrans").val();
	var string = $("#form").serialize();
	if(tgltrans.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, notrans tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#notrans").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/pinv/simpan.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function savekirim(){
	var notrans = $("#notrans").val();
	var string = $("#form-kirim").serialize();
	$.ajax({
		type	: "POST",
		url		: "transaksi/pinv/kirim.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}


function hapus(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row){
		$.messager.confirm('Confirm','Apakah Anda akan menghapus data ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/pinv/hapus.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}
}

function approve(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.approval == 'N'){
		$.messager.confirm('Confirm','Apakah Approve penawaran ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/pinv/approve.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dihapus, krn sudah di Approve',
		timeout:2000,
		showType:'slide'
	});
	}
}

function update(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-form').dialog('open').dialog('setTitle','Edit Data');
		$('#form').form('load',row);
	}
}

function cetak(){
	var row = $('#datagrid-crud').datagrid('getSelected');
		$('#dialog-excel').dialog('open').dialog('setTitle','Cetak Data');
		$('#form-excel').form('load',row);

}

function kirim(){
	var row = $('#datagrid-crud').datagrid('getSelected');
		$('#dialog-kirim').dialog('open').dialog('setTitle','Kirim dan Terima');
		$('#form-kirim').form('load',row);

}

function fresh(){
	$('#datagrid-crud').datagrid('reload');
}
function doSearch(value){
	$('#datagrid-crud').datagrid('load',{
        cari: value
    });
}

$(function(){
    $('#kodecust').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_cust.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
					{field:'nohp',title:'nohp'},
			    ]],onClickRow:function(rowData){
			                 var val =$('#kodesupp').combogrid('grid').datagrid('getSelected');
											 $('#kodesupp').textbox('setValue', val.kode);
			                                }
						});
	$('#jenisbbm').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_bbm.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'keterangan',title:'keterangan'},
		    ]],onClickRow:function(rowData){
		                 var val =$('#jenisbbm').combogrid('grid').datagrid('getSelected');
										 $('#jenisbbm').textbox('setValue', val.kode);
		             }
			});
	$('#cofrom').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_pt.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    columns:[[
		    {field:'kode',title:'kode'},
		    {field:'nama',title:'nama'},
		    {field:'alamat',title:'alamat'},
				{field:'kota',title:'kota'},
	    ]],onClickRow:function(rowData){
	                var val =$('#cofrom').combogrid('grid').datagrid('getSelected');
								 $('#cofrom').textbox('setValue', val.kode);
	          }
				});
  $('#spoint').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_spoint.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    	columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
					{field:'pic',title:'pic'},
	    ]],onClickRow:function(rowData){
	              var val =$('#spoint').combogrid('grid').datagrid('getSelected');
								 $('#spoint').textbox('setValue', val.kode);
	          }
			});
	$('#noso').combogrid({
		panelWidth:400,
		url: 'transaksi/_get/get_noso.php?',
		idField:'notrans',
		textField:'notrans',
		mode:'remote',
		fitColumns:true,
		columns:[[
			{field:'notrans',title:'notrans'},
			{field:'tgltrans',title:'tgltrans'},
			{field:'kodecust',title:'kodecust'},
			{field:'jenisbbm',title:'jenisbbm'},
			{field:'harga',title:'harga'},
			{field:'ppn',title:'ppn'},
			{field:'pbbkb',title:'pbbkb'},
			{field:'top',title:'top'},
			{field:'oat',title:'oat'},
			{field:'cofrom',title:'cofrom'},
			{field:'nodo',title:'nodo'},
			{field:'lewat',title:'lewat'},
			{field:'angkutan',title:'angkutan'},
			{field:'shipment',title:'shipment'},
			]],onClickRow:function(rowData){
							var val =$('#noso').combogrid('grid').datagrid('getSelected');
							$('#noso').textbox('setValue', val.notrans);
							$('#kodecust').textbox('setValue', val.kodecust);
							$('#jenisbbm').textbox('setValue', val.jenisbbm);
							$('#harga').textbox('setValue', val.harga);
							$('#ppn').textbox('setValue', val.ppn);
							$('#pbbkb').textbox('setValue', val.pbbkb);
							$('#top').textbox('setValue', val.top);
							$('#oat').textbox('setValue', val.oat);
							$('#cofrom').textbox('setValue',val.cofrom);
							$('#validto').textbox('setValue',val.validto);
							$('#uom').textbox('setValue','Liter');
							$('#lewat').textbox('setValue',val.lewat);
							$('#angkutan').textbox('setValue',val.angkutan);
							$('#shipment').textbox('setValue',val.shipment);
				}
			});
	});
</script>
</head>
<body>

	<div style="margin:10px 0;"></div>

	<table id="datagrid-crud" title="Proforma Invoice" class="easyui-datagrid" style="width:auto; height: auto;" url="transaksi/pinv/json.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
            <th data-options="field:'notrans'" sortable="true">No Trans </th>
            <th data-options="field:'kodecust'" sortable="true">Customer </th>
            <th data-options="field:'tgltrans'">Tanggal</th>
            <th data-options="field:'shipment'">Berlaku</th>
            <th data-options="field:'jenisbbm'">BBM</th>
						<th data-options="field:'uom'">UOM</th>
						<th data-options="field:'harga'">Harga</th>
						<th data-options="field:'ppn'">PPN</th>
						<th data-options="field:'pbbkb'">PBBKB</th>
						<th data-options="field:'oat'">OAT</th>
						<th data-options="field:'top'">TOP</th>
            <th data-options="field:'cofrom'">CO From</th>
						<th data-options="field:'lokasi'">Job SIte</th>
						<th data-options="field:'pocust'">PO# Customer</th>
						<!--th data-options="field:'tglkirim'">Tgl Kirim</th>
						<th data-options="field:'ekspedisi'">Ekspedisi</th>
						<th data-options="field:'noresi'">No Resi</th>
						<th data-options="field:'tglterima'">Tgl Terima</th-->
        </tr>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px;">
		<div style="float:left;">
			<!--a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-plus-square-o fa-lg" plain="true" onclick="create()">Tambah</a-->
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-pencil-square-o fa-lg" plain="true" onclick="update()">Edit</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-minus-square-o fa-lg" plain="true" onclick="hapus()">Hapus</a>
			<!--a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-check fa-lg" plain="true" onclick="approve()">Approval</a-->
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" plain="true" onclick="cetak()">Print</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-external-link fa-lg" plain="true" onclick="kirim()">Kirim</a>
      <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-refresh fa-lg" plain="true" onclick="fresh()">Refresh</a>
		</div>
		<div style="float:right;">
        	Pencarian <input id="cari" class="easyui-searchbox" data-options="prompt:'Cari notrans / kodesupp..',searcher:doSearch" style="width:200px"></input>
		</div>
	</div>

<!-- Dialog Form -->
<div id="dialog-form" class="easyui-dialog" style="width:600px; height:650px; padding: 10px 20px" closed="true" buttons="#dialog-buttons">
	<form id="form" method="post" novalidate>
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No SO</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="noso" id="noso" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Supplier &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Shipment Date</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="shipment" id="shipment" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="validto">Jenis BBM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; UOM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Harga</label><br />
			<input type="text" name="jenisbbm" id="jenisbbm" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="uom" id="uom" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="harga" id="harga" class="easyui-textbox" required="true" style="width:38%"/>
		</div>
		<div class="form-item">
			<label for="jenisbbm">PPN (%) &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PBBKB (%)&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; OAT</label><br />
			<input type="text" name="ppn" id="ppn" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="pbbkb" id="pbbkb" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="oat" id="oat" class="easyui-textbox" required="true" style="width:38%"/>
		</div>
		<div class="form-item">
			<label for="top">Term Of payment</label><br />
			<input type="text" name="top" id="top" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
    <div class="form-item">
			<label for="cofrom">CO From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="lokasi">PO# Customer</label><br />
			<input type="text" name="pocust" id="pocust" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="lewat">Jobsite</label><br />
			<input type="text" name="lokasi" id="lokasi" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="lewat">Due Date &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="duedate" id="duedate" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="dialog-buttons">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" onclick="save()">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-form').dialog('close')">Batal</a>
</div>


<!-- Pencetakan ke Printer -->
<div id="dialog-excel" class="easyui-dialog" style="width:500px; height:300px; padding: 10px 20px" closed="true" buttons="#dialog-btn">
	<form id="form-excel" method="post" action="transaksi/pinv/cetak.php" target="_blank">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Customer &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Due Date</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="duedate" id="duedate" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="cofrom">CO From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="dialog-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" onclick="$('#form-excel').submit();">Cetak</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-excel').dialog('close')">Batal</a>
</div>

<!-- Pegiriman Invoice ke Customer -->
<div id="dialog-kirim" class="easyui-dialog" style="width:500px; height:300px; padding: 10px 20px" closed="true" buttons="#kirim-btn">
	<form id="form-kirim" method="post">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:49%"/>

		</div>
		<div class="form-item">
			<label for="tglkirim">Ekspedisi &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Tgl Kirim</label><br />
			<input type="text" name="ekspedisi" id="ekspedisi" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="tglkirim" id="tglkirim" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="noresi">No Resi Ekspedisi &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Tgl Terima</label></br>
			<input type="text" name="noresi" id="noresi" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="tglterima" id="tglterima" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="kirim-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" onclick="savekirim();">Cetak</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-kirim').dialog('close')">Batal</a>
</div>
</body>
