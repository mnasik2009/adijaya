<?php
include '../../koneksi.php';
$notrans = $_POST['id'];
$row = mysql_num_rows(mysql_query("SELECT * FROM qtn_master WHERE notrans='$notrans'"));
if($row>0){
	$text = "update qtn_master set approval='Y'
			WHERE notrans='$notrans'";
	mysql_query($text);
	echo "Approval Sukses $notrans";
}else{
	echo "Tidak ada data yang dihapus $notrans";
}
?>
