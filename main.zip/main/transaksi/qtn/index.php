<script type="text/javascript">
var url;
function create(){
	$('#dialog-form').dialog('open').dialog('setTitle','Tambah Data');
	$('#form').form('clear');
}
function save(){
	var notrans = $("#notrans").val();
	var string = $("#form").serialize();
	if(tgltrans.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, notrans tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#notrans").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/qtn/simpan.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}
function hapus(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.approval == 'N'){
		$.messager.confirm('Confirm','Apakah Anda akan menghapus data ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/qtn/hapus.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dihapus, krn sudah di Approve',
		timeout:2000,
		showType:'slide'
	});
	}
}

function approve(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.approval == 'N'){
		$.messager.confirm('Confirm','Apakah Approve penawaran ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/qtn/approve.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dihapus, krn sudah di Approve',
		timeout:2000,
		showType:'slide'
	});
	}
}

function update(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-form').dialog('open').dialog('setTitle','Edit Data');
		$('#form').form('load',row);
	}
}

function lihat(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-lihat').dialog('open').dialog('setTitle','Lihat Data');
		$('#form-lihat').form('load',row);
	}
}

function cetak(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row.approval == 'Y'){
		$('#dialog-excel').dialog('open').dialog('setTitle','Cetak Data');
		$('#form-excel').form('load',row);
	}else{
				$.messager.show({
				title:'Info',
				msg:'Data tidak bisa di Cetak, krn karena belum di Approve',
				timeout:2000,
				showType:'slide'
			});
	}
}

function fresh(){
	$('#datagrid-crud').datagrid('reload');
}
function doSearch(value){
	$('#datagrid-crud').datagrid('load',{
        cari: value
    });
}

$(function(){
    $('#kodecust').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_cust.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
					{field:'nohp',title:'nohp'},
			    ]],onClickRow:function(rowData){
			                 var val =$('#kodecust').combogrid('grid').datagrid('getSelected');
											 $('#kodecust').textbox('setValue', val.kode);
			                                }
						});
	$('#lokasi').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_lok.php?',
			idField:'nama',
			textField:'nama',
			mode:'remote',
			fitColumns:true,
					columns:[[
					{field:'kode',title:'kode'},
					{field:'nama',title:'nama'},
					{field:'alamat',title:'alamat'},
					{field:'nohp',title:'nohp'},
				]],onClickRow:function(rowData){
							    var val =$('#lokasi').combogrid('grid').datagrid('getSelected');
									$('#lokasi').textbox('setValue', val.nama);
							                                }
										});
		$('#jenisbbm').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_bbm.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'keterangan',title:'keterangan'},
		    ]],onClickRow:function(rowData){
		                 var val =$('#jenisbbm').combogrid('grid').datagrid('getSelected');
										 $('#jenisbbm').textbox('setValue', val.kode);
		             }
			});
	$('#cofrom').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_pt.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    columns:[[
		    {field:'kode',title:'kode'},
		    {field:'nama',title:'nama'},
		    {field:'alamat',title:'alamat'},
				{field:'kota',title:'kota'},
	    ]],onClickRow:function(rowData){
	                var val =$('#cofrom').combogrid('grid').datagrid('getSelected');
								 $('#cofrom').textbox('setValue', val.kode);
	          }
				});
  $('#spoint').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_spoint.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
					{field:'pic',title:'pic'},
	    ]],onClickRow:function(rowData){
	              var val =$('#spoint').combogrid('grid').datagrid('getSelected');
								 $('#spoint').textbox('setValue', val.kode);
	          }
			});
   $('#top').combogrid({
		 panelWidth:400,
		 url: 'transaksi/_get/get_top.php?',
		 idField:'kode',
		 textField:'kode',
		 mode:'remote',
	   fitColumns:true,
		 columns:[[
		    {field:'kode',title:'kode'},
		    {field:'nama',title:'nama'},
		   ]],onClickRow:function(rowData){
		            var val =$('#top').combogrid('grid').datagrid('getSelected');
								 $('#top').textbox('setValue', val.kode);
		         }
		});
	});
</script>
</head>
<body>

	<div style="margin:10px 0;"></div>

	<table id="datagrid-crud" title="Penawaran Harga" class="easyui-datagrid" style="width:auto; height: auto;" url="transaksi/qtn/json.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
            <th data-options="field:'notrans'" sortable="true">No Trans </th>
            <th data-options="field:'kodecust'" sortable="true">Customer </th>
						<th data-options="field:'namacust'" sortable="true">Nama Cust</th>
            <th data-options="field:'tgltrans'">Tanggal</th>
            <th data-options="field:'validto'">Berlaku</th>
            <th data-options="field:'jenisbbm'">BBM</th>
						<th data-options="field:'uom'">UOM</th>
						<th data-options="field:'harga'">Harga</th>
						<th data-options="field:'ppn'">PPN</th>
						<th data-options="field:'pbbkb'">PBBKB</th>
						<th data-options="field:'oat'">OAT</th>
						<th data-options="field:'ppnoat'">PPN OAT</th>
						<th data-options="field:'top'">TOP</th>
            <th data-options="field:'approval'">Approval</th>
            <th data-options="field:'cofrom'">CO From</th>
						<th data-options="field:'spoint'">Supply Point</th>
						<th data-options="field:'angkaloses'">Loses</th>
						<th data-options="field:'cp'">CP</th>
						<th data-options="field:'nohp'">No HP</th>
						<th data-options="field:'biayakirim'">Biaya Kirim</th>
						<th data-options="field:'toup'" hidden="true"></th>
						<th data-options="field:'toemail'" hidden="true"></th>
        </tr>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px;">
		<div style="float:left;">
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-plus-square-o fa-lg" plain="true" onclick="create()">Tambah</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-pencil-square-o fa-lg" plain="true" onclick="update()">Edit</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-minus-square-o fa-lg" plain="true" onclick="hapus()">Hapus</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-check fa-lg" plain="true" onclick="approve()">Approval</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-newspaper-o fa-lg" plain="true" onclick="lihat()">View</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" plain="true" onclick="cetak()">Print</a>
      <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-refresh fa-lg" plain="true" onclick="fresh()">Refresh</a>
		</div>
		<div style="float:right;">
        	Pencarian <input id="cari" class="easyui-searchbox" data-options="prompt:'Cari notrans / kodecust..',searcher:doSearch" style="width:200px"></input>
		</div>
	</div>

<!-- Dialog Form -->
<div id="dialog-form" class="easyui-dialog" style="width:600px; height:650px; padding: 10px 20px" closed="true" buttons="#dialog-buttons">
	<form id="form" method="post" novalidate>
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Customer &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Valid To</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="validto" id="validto" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="validto">Jenis BBM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; UOM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Harga</label><br />
			<input type="text" name="jenisbbm" id="jenisbbm" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="uom" id="uom" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="harga" id="harga" class="easyui-textbox" required="true" style="width:38%"/>
		</div>
		<div class="form-item">
			<label for="jenisbbm">PPN (%) &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PBBKB (%)&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; OAT&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; PPN OAT</label><br />
			<input type="text" name="ppn" id="ppn" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="pbbkb" id="pbbkb" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="oat" id="oat" class="easyui-textbox" required="true" style="width:20%"/>
			<input type="text" name="ppnoat" id="ppnoat" class="easyui-textbox" required="true" style="width:18%"/>
		</div>
		<div class="form-item">
			<label for="top">Term Of payment &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; CO From </label><br />
			<input type="text" name="top" id="top" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:49%"/>
		</div>
		<div class="form-item">
			<label for="lokasi">Site / Lokasi &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Via / Lewat</label><br />
			<input type="text" name="lokasi" id="lokasi" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="lewat" id="lewat" class="easyui-textbox" required="true" style="width:49%"/>
		</div>
		<div class="form-item">
			<label for="lewat">Supply Point</label><br />
			<input type="text" name="spoint" id="spoint" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="lokasi">Contact Person &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No HP</label><br />
			<input type="text" name="cp" id="cp" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="nohp" id="nohp" class="easyui-textbox" required="true" style="width:49%"/>
		</div>
		<div class="form-item">
			<label for="lokasi">Angka Loses &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Biaya Pengiriman</label><br />
			<input type="text" name="angkaloses" id="angkaloses" class="easyui-textbox" required="true" style="width:50%"/>
			<select type="text" name="biayakirim" id="biayakirim" class="easyui-combobox" required="true" style="width:49%"/>
				<option value=""></option>
				<option value="Tidak Termasuk">Tidak Termasuk</option>
				<option value="Sudah Termasuk">Sudah Termasuk</option></select>
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="dialog-buttons">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" onclick="save()">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-form').dialog('close')">Batal</a>
</div>

<!-- Dialog Lihat -->
<div id="dialog-lihat" class="easyui-dialog" style="width:600px; height:570px; padding: 10px 20px" closed="true" buttons="#btn-lihat">
	<form id="form-lihat" method="post" novalidate>
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%" disabled="disabled"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%" disabled="disabled"/>

		</div>
		<div class="form-item">
			<label for="kodecust">Customer</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:30%" disabled="disabled"/>
			<input type="text" name="namacust" id="namacust" class="easyui-textbox" required="true" style="width:69%" disabled="disabled"/>
		</div>
		<div class="form-item">
			<label for="validto">Jenis BBM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; UOM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Harga</label><br />
			<input type="text" name="jenisbbm" id="jenisbbm" class="easyui-textbox" required="true" style="width:30%" disabled="disabled"/>
			<input type="text" name="uom" id="uom" class="easyui-textbox" required="true" style="width:30%" disabled="disabled"/>
			<input type="text" name="harga" id="harga" class="easyui-textbox" required="true" style="width:38%" disabled="disabled"/>
		</div>
		<div class="form-item">
			<label for="jenisbbm">PPN (%) &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PBBKB (%)&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; OAT&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; PPN OAT</label><br />
			<input type="text" name="ppn" id="ppn" class="easyui-textbox" required="true" style="width:30%" disabled="disabled"/>
			<input type="text" name="pbbkb" id="pbbkb" class="easyui-textbox" required="true" style="width:30%" disabled="disabled"/>
			<input type="text" name="oat" id="oat" class="easyui-textbox" required="true" style="width:20%" disabled="disabled"/>
			<input type="text" name="ppnoat" id="ppnoat" class="easyui-textbox" required="true" style="width:18%" disabled="disabled"/>
		</div>
		<div class="form-item">
			<label for="top">Term Of payment </label><br />
			<input type="text" name="top" id="top" class="easyui-textbox" required="true" style="width:100%" disabled="disabled"/>
			<!--input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:49%"/-->
		</div>
		<div class="form-item">
			<label for="lokasi">Site / Lokasi &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Via / Lewat</label><br />
			<input type="text" name="lokasi" id="lokasi" class="easyui-textbox" required="true" style="width:50%" disabled="disabled"/>
			<input type="text" name="lewat" id="lewat" class="easyui-textbox" required="true" style="width:49%" disabled="disabled"/>
		</div>
		<div class="form-item">
			<label for="lewat">Supply Point</label><br />
			<input type="text" name="spoint" id="spoint" class="easyui-textbox" required="true" style="width:100%" disabled="disabled"/>
		</div>
		<div class="form-item">
			<label for="lokasi">Angka Loses &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Biaya Pengiriman</label><br />
			<input type="text" name="angkaloses" id="angkaloses" class="easyui-textbox" required="true" style="width:50%" disabled="disabled"/>
			<input type="text" name="biayakirim" id="biayakirim" class="easyui-combobox" required="true" style="width:49%" disabled="disabled"/>
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="btn-lihat">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-lihat').dialog('close')">Batal</a>
</div>

<!-- Pencetakan ke Printer -->
<div id="dialog-excel" class="easyui-dialog" style="width:600px; height:400px; padding: 10px 20px" closed="true" buttons="#dialog-btn">
	<form id="form-excel" method="post" action="transaksi/qtn/cetak.php" target="_blank">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Customer &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Valid To</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="validto" id="validto" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="cofrom">CO From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="toup">UP / Email</label><br />
			<input type="text" name="toup" id="toup" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="toemail" id="toemail" class="easyui-textbox" required="true" style="width:49%"/>
		</div>
		<div class="form-item">
			<label for="pilihan">Pilihan</label><br />
			<select type="text" name="pilihan" id="pilihan" class="easyui-combobox" required="true" style="width:100%"/>
					<option value="Indonesia">Indonesia</option>
					<option value="Inggris">Inggris</option>
				</select>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="dialog-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" onclick="$('#form-excel').submit();">Cetak</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-excel').dialog('close')">Batal</a>
</div>
</body>
