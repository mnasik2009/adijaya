
<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">
var url;
function createbkm(){
	$('#dialog-bkm').dialog('open').dialog('setTitle','Entry Mutasi');
	$('#tanggal').textbox('setValue', '');
	$('#nobkm').textbox('setValue', '');
	$('#noinvoice').textbox('setValue', '');
	$('#nilai').textbox('setValue', '');
    $('#mtdbayar').textbox('setValue', '');
    $('#keterangan').textbox('setValue', '');
    $('#deskripsi').textbox('setValue', '');
}

function savebkm(){
	var nobkm = $("#nobkm").val();
	var string = $("#form-bkm").serialize();
	if(noinvoice.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, No Referensi tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#nobkm").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/bkm/simpan.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function hapus(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.posting =='N'){
		$.messager.confirm('Confirm','Yakin akan menghapus data ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/bkm/hapus.php",
					data	: 'id='+row.nobkm,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
				$.messager.show({
							title:'Info',
							msg:"Data tidak bisa dihapus, krn sudah diposting",
							timeout:2000,
							showType:'slide'
				});
			}
}
function posting(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.posting =='N'){
		$.messager.confirm('Confirm','Yakin akan memposting data ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/bkm/posting.php",
					data	: 'id='+row.nobkm,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
				$.messager.show({
							title:'Info',
							msg:"Data sudah diposting",
							timeout:2000,
							showType:'slide'
				});
			}
}
function cetakexcel(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-excel').dialog('open').dialog('setTitle','Print to Excel');
		$('#form-excel').form('load',row);
	}
}

function editmaster(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row.posting == 'N'){
		$('#dialog-bkm').dialog('open').dialog('setTitle','Edit Data Master');
		$('#form-bkm').form('load',row);
	}else{
		$.messager.show({
			title:'Info',
			msg:"Data Tidak Bisa diedit, krn sudah diposting",
			timeout:2000,
			showType:'slide'
		});
	}
}

function fresh(){
	$('#datagrid-crud').datagrid('reload');
}
function doSearch(){
	$('#datagrid-crud').datagrid('load',{
        cabang: $('#cabang').val(),
		cari: $('#cari').val()
    });
}
$(function(){
    $('#noinvoice').combogrid({
				panelWidth:600,
				url		: 'transaksi/bkm/get_data.php?',
				idField:'noinv',
				textField:'noinv',
				mode:'remote',
				fitColumns:true,
			    columns:[[
				{field:'noinv',title:'noinv',width:30},
			    {field:'nama',title:'nama',width:25},
			    {field:'total',title:'nilai',width:10},
				{field:'bayar',title:'bayar',width:10},
				{field:'cofrom',title:'cofrom',width:10},
			    ]],onClickRow:function(rowData){
			                                 var val =$('#noinvoice').combogrid('grid').datagrid('getSelected');
											 $('#keterangan').textbox('setValue', val.nama);
											 $('#nilai').textbox('setValue', val.total);
											 $('#cofrom').textbox('setValue', val.cofrom);
			                                }
						});

	$('#form-excel1').form(
        {
            url:'excelbkm.php',
            success:function(data){
                if(data)//check if data returned
                {
                alert('yes');
                }}
            }
    )
});
</script>
</head>
<body onload="doSearch()">


	<table id="datagrid-crud" title="Pembayaran Invoice" class="easyui-datagrid" style="width:auto; height: auto;" url="transaksi/bkm/jsonbkm.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
			<th data-options="field:'nobkm',width:15" >No Transaksi</th>
            <th data-options="field:'tanggal',width:10" sortable="true">Tanggal</th>
            <th data-options="field:'mtdbayar',width:8">Bank In</th>
			<th data-options="field:'deskripsi',width:20">Deskripsi</th>
            <th data-options="field:'nilai',width:10" align="right">Nilai</th>
			<th data-options="field:'noinvoice',width:15" align="right">No Invoice</th>
            <th data-options="field:'keterangan',width:15">Keterangan</th>
            <th data-options="field:'cofrom',width:15">Co From</th>
			<th data-options="field:'nojurnal',width:15">No Jurnal</th>
			<th data-options="field:'posting',width:8">Posting</th>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px">
		<div style="float:left;">
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-plus-square-o fa-lg" plain="true" onclick="createbkm()">Add</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-pencil-square-o fa-lg" plain="true" onclick="editmaster()">Edit</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-minus-square-o fa-lg" plain="true" onclick="hapus()">Delete</a>
            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-refresh fa-lg" plain="true" onclick="fresh()">Refresh</a>
            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" plain="true" onclick="cetakexcel()">Print</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-bookmark-o fa-lg" plain="true" onclick="posting()">Posting</a>
		</div>
		<div style="float:right;">
        	Pencarian <input id="cari" class="easyui-searchbox" data-options="prompt:'No. Trans ../Tanggal (YYYY-MM-DD)..',searcher:doSearch" style="width:250px"></input>
			<input name="cabang" type="hidden" id="cabang" value="<?php echo $_SESSION['cabang']?>">
		</div>
	</div>

<!-- Dialog Form -->
<div id="dialog-bkm" class="easyui-dialog" style="width:400px; height:550px; padding: 10px 20px" closed="true" buttons="#btn-bkk">
	<form id="form-bkm" method="post" novalidate>

		<div class="form-item">
			<label for="tanggal">Tanggal</label><br />
			<input type="text" name="tanggal" id="tanggal" class="easyui-datebox" required="true" data-options="prompt:'YYYY-MM-DD'" size="20" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="nobkm">No Transaksi</label><br/>
			<input type="text" name="nobkm" id="nobkm" class="easyui-textbox" style="width:100%" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="deskripsi">Deskripsi</label><br/>
			<input type="text" name="deskripsi" id="deskripsi" class="easyui-textbox" required="true"  style="width:100%;height:60px" data-options="multiline:true" />
		</div>
		<div class="form-item">
			<label for="noinvoice">Post to Inv</label><br />
			<input type="text" name="noinvoice" id="noinvoice" class="easyui-textbox" required="true" style="width:79%"/>
			<input type="hidden" name="username" id="username" value="<?php echo $_SESSION['username']?>"/>
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:20%">
		</div>
		<div class="form-item">
			<label for="nilai">Nilai</label><br/>
			<input type="text" name="nilai" id="nilai" class="easyui-textbox" data-options="valueField:'id',textField:'text'" required="true" style="width:100%" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="mtdbayar">Pembayaran</label><br/>
			<input type="text" name="mtdbayar" id="mtdbayar" class="easyui-textbox" required="true"  style="width:100%" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="keterangan">Keterangan</label><br/>
			<input type="text" name="keterangan" id="keterangan" class="easyui-textbox" required="true"  style="width:100%" maxlength="100"  />
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="btn-bkk">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" onclick="savebkm()">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-bkm').dialog('close')">Batal</a>
</div>

<div id="dialog-excel" class="easyui-dialog" style="width:400px; height:350px; padding: 10px 20px" closed="true" buttons="#btn-excel">
	<form id="form-excel" method="post" action="transaksi/bkm/bkmtemp.php" target="_blank">
		<div class="form-item">
			<label for="tanggal">Tanggal</label><br/>
			<input type="text" name="tanggal" id="tanggal" class="easyui-textbox" required="true" size="20" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="nobkm">No Transaksi</label><br/>
			<input type="text" name="nobkm" id="nobkm" class="easyui-textbox" style="width:100%" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="noinvoice">No Invoice</label><br />
			<input type="text" name="noinvoice" id="noinvoice" class="easyui-textbox" required="true" style="width:100%" data-options="multiline:true"/>
			<input type="hidden" name="username" id="username" value="<?php echo $_SESSION['username']?>"/>
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="btn-excel">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" onclick="$('#form-excel').submit();">Print</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-excel').dialog('close')">Batal</a>
</div>

</body>
