<?php
include '../../koneksi.php';
include '../../Classes/PHPExcel.php';
include '../../terbilang.php';

 $akses = isset($_POST['nobkm'])? mysql_real_escape_string($_POST['nobkm']) : '';
 $username = $_POST['username'];
 $tgl=date('d-m-Y H:i:s');
 $sql = "select * from bkm where nobkm ='" .$akses. "'";

 $result = mysql_query ($sql) or die (mysql_error ());
 $register = mysql_num_rows ($result);

	$objPHPExcel = new PHPExcel();
	$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:C3');
	$objPHPExcel->setActiveSheetIndex(0)->mergeCells('B7:D7');
	$objPHPExcel->setActiveSheetIndex(0)->mergeCells('E7:F7');

	$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
	$objPHPExcel->getActiveSheet()->getStyle('A7:F7')->getFont()->setBold(true);
	$objPHPExcel->getActiveSheet()->getStyle('F2')->getFont()->setBold(true);
	$objPHPExcel->getActiveSheet()->getStyle('C5')->getFont()->setBold(true);
	$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
	$objPHPExcel->getActiveSheet()->getStyle('A7:F7')->getFont()->setSize(14);
	$objPHPExcel->getActiveSheet()->getStyle('F2')->getFont()->setSize(11);
	$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth("15");
	$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth("3");
	$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth("56");
	$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth("10");
	$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth("2");
	$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth("20");

	$objPHPExcel->getActiveSheet()->getStyle('A1:C3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	$objPHPExcel->getActiveSheet()->getStyle('A1:C3')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
	$objPHPExcel->getActiveSheet()->getStyle('A7:F7')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	$objPHPExcel->getActiveSheet()->getStyle('A7:F7')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFE8E5E5');
	$objPHPExcel->getActiveSheet()->getStyle('A7:F7')->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('A1:C3')->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

	$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue("A1", 'BUKTI PENERIMAAN KAS')
				->setCellValue("D2", 'NO.' )
				->setCellValue("E2", ':')
				->setCellValue("A5", 'Diterima Dari : ')
				->setCellValue("D4", 'Tanggal')
				->setCellValue("E4", ':')
				->setCellValue("D5", 'Lampiran')
				->setCellValue("E5", ':')			
				->setCellValue("F5", '1 Lembar')
				->setCellValue("A7", 'No. Perkiraan')
				->setCellValue("B7", 'URAIAN')
				->setCellValue("E7", 'JUMLAH');

	$i = 8;
	$m = 1;
	$baris = $register + 8;
	$baris1 = $baris + 2;
	$baris2 = $baris1 + 2;
	$baris3 = $baris2 + 4;
	$baris4 = $baris3 + 1;

	while ($register = mysql_fetch_array ($result)) {
	$objPHPExcel->setActiveSheetIndex(0)->mergeCells("B$i:D$i");
	$objPHPExcel->setActiveSheetIndex(0)->mergeCells("E$i:F$i");
	$tanggal = date('d-m-Y',strtotime($register['tanggal']));
	$nilai = $register['nilai'];
	$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue("F2", $register['nobkm'])
				->setCellValue("F4", $register['tanggal'])
				->setCellValue("C5", $register['keterangan'])
				->setCellValue("A$i", $register['mtdbayar'])
				->setCellValue("B$i", $register['deskripsi'] . " untuk INV No. : " .$register['noinvoice'])
				->setCellValue("E$i", $register['nilai']);
				$objPHPExcel->getActiveSheet()->getStyle("E$i")->getNumberFormat()->setFormatCode('#,##0');
				$objPHPExcel->getActiveSheet()->getStyle("A$i:F$i")->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
				$objPHPExcel->getActiveSheet()->getStyle('F4:F5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);

		$i++;
		$m++;
	}
	// Kolom untuk jumlah
	$objPHPExcel->setActiveSheetIndex(0)->mergeCells("E$baris:F$baris");
	$objPHPExcel->setActiveSheetIndex(0)->mergeCells("A$baris:D$baris");
	$objPHPExcel->getActiveSheet()->getStyle("A$baris:F$baris")->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue("E$baris",$nilai);
	$objPHPExcel->getActiveSheet()->getStyle("E$baris")->getFont()->setBold(true);
	$objPHPExcel->getActiveSheet()->getStyle("E$baris")->getNumberFormat()->setFormatCode('#,##0');

	// kolom untuk terbilang
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue("A$baris1","Terbilang");
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue("B$baris1",":");
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue("C$baris1",Terbilang($nilai). " Rupiah");
	$objPHPExcel->getActiveSheet()->getStyle("A$baris1:C$baris1")->getFont()->setBold(true);
	$objPHPExcel->getActiveSheet()->getStyle("A$baris1:C$baris1")->getFont()->setSize(12);
	$objPHPExcel->getActiveSheet()->getStyle("A$baris1:C$baris1")->getFont()->setItalic(true);
	$objPHPExcel->getActiveSheet()->getStyle("A$baris1")->getFont()->SetName('Brush Script MT');
	$objPHPExcel->getActiveSheet()->getStyle("A$baris1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);

	// kolom untuk bkmir, penerima dan keuangan
	$objPHPExcel->setActiveSheetIndex(0)->mergeCells("A$baris2:B$baris2");
	$objPHPExcel->setActiveSheetIndex(0)->mergeCells("D$baris2:F$baris2");
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue("A$baris2","Prepared By");
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue("C$baris2","Checked By");
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue("D$baris2","Finance & ACC");
	$objPHPExcel->getActiveSheet()->getStyle("A$baris2:F$baris2")->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle("A$baris2:F$baris2")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

	// Kolom untuk nama penerima, bkmir dan keuangan
	$objPHPExcel->setActiveSheetIndex(0)->mergeCells("A$baris3:B$baris3");
	$objPHPExcel->setActiveSheetIndex(0)->mergeCells("D$baris3:F$baris3");
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue("A$baris3",$username);
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue("C$baris3","___________");
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue("D$baris3","___________");
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue("A$baris4", "Printed by " .$username. " date : ".$tgl);
	$objPHPExcel->getActiveSheet()->getStyle("A$baris4")->getFont()->setItalic(true);
	$objPHPExcel->getActiveSheet()->getStyle("A$baris3:F$baris3")->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle("A$baris3:F$baris3")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
		// buat garis semua
		$objPHPExcel->getActiveSheet()->getStyle("A1:F$baris3")
			->getBorders()
			->getTop()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
		$objPHPExcel->getActiveSheet()->getStyle("A1:F$baris3")
			->getBorders()
			->getBottom()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
		$objPHPExcel->getActiveSheet()->getStyle("A1:F$baris3")
			->getBorders()
			->getLeft()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
		$objPHPExcel->getActiveSheet()->getStyle("A1:F$baris3")
			->getBorders()
			->getRight()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

		// buat garis untuk C$baris2 :
		$objPHPExcel->getActiveSheet()->getStyle("C$baris2:C$baris3")
			->getBorders()
			->getTop()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
		$objPHPExcel->getActiveSheet()->getStyle("C$baris2:C$baris3")
			->getBorders()
			->getBottom()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
		$objPHPExcel->getActiveSheet()->getStyle("C$baris2:C$baris3")
			->getBorders()
			->getLeft()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
		$objPHPExcel->getActiveSheet()->getStyle("C$baris2:C$baris3")
			->getBorders()
			->getRight()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);


		// garis D1:F3
		$objPHPExcel->getActiveSheet()->getStyle("D1:F3")
			->getBorders()
			->getTop()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
		$objPHPExcel->getActiveSheet()->getStyle("D1:F3")
			->getBorders()
			->getBottom()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
		$objPHPExcel->getActiveSheet()->getStyle("D1:F3")
			->getBorders()
			->getLeft()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
		$objPHPExcel->getActiveSheet()->getStyle("D1:F3")
			->getBorders()
			->getRight()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

		// garis D4:D6
		$objPHPExcel->getActiveSheet()->getStyle("D4:D6")
			->getBorders()
			->getTop()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
		$objPHPExcel->getActiveSheet()->getStyle("D4:D6")
			->getBorders()
			->getBottom()
				->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
		$objPHPExcel->getActiveSheet()->getStyle("D4:D6")
			->getBorders()
			->getLeft()
			->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	header('Content-Disposition: attachment;filename="bkm.xlsx"');
	header('Cache-Control: max-age=0');
$objWriter=PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel2007');
$objWriter->save('php://output');
exit;

?>
