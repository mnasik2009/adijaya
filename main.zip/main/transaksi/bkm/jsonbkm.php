<?php
session_start();
include '../../koneksi.php';

$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
$rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'nobkm';
$order = isset($_POST['order']) ? strval($_POST['order']) : 'desc';
$cari = isset($_POST['cari']) ? mysql_real_escape_string($_POST['cari']) : '';
$cabang = $_SESSION['cabang'];

$offset = ($page-1) * $rows;

$where = " WHERE cabang='$cabang' and (nobkm LIKE '%$cari%' or noinvoice like '%$cari%')";

$text = "SELECT * FROM bkm
	$where  
	ORDER BY $sort $order
	LIMIT $rows OFFSET $offset";

$result = array();
$result['total'] = mysql_num_rows(mysql_query("SELECT * FROM bkm limit 200"));
$row = array();	

$criteria = mysql_query($text);
while($data=mysql_fetch_array($criteria))
{	
	$row[] = array(
		'nobkm'=>$data['nobkm'],
        'deskripsi'=>$data['deskripsi'],
        'noinvoice'=>$data['noinvoice'],
        'nilai'=>$data['nilai'],
		'tanggal'=>$data['tanggal'],
		'keterangan'=>$data['keterangan'],
		'mtdbayar'=>$data['mtdbayar'],
		'if_code'=>$data['if_code'],
		'cofrom'=>$data['cofrom'],
		'posting'=>$data['posting'],
		'nojurnal'=>$data['if_code'],
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
?>