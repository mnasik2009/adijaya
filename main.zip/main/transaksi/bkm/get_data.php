<?php
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';  
  
$arr_data=array();
$sql="SELECT * from inv_master where notrans like '%$q%' and (total - bayar - pph) > 0 limit 20";
$result = mysql_query($sql);
while($obj = mysql_fetch_array($result)) {
     $nilai = $obj['jumlah'] * $obj['harga'];
     $ppn = ($obj['ppn'] * $nilai ) / 100;
     $oat = $obj['oat'] * $obj['jumlah'];
     $pbbkb = ($obj['pbbkb'] * $nilai ) / 100;
     $total = $nilai + $ppn + $pbbkb + $oat;
     $sisa = $obj['total'] - $obj['bayar'];
     $arr_data[]=array(
          'noinv'=>$obj['notrans'],
          'nama'=>$obj['kodecust'],
          'total'=>$obj['total'],
          'bayar'=>$obj['bayar'],
          'sisa'=>$sisa,
          'cofrom'=>$obj['cofrom'],
     );
}

echo json_encode($arr_data);
?>
