


<script type="text/javascript">
var url;  
	$.fn.datebox.defaults.formatter = function(date){
		var y = date.getFullYear();
		var m = date.getMonth()+1;
		var d = date.getDate();
		return y+'-'+(m<10?('0'+m):m)+'-'+(d<10?('0'+d):d);
	};
	$.fn.datebox.defaults.parser = function(s){
		if (!s) return new Date();
		var ss = s.split('-');
		var y = parseInt(ss[0],10);
		var m = parseInt(ss[1],10);
		var d = parseInt(ss[2],10);
		if (!isNaN(y) && !isNaN(m) && !isNaN(d)){
			return new Date(y,m-1,d);
		} else {
			return new Date();
		}
	};
function doSearch(){
    $('#datagrid-crud').datagrid('load',{
		tgl1: $("#tgl1").val(),
		tgl2: $("#tgl2").val()

    });
 } 

$(function(){
        $('#frm2').form(
        {
            url:'kas_excel.php',
            success:function(data){
                if(data)//check if data returned
                {
                alert('yes');
                }}
            }
        )
    })
</script>
</head>
<body>
   
	
	<div style="margin:10px 0;"></div>
	<table id="datagrid-crud" title="KAS Reporting" class="easyui-datagrid" style="width:auto; height: auto;" url="json.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
            <th data-options="field:'noref',width:20" sortable="true">No Transaksi</th>
            <th data-options="field:'tanggal',width:12" sortable="true">Tgl Trans</th>
            <th data-options="field:'kegiatan',width:10">Kegiatan</th>
            <th data-options="field:'deskripsi',width:25">Deskripsi</th>
            <th data-options="field:'debet',width:10">Debet</th>
            <th data-options="field:'kredit',width:10">Kredit</th>
            <th data-options="field:'penerima',width:15">Penerima</th>
            <th data-options="field:'ifcode',width:15">No Jurnal</th>		
        </tr>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px;">
		<div style="float:left;">
		<form method="post" name="frm2" id="frm2" action="#"> 
			<input name="tgl1" id="tgl1" type="text" class="easyui-textbox" size="18" prompt="yyyy-mm-dd">
			<input name="tgl2" id="tgl2" type="text" class="easyui-textbox" size="18" prompt="yyyy-mm-dd">
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-search" plain="true" onclick="doSearch()">Proses</a>			
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-excel" plain="true" onclick="$('#frm2').submit();">Export to Excel</a>
		</form>
	</div>
	</div>
</body>
