<?php
session_start();
include '../../koneksi1.php';

//$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
//$rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
//$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'notransaksi';
//$order = isset($_POST['order']) ? strval($_POST['order']) : 'asc';
 $tgl1 = isset($_POST['tgl1'])? mysql_real_escape_string($_POST['tgl1']) : '';
 $tgl2 = isset($_POST['tgl2'])? mysql_real_escape_string($_POST['tgl2']) : '';
 $cabang = $_SESSION['cabang'];
//$offset = ($page-1) * $rows;

$format1=date('Y-m-d',strtotime($tgl1));
$format2=date('Y-m-d',strtotime($tgl2));

$text = "SELECT * from bkm where cabang='$cabang' and tanggal>='" .$format1. "' and tanggal <='" .$format2. "'"; 

$result = array();
//$result['total'] = mysql_num_rows(mysql_query("SELECT jadwal.*,mcustomer.tanggal FROM mcustomer,jadwal 
//	WHERE mcustomer.notransaksi=jadwal.notransaksi and tanggal>='" .$tgl1. "' and tanggal <='".$tgl2. "'"));
$row = array();	

$criteria = mysql_query($text);
while($data=mysql_fetch_array($criteria))
{	
	$row[] = array(
		'noref'=>$data['noref'],
		'tanggal'=>$data['tanggal'],
		'kegiatan'=>$data['kegiatan'],
		'deskripsi'=>$data['deskripsi'],
		'debet'=>$data['debet'],
		'kredit'=>$data['kredit'],
		'penerima'=>$data['penerima'],
		'ifcode'=>$data['ifcode'],
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
?>