<?php
include '../../koneksi1.php';
$kode = $_POST['id'];
$row = mysql_num_rows(mysql_query("SELECT * FROM bkm WHERE nobkm='$kode'"));
if($row>0){
	$text = "DELETE FROM bkm 
			WHERE nobkm='$kode'";
	mysql_query($text);
	echo "Hapus Sukses";
}else{
	echo "Tidak ada data yang dihapus $kode";
}
?>