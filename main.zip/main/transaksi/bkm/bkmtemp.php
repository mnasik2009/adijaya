<link href="../../style_doc.css" rel="stylesheet" type="text/css" />
<title>Bukti Kas</title>
<?php
include '../../koneksi.php';

 $akses = $_POST['nobkm'];
 $username = $_POST['username'];
 $tgl=date('d M Y');
	//modus tanggal

$sql = "select * from bkm where nobkm ='$akses'";


$query = mysql_query($sql);
$pe = mysql_fetch_array($query);
$penerima = $pe['keterangan'];
$mtd = $pe['mtdbayar'];
$desk = $pe['deskripsi'];
$nilai = $pe['nilai'];
$noinv = $pe['noinvoice'];
$cofrom = $pe['cofrom'];

if ($cofrom == 'AJ0001'){
    $img = '../../dist/img/logo_aj.png';
    $pt = 'PT. ABADI JAYA';
  }else{
    $img = '../../dist/img/logo_paj.png';
    $pt = 'PT. PRIMA ABADI JAYA';
  }
  

echo"<table width='100%' border='0'>
 <tr>
	<th rowspan='4' align='left'><img src=$img width='200' height='64'></th>
    <th align=center><font size='4'><b>BUKTI PENERIMAAN</font> </b></th><br/>
	<th align=right scope='col'><font size='2'><b></font> </b></th>
	<th align=right scope='col'><font size='2'><b></font> </b></th>
	<th align=right scope='col'><font size='2'><b></font> </b></th>
  </tr>
 <tr>
	<th colspan='4' align=right scope='col'><font size='2'><b>No. Transaksi</font> </b></th>
	<th align=left scope='col'><font size='2'><b>: ".$akses."</font> </b></th>
  </tr>
 <tr>
	<th colspan='4' align=right scope='col'><font size='2'><b>Tanggal </font> </b></th>
	<th align=left scope='col'><font size='2'><b>: ".$tgl."</font> </b></th>
  </tr>
 <tr>
	<th colspan='4' align=right scope='col'><font size='2'><b>Departemen </font> </b></th>
	<th align=left scope='col'><font size='2'><b>: ....................... </font> </b></th>
  </tr>
</table>
";
?>
 <br/>
<table width='100%' border='0'>
	<tr>
		<th align='left' scope='col'><font size='3'>Customer : <?php echo $penerima; ?></font></th>
	</tr>
</table>
<br/>
 <table width='100%' border='1'>
							  <thead>
								  <tr>
									  <th><font size='2'>Metode</th>
									  <th><font size='2'><center>Description</center></font></th>
									  <th><font size='2'><center>Invoice No.</center></font></th>
									  <th><font size='2'>Nilai</font></th>
								  </tr>
							  </thead>
							  <tbody>
				<tr>
                <td><font size='2'><center><?php echo $mtd; ?></center></font></td>
                <td><font size='2'><?php echo $desk; ?></font></td>
				<td><font size='2'><?php echo $noinv; ?></font></td>
                <td align="right"><font size='2'><?php echo number_format($nilai); ?></font></td>
                </tr>
			   <tr>
				<td style="border:yes" colspan="3" align="center"><font size='3'>Total</td>
				<td style="border:yes" align="right"><font size='3'><?php echo number_format($nilai); ?></td>

              </tr>
			  <tr>
				<td style="border:1" align="left"><font size='2'>Cash/Cheque</td>
				<td style="border:1" align="left"><font size='2'>NO.:</td>
				<td style="border:1" colspan='2' align="left"><font size='2'>Rp. / USD</td>

              </tr>
			  <tr>
				<td height="25" style="border:no" colspan="4" align="center"><font size='2'> </td>
              </tr>
							  </tbody>

						 </table>
<br/>
  <br/>
<table width='100%' border='0'><font size='2'>
  <tr>
    <th width='201' scope='col'><font size='2'>Prepaid By</th>
    <th width='202' scope='col'><font size='2'>Authorized By 1</th>
    <th width='201' scope='col'><font size='2'>Authorized By 2</th>
	<th width='202' scope='col'><font size='2'>Received By </th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>

   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>

   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'></th>
    <th width='202' scope='col'><font size='2'></th>
    <th width='201' scope='col'><font size='2'></th>
	<th width='202' scope='col'><font size='2'></th>

  </tr>
   <tr>
    <th width='201' scope='col'><font size='2'>Date : .......................</th>
    <th width='202' scope='col'><font size='2'>Date : .......................</th>
    <th width='201' scope='col'><font size='2'>Date : .......................</th>
	<th width='202' scope='col'><font size='2'>Date : .......................</th>

  </tr>

</table>

<br/>
<br/>
</body>
