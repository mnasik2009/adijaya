<?php
include '../../koneksi1.php';
$kode = $_POST['id'];
$tgl = date('d-m-Y h:i:s');
$row = mysql_num_rows(mysql_query("SELECT * FROM bkm WHERE nobkm='$kode'"));
$global = mysql_query("select * from globalset");
$result = mysql_fetch_array($global);
$kodept = $result['kode_fin'];
if($row > 0){
	$text = "select bkm.*, invoice.customer, mcustomer.keu_code, mtdbayar.if_code AS if_fin from bkm, mcustomer, mtdbayar, invoice
            where bkm.noinvoice = invoice.noinvoice
            and invoice.customer = mcustomer.kode
            and bkm.mtdbayar = mtdbayar.kode
            and nobkm ='$kode'";
	$master1 = mysql_fetch_array(mysql_query($text));
	$notransaksi = $master1['nobkm'];
    $nojurnal = $master1['if_code'];
    $tanggal = $master1['tanggal'];
    $if_code = $master1['if_fin'];
    $if_code1 = $master1['keu_code'];
    $keterangan = $master1['keterangan'];
    $kredit = $master1['nilai'];
    $insert1 = "insert into if_finance set 
               nojurnal = '$nojurnal',
               kodept = '$kodept',
               tanggal = '$tanggal',
               remarks1 ='Null',
               notransaksi = '$notransaksi',
               userid = 'Admin',
               tglinput = '$tgl',
               if_code = '$if_code',
               keterangan = '$keterangan',
               debet = '$kredit',
               kredit = 0,
               remarks2 ='Null',
               ref = '001',
               trf='N'";
    mysql_query($insert1);

    $insert2 = "insert into if_finance set 
                nojurnal = '$nojurnal',
                kodept = '$kodept',
                tanggal = '$tanggal',
                remarks1 ='Null',
                notransaksi = '$notransaksi',
                userid = 'Admin',
                tglinput = '$tgl',
                if_code = '$if_code1',
                keterangan = '$keterangan',
                debet = 0,
                kredit = '$kredit',
                remarks2 ='Null',
                ref = '001',
                trf='N'";
    mysql_query($insert2);
    mysql_query("update bkm set posting='Y' where nobkm='$kode'");
    echo "Posting Sukses";
}else{
	echo "Tidak bisa diposting karena $kode ada yang kurang lengkap";
}
?>