<?php
session_start();
include '../../koneksi.php';

$username = $_SESSION['username'];
$cabang = $_SESSION['cabang'];
$tanggal = $_POST['tanggal'];
$noinvoice = $_POST['noinvoice'];
$nobkm = $_POST['nobkm'];
$keterangan = $_POST['keterangan'];
$deskripsi = $_POST['deskripsi'];
$nilai = $_POST['nilai'];
$mtdbayar = $_POST['mtdbayar'];
$cofrom=$_POST['cofrom'];
 
$tahun = $format = date('Y', strtotime($tanggal));
$bulan = $format = date('m', strtotime($tanggal));
$format1 = date('d-m-Y', strtotime($tanggal));
$format2 = date('Y-m-d', strtotime($tanggal));
$bb = $format = date('y', strtotime($tanggal));
$tglinput = date('d-m-Y');
$nomor = mysql_query("select max(substr(nobkm,-6)) as nobkm from bkm where year(tanggal)='$tahun' and cabang='$cabang'");

$data1 = mysql_fetch_array($nomor);
$idMax = $data1['nobkm'];
$idMax++;
$newID = $cofrom.'/'.$cabang.'-BKM-' .$tahun .$bulan . sprintf('%06d',$idMax);
$ifbkk = 'KM'. sprintf('%05d',$idMax). '/' .$bulan . $bb;

$row = mysql_num_rows(mysql_query("SELECT * FROM bkm WHERE nobkm='$nobkm'"));
if($row>0){
	$text = "UPDATE bkm SET noinvoice = '$noinvoice',
								tanggal = '$format2',
								tglinput = '$tglinput',
								keterangan = '$keterangan',
								deskripsi = '$deskripsi',
                                nilai = '$nilai',
                                mtdbayar = '$mtdbayar',
								keterangan = '$keterangan',
								cabang = '$cabang'
								WHERE nobkm='$nobkm'";
	mysql_query($text);
	echo "Update Sukses";
}else{
    $text = "INSERT INTO bkm (nobkm,tanggal,noinvoice,tglinput,userid,keterangan,deskripsi,nilai,mtdbayar,if_code,cofrom,cabang)
			VALUES ('$newID','$format2','$noinvoice','$tglinput','$username','$keterangan','$deskripsi','$nilai','$mtdbayar','$ifbkk','$cofrom','$cabang')";
	mysql_query($text);
	echo "Simpan Sukses " .$newID;	
}
?>