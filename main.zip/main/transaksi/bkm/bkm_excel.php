<?php
include '../../koneksi1.php';
include '../../Classes/PHPExcel.php';
	
 $tgl1 = isset($_POST['tgl1'])? mysql_real_escape_string($_POST['tgl1']) : '';
 $tgl2 = isset($_POST['tgl2'])? mysql_real_escape_string($_POST['tgl2']) : '';
 
	$format1=date('Y-m-d',strtotime($tgl1));
	$format2=date('Y-m-d',strtotime($tgl2));

 $tgl=date('d-m-Y');
 $sql = "SELECT * from kas where tanggal>='".$format1. "' and tanggal <='" .$format2. "'";
 
 $result = mysql_query ($sql) or die (mysql_error ());
 $register = mysql_num_rows ($result);

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:I1');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A2:I2');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A3:I3');
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A4:I4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
$objPHPExcel->getActiveSheet()->getStyle('A2')->getFont()->setSize(16);
$objPHPExcel->getActiveSheet()->getStyle('A5:I5')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->getStyle('A1:I1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A2:I2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A3:I3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4:I4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4:I4')->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('A4:I4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFE8E5E5');

 
 $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A1", 'REKAP BIAYA NON OPERASIONAL')
            ->setCellValue("A2", "TANGGAL : " .$tgl1. "  S/D : " .$tgl2. "")
			
 
            ->setCellValue("A4", 'No')
            ->setCellValue("B4", 'No Transaksi')
            ->setCellValue("C4", 'Tanggal')			
            ->setCellValue("D4", 'Kegiatan')
			->setCellValue("E4", 'Deskripsi')
			->setCellValue("F4", 'Debet')
   			->setCellValue("G4", 'Kredit')
   			->setCellValue("H4", 'Penerima')
 			->setCellValue("I4", 'No. Jurnal');

   $i = 5;    
   $m = 1;
   while ($register = mysql_fetch_array ($result)) {
        
   $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A$i", "{$m}")
            ->setCellValue("B$i", "{$register['noref']}")
            ->setCellValue("C$i", "{$register['tanggal']}")
			->setCellValue("D$i", "{$register['kegiatan']}")
			->setCellValue("E$i", "{$register['deskripsi']}")
			->setCellValue("F$i", "{$register['debet']}")
			->setCellValue("G$i", "{$register['kredit']}")
			->setCellValue("H$i", "{$register['penerima']}")
			->setCellValue("I$i", "{$register['ifcode']}");          
			$objPHPExcel->getActiveSheet()->getStyle("A$i:I$i")->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
			
      $i++;
      $m++;
   }

	for($col = 'A'; $col !== 'I'; $col++) {
		$objPHPExcel->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
	}
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="kasreport.xlsx"');
header('Cache-Control: max-age=0');

$objWriter=PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel2007');
$objWriter->save('php://output');
exit;

?>