<!DOCTYPE html>
<html>
<head>

<script type="text/javascript">
var url;
function create(){
	$('#dialog-form').dialog('open').dialog('setTitle','Proses Gaji dan Potongan');
	$('#form').form('clear');
}

function printslip(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-excel').dialog('open').dialog('setTitle','Print Data Gaji');
		$('#form-excel').form('load',row);
	}
}

function hadir(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-hadir').dialog('open').dialog('setTitle','Input Data Kehadiran');
		$('#form-hadir').form('load',row);
	}
}

function potongan(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-potongan').dialog('open').dialog('setTitle','Input Data Potongan');
		$('#form-potongan').form('load',row);
	}
}

function save(){
	var kode = $("#kode").val();
	var string = $("#form").serialize();
	if(kode.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, kode tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#kode").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/gaji/simpan.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function savecuti(){
	var kode = $("#gapok").val();
	var string = $("#form-cuti").serialize();
	if(kode.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, Tahun tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#gapok").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/gaji/simpancuti.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function saveubah(){
	var kode = $("#gapok").val();
	var string = $("#form-edit").serialize();
	if(kode.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, Tahun tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#nik").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/gaji/simpanedit.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function simpanhadir(){
	var nik = $("#no_id").val();
	var string = $("#form-hadir").serialize();
	if(nik.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, NIK tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#nik").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/gaji/simpanhadir.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function simpanpot(){
	var nik = $("#no_id").val();
	var string = $("#form-potongan").serialize();
	if(nik.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, NIK tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#gapok").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/gaji/simpot.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}


function hapus(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row){
		$.messager.confirm('Confirm','Apabila anda menghapus data, seluruh data cuti akan terhapus ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/gaji/hapus.php",
					data	: 'id='+row.gapok,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}
}
function update(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-edit').dialog('open').dialog('setTitle','Edit Data t_komunikasi Cuti');
		$('#form-edit').form('load',row);
	}
}

function cuti(){
		$('#dialog-cuti').dialog('open').dialog('setTitle','Tambah / Edit Cuti Bersama');
		$('#form-cuti').form('clear');
}

function fresh(){
	$('#datagrid-crud').datagrid('reload');
}
function doSearch(value){
	$('#datagrid-crud').datagrid('load',{
        cari: value
    });
}
</script>
</head>
<body>


	<div style="margin:10px 0;"></div>

	<table id="datagrid-crud" title="Input Data Gaji" class="easyui-datagrid" style="width:auto; height: auto;" url="transaksi/gaji/json.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
            <th data-options="field:'no_id'" sortable="true">No Induk</th>
            <th data-options="field:'nama'" sortable="true">Nama Karyawan</th>
			<th data-options="field:'tanggal'" sortable="true">Tgl Masuk</th>
            <th data-options="field:'gapok'">Hak Cuti</th>
            <th data-options="field:'t_kesejahteraan'">T. Kesejahteraan</th>
            <th data-options="field:'t_komunikasi'">T. Komunikasi</th>
            <th data-options="field:'t_makan'">T. Makan</th>
			<th data-options="field:'t_kinerja'">T. Kinerja</th>
            <th data-options="field:'t_jabatan'">T. Jabatan</th>
			<th data-options="field:'t_transport'">T. Transport</th>
	        <th data-options="field:'t_hariraya'">T. Hari Raya</th>
	        <th data-options="field:'t_cuti'">T. Cuti</th>
	        <th data-options="field:'t_lain'">T. Lain-lain</th>
			<th data-options="field:'jumlahin'">Masuk</th>
			<th data-options="field:'potongan'">Potongan</th>
			<th data-options="field:'potbpjstk'">BPJS TK</th>
            <th data-options="field:'potlain'">Potongan Lain</th>
			<th data-options="field:'bulan'">Bulan</th>
			<th data-options="field:'tahun'">Tahun</th>
        </tr>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px;">
		<div style="float:left;">
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-plus-square-o fa-lg" plain="true" onclick="create()">Tambah All</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-list fa-lg" plain="true" onclick="hadir()">Kehadiran</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-calculator fa-lg" plain="true" onclick="potongan()">Potongan</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-file-excel-o fa-lg" plain="true" onclick="printslip()">Print Slip</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-pencil-square-o fa-lg" plain="true" onclick="update()">Edit</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-minus-square-o fa-lg" plain="true" onclick="hapus()">Hapus</a>
      <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-refresh fa-lg" plain="true" onclick="fresh()">Refresh</a>
		</div>
		<div style="float:right;">
        	Pencarian <input id="cari" class="easyui-searchbox" data-options="prompt:'Cari Kode / cutilebaran..',searcher:doSearch" style="width:200px"></input>
		</div>
	</div>

<!-- Dialog Form -->
<div id="dialog-form" class="easyui-dialog" style="width:400px; height:300px; padding: 10px 20px" closed="true" buttons="#dialog-buttons">
	<form id="form" method="post" novalidate>
    <div class="form-item">
		  <label for="Bulan">Bulan</label><br />
		  <select type="text" name="bulan" id="bulan" class="easyui-combobox" required="true" style="width:100%"/>
          <option value="01">Januari</option>
          <option value="02">Februari</option>
          <option value="03">Maret</option>
          <option value="04">April</option>
          <option value="05">Mei</option>
          <option value="06">Juni</option>
          <option value="07">Juli</option>
          <option value="08">Agustus</option>
          <option value="09">September</option>
          <option value="10">Oktober</option>
          <option value="11">Nopember</option>
          <option value="12">Desember</option></select>
		</div>
		<div class="form-item">
			<label for="type">Tahun</label><br />
			<input type="text" name="kode" id="kode" class="easyui-textbox" required="true" style="width:100%"/>
		</div>

	</form>
</div>
<!-- Dialog Button -->
<div id="dialog-buttons">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-save fa-lg" onclick="save()">Proses</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" onclick="javascript:jQuery('#dialog-form').dialog('close')">Batal</a>
</div>

<!-- Dialog Edit -->
<div id="dialog-edit" class="easyui-dialog" style="width:400px; height:500px; padding: 10px 20px" closed="true" buttons="#db-edit">
	<form id="form-edit" method="post" novalidate>
		<div class="form-item">
			<label for="type">No. Induk Karyawan</label><br />
			<input type="text" name="no_id" id="no_id" class="easyui-textbox" required="true" style="width:40%"/>
			<input type="text" name="nama" id="nama" class="easyui-textbox" required="true" style="width:59%"/>
		</div>
		<div class="form-item">
			<label for="type">Bulan & Tahun</label><br />
			<input type="text" name="bulan" id="bulan" class="easyui-textbox" required="true" style="width:40%"/>
			<input type="text" name="tahun" id="tahun" class="easyui-textbox" required="true" style="width:59%"/>
		</div>
		<div class="form-item">
			<label for="type">Gaji Pokok</label><br />
			<input type="text" name="gapok" id="gapok" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
		  <label for="t_komunikasi">T. Komunikasi</label><br />
		  <input type="text" name="t_komunikasi" id="t_komunikasi" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
		  <label for="t_kesejahteraan">T. Kesejahteraan</label><br />
		  <input type="text" name="t_kesejahteraan" id="t_kesejahteraan" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
		  <label for="t_makan">T. Makan</label><br />
		  <input type="text" name="t_makan" id="t_makan" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
    <div class="form-item">
		  <label for="t_kinerja">T. Kinerja</label><br />
		  <input type="text" name="t_kinerja" id="t_kinerja" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
    <div class="form-item">
		  <label for="t_jabatan">T. Jabatan</label><br />
		  <input type="text" name="t_jabatan" id="t_jabatan" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
		  <label for="t_transport">T. Transportasi</label><br />
		  <input type="text" name="t_transport" id="t_transport" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
		  <label for="t_hariraya">T. Hari Raya</label><br />
		  <input type="text" name="t_hariraya" id="t_hariraya" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
		  <label for="t_cuti">T. Cuti</label><br />
		  <input type="text" name="t_cuti" id="t_cuti" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
		  <label for="t_lain">T. Lain-lian</label><br />
		  <input type="text" name="t_lain" id="t_lain" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>
<!-- Dialog Button -->
<div id="db-edit">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-save fa-lg" onclick="saveubah()">Proses</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" onclick="javascript:jQuery('#dialog-edit').dialog('close')">Batal</a>
</div>


<div id="dialog-excel" class="easyui-dialog" style="width:400px; height:400px; padding: 10px 20px" closed="true" buttons="#btn-excel">
	<form id="form-excel" method="post" action="transaksi/gaji/printemp.php" target="_blank">
		<div class="form-item">
			<label for="tglinv">N I K</label><br/>
			<input type="text" name="no_id" id="no_id" class="easyui-textbox" required="true" size="20"  />
		</div>
		<div class="form-item">
			<label for="noinvoice">Nama</label><br/>
			<input type="text" name="nama" id="nama" class="easyui-textbox" style="width:100%"  />
		</div>
		<div class="form-item">
			<label for="Bulan">Bulan dan Tahun</label><br/>
			<input type="text" name="bulan" id="bulan" class="easyui-textbox" style="width:49%"  />
			<input type="text" name="tahun" id="tahun" class="easyui-textbox" style="width:50%"  />
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="btn-excel">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" onclick="$('#form-excel').submit();">Print</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-excel').dialog('close')">Batal</a>
</div>


<div id="dialog-hadir" class="easyui-dialog" style="width:400px; height:400px; padding: 10px 20px" closed="true" buttons="#btn-hadir">
	<form id="form-hadir" method="post">
		<div class="form-item">
			<label for="tglinv">N I K</label><br/>
			<input type="text" name="no_id" id="no_id" class="easyui-textbox" required="true" size="20"  />
		</div>
		<div class="form-item">
			<label for="noinvoice">Nama</label><br/>
			<input type="text" name="nama" id="nama" class="easyui-textbox" style="width:100%"  />
		</div>
		<div class="form-item">
			<label for="Bulan">Bulan dan Tahun</label><br/>
			<input type="text" name="bulan" id="bulan" class="easyui-textbox" style="width:49%"  />
			<input type="text" name="tahun" id="tahun" class="easyui-textbox" style="width:50%"  />
		</div>
		<div class="form-item">
			<label for="Bulan">Hadir&emsp;&emsp;&nbsp;Sakit&emsp;&emsp;&emsp;Ijin&nbsp;&emsp;&emsp;&emsp;&emsp;Alpa&nbsp;&emsp;&emsp;Cuti</label><br/>
			<input type="text" name="hadir" id="hadir" class="easyui-textbox" style="width:19%"  />
			<input type="text" name="sakit" id="sakit" class="easyui-textbox" style="width:19%"  />
			<input type="text" name="ijin" id="ijin" class="easyui-textbox" style="width:19%"  />
			<input type="text" name="alpa" id="alpa" class="easyui-textbox" style="width:19%"  />
			<input type="text" name="cuti" id="cuti" class="easyui-textbox" style="width:19%"  />
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="btn-hadir">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-save fa-lg" onclick="simpanhadir()">Simpab</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-hadir').dialog('close')">Batal</a>
</div>

<div id="dialog-potongan" class="easyui-dialog" style="width:400px; height:450px; padding: 10px 20px" closed="true" buttons="#btn-potongan">
	<form id="form-potongan" method="post">
		<div class="form-item">
			<label for="tglinv">N I K</label><br/>
			<input type="text" name="no_id" id="no_id" class="easyui-textbox" required="true" style="width:40%"  />
			<input type="text" name="nama" id="nama" class="easyui-textbox" style="width:59%"  />
		</div>
		<div class="form-item">
			<label for="Bulan">Bulan dan Tahun</label><br/>
			<input type="text" name="bulan" id="bulan" class="easyui-textbox" style="width:49%"  />
			<input type="text" name="tahun" id="tahun" class="easyui-textbox" style="width:50%"  />
		</div>
		<div class="form-item">
		  <label for="potbpjstk">Pot. BPJS Ketanagakerjaan</label><br />
		  <input type="text" name="potbpjstk" id="potbpjstk" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
    <div class="form-item">
		  <label for="potongan">Pot. Pinjaman</label><br />
		  <input type="text" name="potongan" id="potongan" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
     <label for="potlain">Potongan BAZIS</label><br />
     <input type="text" name="bazis" id="bazis" class="easyui-textbox" required="true" style="width:100%"/>
   </div>
    <div class="form-item">
     <label for="potlain">Potongan Keterlambatan</label><br />
     <input type="text" name="potlain" id="potlain" class="easyui-textbox" required="true" style="width:100%"/>
   </div>
	</form>
</div>

<!-- Dialog Button -->
<div id="btn-potongan">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-save fa-lg" onclick="simpanpot()">Simpab</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-potongan').dialog('close')">Batal</a>
</div>

</body>
</html>
