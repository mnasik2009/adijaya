<?php
include '../../koneksi.php';

$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
$rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'no_id';
$order = isset($_POST['order']) ? strval($_POST['order']) : 'asc';
$cari = isset($_POST['cari']) ? mysql_real_escape_string($_POST['cari']) : '';

$offset = ($page-1) * $rows;

$where = " WHERE no_id LIKE '%$cari%'";

$text = "SELECT * FROM gaji_transaksi
	$where
	ORDER BY $sort $order
	LIMIT $rows OFFSET $offset";

$result = array();
$result['total'] = mysql_num_rows(mysqli_query($conn,"SELECT * FROM gaji_transaksi $where"));
$row = array();

$criteria = mysqli_query($conn,$text);
while($data=mysqli_fetch_array($criteria))
{
	$nik = $data['no_id'];
	$dkar = mysqli_fetch_array(mysqli_query($conn,"select * from karyawan_induk where no_id='$nik'"));
	$row[] = array(
		'no_id'=>$data['no_id'],
		'nama'=>$dkar['nama'],
		'tanggal'=>date('m/d/Y', strtotime($data['tanggal'])),
		'gapok'=>$data['gapok'],
		't_kesejahteraan'=>$data['t_kesejahteraan'],
		't_komunikasi'=>$data['t_komunikasi'],
		't_makan'=>$data['t_makan'],
		't_kinerja'=>$data['t_kinerja'],
		't_transport'=>$data['t_transport'],
		't_cuti'=>$data['t_cuti'],
		't_hariraya'=>$data['t_hariraya'],
		't_lain'=>$data['t_lain'],
		'notrans'=>$data['notrans'],
    'tahun'=>$data['tahun'],
    'bulan'=>$data['bulan'],
    'potlain'=>$data['potlain'],
    'potongan'=>$data['potongan'],
    'potbpjstk'=>$data['potbpjstk'],
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
?>
