<?php
session_start();
include '../../koneksi.php';

$nik = $_POST['no_id'];
$nama = $_POST['nama'];
$tahun = $_POST['tahun'];
$bulan = $_POST['bulan'];
$tanggal = date('Y-m-d');
$t_kesejahteraan = $_POST['t_kesejahteraan'];
$t_komunikasi = $_POST['t_komunikasi'];
$gapok = $_POST['gapok'];
$t_makan = $_POST['t_makan'];
$t_kinerja = $_POST['t_kinerja'];
$t_jabatan = $_POST['t_jabatan'];
$t_transport = $_POST['t_transport'];
$t_cuti = $_POST['t_cuti'];
$t_hariraya = $_POST['t_cuti'];
$t_lain = $_POST['t_lain'];
$row = mysql_num_rows(mysqli_query($conn,"SELECT * FROM gaji_transaksi WHERE no_id='$nik' and bulan='$bulan' and tahun='$tahun'"));
if ($row > 0){
		$text = "update gaji_transaksi set tanggal='$tanggal',
																			 gapok = '$gapok',
																			 t_kesejahteraan = '$tkesej',
																			 t_komunikasi = '$t_komunikasi',
                                       t_makan = '$t_makan',
                                       t_kinerja = '$t_kinerja',
                                       t_jabatan = '$t_jabatan',
																			 t_transport = '$t_transport',
																			 t_hariraya = '$t_transport',
																			 t_cuti = '$t_cuti',
																			 t_lain = '$t_lain'
																			 where no_id = '$nik' and tahun='$kode' and bulan='$bulan'";
		mysqli_query($conn,$text);
	  echo "Data Gaji untuk $nik bulan: $bulan dan tahun: $kode tersimpan";
}

?>
