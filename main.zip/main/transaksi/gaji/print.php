<?php
include '../../koneksi.php';
include '../../Classes/PHPExcel.php';
include '../../Classes/PHPExcel/IOFactory.php';
include '../../terbilang.php';
include '../../phpqrcode/qrlib.php';
error_reporting();
$nik = isset($_POST['no_id'])? mysql_real_escape_string($_POST['no_id']) : '';
$bulan = isset($_POST['bulan'])? mysql_real_escape_string($_POST['bulan']) : '';
$tahun = isset($_POST['tahun'])? mysql_real_escape_string($_POST['tahun']) : '';
 //$tgl=date('d-m-Y H:i:s');
 //$username = $_POST['username'];
 //$dok = mysqli_query($conn,"Select * from dokumen where kode='SJ'");
 //$hasildok = mysqli_fetch_array($dok);
 //$nomordok = $hasildok['nomor'];
 $sql = "select gaji_transaksi.*, karyawan_induk.nama, karyawan_induk.jabatan, karyawan_induk.kawin, karyawan_induk.tgl_masuk from gaji_transaksi, karyawan_induk where gaji_transaksi.no_id = karyawan_induk.no_id
         and gaji_transaksi.no_id = '$nik' and bulan='$bulan' and tahun='$tahun'";

 $result = mysql_query ($sql) or die (mysql_error ());
 $register = mysqli_fetch_array($result);

 if ($bulan == '01'){
   $des = 'Januari';
 }else if ($bulan == '02'){
   $des = 'Februari';
 }else if ($bulan == '03'){
   $des = 'Maret';
 }else if ($bulan == '04'){
   $des = 'April';
 }else if ($bulan == '05'){
   $des = 'Mei';
 }else if ($bulan == '06'){
   $des = 'Juni';
 }else if ($bulan == '07'){
   $des = 'Juli';
 }else if ($bulan == '08'){
   $des = 'Agustus';
 }else if ($bulan == '09'){
   $des = 'September';
 }else if ($bulan == '10'){
   $des = 'Oktober';
 }else if ($bulan == '11'){
   $des = 'Nopember';
 }else if ($bulan == '12'){
   $des = 'Desember';
 }
 //$tempdir = "temp/";
 //if (!file_exists($tempdir))
//		mkdir($tempdir);
 //$isi = substr($akses,-15);
 //$namafile = $isi.'.png';
 //$qua = 'H';
 //$ukuran = 5;
 //$padding = 0;
 //QRCode::png($akses,$tempdir.$namafile,$qua,$ukuran,$padding);
$total = $register['gapok']+$register['t_jabatan']+$register['t_kesejahteraan']+$register['t_makan']+$register['t_komunikasi']+$register['t_kinerja'];
$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:H1');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A3:C3');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('F2:H2');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('F3:H3');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('G24:H24');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('G29:H29');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('F6:H6');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('F14:H14');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('F15:H15');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('F16:H16');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('F21:H21');

$objPHPExcel->setActiveSheetIndex(0)->setCellValue("A1","PT. MIGAS MANDIRI PRATAMA");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("A2","KALIMANTAN TIMUR");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("A3","BUMD PROVINSI KALIMANTAN TIMUR");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("F2","R A H A S I A");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("F3","REG. NOMOR 7");
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('B4:E4');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('B37:E37');
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("G24"," DATA ABSENSI");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("G25"," Hari Kerja");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("G26"," Sakit");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("G27"," Ijin");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("G28"," Alpa");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("G29"," HAK CUTI");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("G30"," Cuti");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("G31"," Sisa Cuti");
// Untuk mengisi data kehadiran
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("H25"," 24");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("H26"," 0");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("H27"," 0");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("H28"," 0");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("H30"," 0");
$objPHPExcel->setActiveSheetIndex(0)->setCellValue("h31"," 12");
$objPHPExcel->getActiveSheet()->getStyle('H25:H31')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$objPHPExcel->getActiveSheet()->getStyle('F14:H21')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$objPHPExcel->getActiveSheet()->getStyle('G24:H31')->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('B4:E4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('696e72');
$objPHPExcel->getActiveSheet()->getStyle('G24:H24')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('696e72');
$objPHPExcel->getActiveSheet()->getStyle('G29:H29')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('696e72');
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('F2')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('B4')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('B37')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('B4')->getFont()->setSize(14);
$objPHPExcel->getActiveSheet()->getStyle('B37')->getFont()->setSize(14);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(16);
$objPHPExcel->getActiveSheet()->getStyle('A34')->getFont()->setSize(16);

$objPHPExcel->getActiveSheet()->getStyle('A2:H65')->getFont()->SetName('Calibri');
$objPHPExcel->getActiveSheet()->getStyle('F2')->getFont()->setSize(14);
$objPHPExcel->getActiveSheet()->getStyle('F2')->getFont()->SetName('Candara');
$objPHPExcel->getActiveSheet()->getStyle('F35')->getFont()->SetName('Candara');

$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth("30");
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth("2");
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth("40");
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth("30");
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth("2");
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth("15");
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth("12");
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth("12");

$objPHPExcel->getActiveSheet()->getStyle('F2:H3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F35:F36')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4:E4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A37:E37')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4:E4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('#000000');
$objPHPExcel->getActiveSheet()->getStyle('A37:E37')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('#000000');
$objPHPExcel->getActiveSheet()->getStyle('A6:H6')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('A11:H11')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('A13:H13')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('A22:H22')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
//$objPHPExcel->getActiveSheet()->getStyle('A39:H39')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
//$objPHPExcel->getActiveSheet()->getStyle('A44:H44')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
//$objPHPExcel->getActiveSheet()->getStyle('A46:H46')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
//$objPHPExcel->getActiveSheet()->getStyle('A55:H55')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('A6:A11')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('D6:D11')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('H6:H11')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('A13:A22')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('D13:D22')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('H13:H22')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
//$objPHPExcel->getActiveSheet()->getStyle('A39:A44')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
//$objPHPExcel->getActiveSheet()->getStyle('D39:D44')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
//$objPHPExcel->getActiveSheet()->getStyle('H39:H44')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
//$objPHPExcel->getActiveSheet()->getStyle('A46:A55')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
//$objPHPExcel->getActiveSheet()->getStyle('D46:D55')->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
//$objPHPExcel->getActiveSheet()->getStyle('H46:H55')->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);


$objPHPExcel->setActiveSheetIndex(0)->setCellValue("B4","SLIP GAJI BULAN $des $tahun");
//$objPHPExcel->setActiveSheetIndex(0)->setCellValue("B37","SLIP GAJI BULAN DESEMBER 2021");
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A6", ' N I K')
            ->setCellValue("B6", ':')
            ->setCellValue("C6", "'".$register['no_id'])
            ->setCellValue("A7", ' N a m a')
            ->setCellValue("B7", ':')
            ->setCellValue("C7", $register['nama'])
            ->setCellValue("A8", ' Jabatan')
            ->setCellValue("B8", ':')
            ->setCellValue("C8", $register['jabatan'])
      			->setCellValue("A9", ' Grade')
            ->setCellValue("B9", ':')
            ->setCellValue("C9", "13")
      			->setCellValue("A10", ' Tanggal Masuk')
            ->setCellValue("B10", ':')
            ->setCellValue("C10", date('d-m-Y',strtotime($register['tgl_terima'])))
            ->setCellValue("A11", ' Status')
            ->setCellValue("B11", ':')
            ->setCellValue("C11", 'K/3')
            ->setCellValue("A13", ' PENGHASILAN')
      			->setCellValue("A14", ' Gaji Pokok')
            ->setCellValue("B14", ':')
            ->setCellValue("C14", number_format($register['gapok']))
            ->setCellValue("A15", ' Tunjangan Jabatan')
            ->setCellValue("B15", ':')
            ->setCellValue("C15", number_format($register['t_jabatan']))
            ->setCellValue("A16", ' Tunjangan Kesejahteraan')
            ->setCellValue("B16", ':')
            ->setCellValue("C16", number_format($register['t_kesejahteraan']))
            ->setCellValue("A17", ' Tunjangan Kinerja')
            ->setCellValue("B17", ':')
            ->setCellValue("C17", number_format($register['t_kinerja']))
            ->setCellValue("A18", ' Tunjangan Makan')
            ->setCellValue("B18", ':')
            ->setCellValue("C18", number_format($register['t_makan']))
            ->setCellValue("A19", ' Tunjangan Komunikasi')
            ->setCellValue("B19", ':')
            ->setCellValue("C19", number_format($register['t_komunikasi']))
            ->setCellValue("A21", ' PENGHASILAN KOTOR')
            ->setCellValue("C21", number_format($total))
            ->setCellValue("D6", ' Masa Kerja')
            ->setCellValue("E6", ':')
            ->setCellValue("F6", '10 Tahun 3 Bulan')
            ->setCellValue("D7", ' Tgl Terbit Hak Cuti')
            ->setCellValue("E7", ':')
            ->setCellValue("F7", '22-Jan-2022')
            ->setCellValue("D8", ' Jatuh Tempo Hak Cuti')
            ->setCellValue("E8", ':')
            ->setCellValue("F8", '22-Jan-2023')
      			->setCellValue("D9", ' Bank')
            ->setCellValue("E9", ':')
            ->setCellValue("F9", 'Bank BCA')
      			->setCellValue("D10", ' No. Rekening')
      			->setCellValue("E10", ':')
            ->setCellValue("F10", '7815158911')
            ->setCellValue("A13", ' POTONGAN')
      			->setCellValue("D14", ' Pinjaman Karyawan')
            ->setCellValue("E14", ':')
            ->setCellValue("F14", '0')
            ->setCellValue("D15", ' Keterlambatan')
            ->setCellValue("E15", ':')
            ->setCellValue("F15", '0')
            ->setCellValue("D16", ' BAZIS 2.5%')
            ->setCellValue("E16", ':')
            ->setCellValue("F16", '0')
            ->setCellValue("D21", ' PENGHASILAN BERSIH')
            ->setCellValue("E21", ':')
            ->setCellValue("F21", $total)
      			->setCellValue("A23", 'Keterangan')
      			->setCellValue("A24", 'Dikeluarkan di')
      			->setCellValue("A25", 'Pada Tanggal')
            ->setCellValue("A25", 'Dibuat Oleh,')
      			->setCellValue("B24", ':')
      			->setCellValue("B25", ':')
            ->setCellValue("C24", 'Samarinda')
      			->setCellValue("C25", '24 Desember 2021')
            ->setCellValue("A30", 'ADI FAHRIZAL PUTRA')
      			->setCellValue("A31", 'Staff SDM')
      			->setCellValue("D26", 'Penerima,')
    		    ->setCellValue("D30", 'ARI NUGROHO WIBISONO')
            ->setCellValue("D31", 'Manajer Usaha Hulu');

$objPHPExcel->getActiveSheet()
                ->getStyle('C14:C21')
                ->getAlignment()
                ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);

//$objDrawing = new PHPExcel_Worksheet_Drawing();
//$objDrawing1 = new PHPExcel_Worksheet_Drawing();

//$objDrawing->setPath('../../images/icon.png');
//$objDrawing->setImageResource('https://pbmtla-gorontalo.com/e-pbm/images/icon.png');
//$objDrawing->setCoordinates('A2');
//$objDrawing->setOffsetX(40);
//$objDrawing->setHeight(60);
//$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());

//$objDrawing1->setPath('temp/'.$isi.'.png');
//$objDrawing1->setCoordinates('G2');
//$objDrawing1->setHeight(74);
//$objDrawing1->setOffsetX(100);
//$objDrawing1->setWorksheet($objPHPExcel->getActiveSheet());

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="dn.html"');
header('Cache-Control: max-age=0');
//$inputFileName = 'dn.xls';
//$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
//$objWriter=PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel2007');
$objWriter=PHPExcel_IOFactory::createWriter($objPHPExcel,'HTML');
//$objWriter = new PHPExcel_Writer_HTML($objPHPExcel);
//$objWriter->save('dn.htm');
$objWriter->save('php://output');
//include 'dn.html';
unlink('temp/'.$isi.'.png');
exit;
?>
