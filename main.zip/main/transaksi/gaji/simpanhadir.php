<?php
session_start();
include '../../koneksi.php';

$nik = $_POST['no_id'];
$nama = $_POST['nama'];
$tahun = $_POST['tahun'];
$bulan = $_POST['bulan'];
$hadir = $_POST['hadir'];
$sakit = $_POST['sakit'];
$ijin = $_POST['ijin'];
$alpa = $_POST['alpa'];
$row = mysql_num_rows(mysqli_query($conn,"SELECT * FROM gaji_transaksi WHERE no_id='$nik' and bulan='$bulan' and tahun='$tahun'"));
if ($row > 0){
		$text = "update gaji_transaksi set ijin = '$ijin',
																			 hadir = '$hadir',
																			 sakit = '$sakit',
                                       alpa = '$alpa'
																			 where no_id = '$nik' and tahun='$kode' and bulan='$bulan'";
		mysqli_query($conn,$text);
	  echo "Data Gaji untuk $nik bulan: $bulan dan tahun: $kode tersimpan";
}

?>
