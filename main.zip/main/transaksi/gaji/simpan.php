<?php
session_start();
include '../../koneksi.php';

$kode = $_POST['kode'];
$bulan = $_POST['bulan'];
$tanggal = date('Y-m-d');
$t_kesejahteraan = $_POST['t_kesejahteraan'];
$t_komunikasi = $_POST['t_komunikasi'];
	$row = mysqli_query($conn,"SELECT * FROM karyawan_induk WHERE aktif='Y'");
	while($data=mysqli_fetch_array($row))
	{
		$nik = $data['no_id'];
		$nama = $data['nama'];
		$dgaji = mysqli_fetch_array(mysqli_query($conn,"select * from gaji_master where no_id='$nik'"));
    $gapok = $dgaji['gapok'];
    $tkesej = $dgaji['t_kesejahteraan'];
    $tkom = $dgaji['t_komunikasi'];
    $tmakan = $dgaji['t_makan'];
    $tkinerja = $dgaji['t_kinerja'];
    $tjabatan = $dgaji['t_jabatan'];
		$t_transport = $dgaji['t_transport'];
		$t_cuti = $dgaji['t_cuti'];
		$t_hariraya = $dgaji['t_cuti'];
		$t_lain = $dgaji['t_lain'];
		$notrans = substr($data['no_id'],-6).'/SLY-MMP/'.date('mY');
		$text = "insert into gaji_transaksi set no_id = '$nik',
																			 tahun='$kode',
                                       bulan='$bulan',
																			 tanggal='$tanggal',
																			 gapok = '$gapok',
																			 t_kesejahteraan = '$tkesej',
																			 t_komunikasi = '$tkom',
                                       t_makan = '$tmakan',
                                       t_kinerja = '$tkinerja',
                                       t_jabatan = '$tjabatan',
																			 t_transport = '$t_transport',
																			 t_hariraya = '$t_transport',
																			 t_cuti = '$t_cuti',
																			 t_lain = '$t_lain',
																			 notrans = '$notrans'";
		mysqli_query($conn,$text);
	  echo "Data Gaji bulan: $bulan dan tahun: $kode tersimpan";
}

?>
