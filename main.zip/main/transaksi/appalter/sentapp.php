<?php
session_start();
include '../../koneksi1.php';
$noref = $_POST['noref'];
$noinv = $_POST['noinv'];
$nilai = $_POST['nilai'];
$username = $_SESSION['username'];

$sql = "SELECT * FROM operator WHERE username = '$username'";
$data = mysql_fetch_array(mysql_query($sql));
$limitapp = $data['lapp'];
$row = mysql_num_rows(mysql_query("SELECT * FROM inv_alter WHERE noref ='$noref'"));
if ($limitapp >= $nilai ){
	if($row>0){
		$text = "UPDATE inv_alter set cek='Y',approvedby ='$username' WHERE noref='$noref'";
		mysql_query($text);
		$text1 = "update inv_master set invalter = invalter + '$nilai' where notrans = '$noinv'";
		mysql_query($text1);
		echo "Approval Sukses";
	}

}else{
		echo "Tidak bisa Approval untuk $noref karena limit anda lebih kecil";
	}
?>
