<?php
include '../../koneksi1.php';
$kode = $_POST['id'];
$sql = "SELECT * FROM invalter WHERE noref='$kode'";
$row = mysql_num_rows(mysql_query($sql));
$data = mysql_fetch_array(mysql_query($sql));
$nilai = $data['nilai'];
$noinv = $data['noinv'];
if($row>0){
	$text = "update invalter set cek='N' WHERE noref='$kode'";
	mysql_query($text);
	$text1 = "update postinv set reinv = 0 where noinv = '$noinv'";
	mysql_query($text1);
	echo "Cancel Sukses Sukses";

}else{
	echo "Tidak ada data yang dihapus $kode";
}
?>