

<script type="text/javascript">
var url;
function createalter(){
	$('#dialog-alter').dialog('open').dialog('setTitle','Print Alteration Per Periode');
	$('#tanggal1').textbox('setValue', '');
	$('#tanggal2').textbox('setValue', '');
}

function savealter(){
	var noref = $("#noref").val();
	var string = $("#form-excel").serialize();
	if(noinv.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, No Referensi tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#noref").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/appalter/sentapp.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}
function cancelalter(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.cek == 'Y'){
		$.messager.confirm('Confirm','Yakin akan membatalkan approval ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/appalter/hapus.php",
					data	: 'id='+row.noref,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}
}

function posting(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.posting =='N'){
		$.messager.confirm('Confirm','Yakin akan memposting data ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/appalter/posting.php",
					data	: 'id='+row.noref,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
				$.messager.show({
							title:'Info',
							msg:"Data sudah diposting",
							timeout:2000,
							showType:'slide'
				});
			}
}
function appform(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row.cek == 'S'){
		$('#dialog-excel').dialog('open').dialog('setTitle','Approval Form');
		$('#form-excel').form('load',row);
	}else{
			$.messager.show({
			title:'Info',
			msg:'Maaf, tidak bisa di Approval karena status bukan S',
			timeout:2000,
			showType:'slide'
		});
	}
}
function fresh(){
	$('#datagrid-crud').datagrid('reload');
}
function doSearch(){
	$('#datagrid-crud').datagrid('load',{
        cabang: $('#cabang').val(),
		cari: $('#cari').val()
    });
}

$(function(){
        $('#form-alter').form(
        {
            url:'transaksi/appalter/excelapp.php',
            success:function(data){
                if(data)//check if data returned
                {
                alert('yes');
                }}
            }
        )
    })
</script>
</head>
<body onload="doSearch()">


	<div style="margin:10px 0;"></div>

	<table id="datagrid-crud" title="Invoice Alteration" class="easyui-datagrid" style="width:auto; height: auto;" url="transaksi/appalter/json.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
			<th data-options="field:'noref',width:15" >No Transaksi</th>
            <th data-options="field:'tanggal',width:8" sortable="true">Tanggal</th>
            <th data-options="field:'keu_code',width:8" hidden="true">Keu Code</th>
			<th data-options="field:'keterangan',width:17">Keterangan</th>
            <th data-options="field:'nilai',width:10" align="right">Nilai</th>
			<th data-options="field:'noinv',width:15">No Invoice</th>
            <th data-options="field:'customer',width:25">Customer</th>
            <th data-options="field:'invcode',width:15" hidden="true">Inv Code</th>
			<th data-options="field:'cek',width:5">Status</th>
			<th data-options="field:'posting',width:5">Posting</th>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px">
		<div style="float:left;">
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" plain="true" onclick="cancelalter()">Cancel Approval</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" plain="true" onclick="appform()">Approval</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-file-excel-o fa-lg" plain="true" onclick="createalter()">Print To Excel</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-refresh fa-lg" plain="true" onclick="fresh()">Refresh</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-bookmark-o fa-lg" plain="true" onclick="posting()">Posting</a>
		</div>
		<div style="float:right;">
        	Pencarian <input id="cari" class="easyui-searchbox" data-options="prompt:'No. Trans ../Tanggal (YYYY-MM-DD)..',searcher:doSearch" style="width:250px"></input>
			<input type="hidden" name="cabang" id="cabang" value="<?php echo $_SESSION['cabang']?>"/>
		</div>
	</div>

<div id="dialog-excel" class="easyui-dialog" style="width:400px; height:350px; padding: 10px 20px" closed="true" buttons="#btn-excel">
	<form id="form-excel" method="post" novalidate>
		<div class="form-item">
			<label for="tanggal">Tanggal</label><br/>
			<input type="text" name="tanggal" id="tanggal" class="easyui-textbox" required="true" size="20" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="noref">No Transaksi</label><br/>
			<input type="text" name="noref" id="noref" class="easyui-textbox" style="width:100%" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="noinv">noinv</label><br />
			<input type="text" name="noinv" id="noinv" class="easyui-textbox" required="true" style="width:100%" data-options="multiline:true"/>
			<input type="hidden" name="username" id="username" value="<?php echo $_SESSION['username']?>"/>
			<input type="hidden" name="cabang" id="cabang" value="<?php echo $_SESSION['cabang']?>"/>
		</div>
		<div class="form-item">
			<label for="nilai">Nilai</label><br/>
			<input type="text" name="nilai" id="nilai" class="easyui-textbox" style="width:100%" maxlength="20" />
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="btn-excel">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" onclick="savealter()">Approve</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-excel').dialog('close')">Batal</a>
</div>
<div id="dialog-alter" class="easyui-dialog" style="width:400px; height:200px; padding: 10px 20px" closed="true" buttons="#btn-alter">
	<form id="form-alter" method="post" novalidate>
		<div class="form-item">
			<label for="tanggal">Tanggal Awal / Tanggal Akhir</label><br/>
			<input type="text" name="tanggal1" id="tanggal1" class="easyui-datebox" required="true" style="width:50%" maxlength="20" />
			<input type="text" name="tanggal2" id="tanggal2" class="easyui-datebox" required="true" style="width:49%" maxlength="20" />
			<input type="hidden" name="username" id="username" value="<?php echo $_SESSION['username']?>"/>
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="btn-alter">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" onclick="$('#form-alter').submit();">Print</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-alter').dialog('close')">Batal</a>
</div>
</body>
