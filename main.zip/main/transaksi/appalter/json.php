<?php
include '../../koneksi1.php';

$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
$rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'cek';
$order = isset($_POST['order']) ? strval($_POST['order']) : 'asc';
$cari = isset($_POST['cari']) ? mysql_real_escape_string($_POST['cari']) : '';
$cabang = isset($_POST['cabang']) ? mysql_real_escape_string($_POST['cabang']) : '';

$offset = ($page-1) * $rows;

$where = " WHERE noref LIKE '%$cari%' or tanggal like '%$cari%' or cek like '%$cari%'";

$text = "SELECT * FROM inv_alter
	$where
	ORDER BY  $sort $order, tanggal desc
	LIMIT $rows OFFSET $offset";

$result = array();
$result['total'] = mysql_num_rows(mysql_query("SELECT * FROM inv_alter limit 200"));
$row = array();

$criteria = mysql_query($text);
while($data=mysql_fetch_array($criteria))
{
	$row[] = array(
		'noref'=>$data['noref'],
        'deskripsi'=>$data['deskripsi'],
        'noinv'=>$data['noinv'],
        'nilai'=>$data['nilai'],
		'tanggal'=>$data['tanggal'],
		'keterangan'=>$data['keterangan'],
		'keu_code'=>$data['keu_code'],
		'invcode'=>$data['invcode'],
		'customer'=>$data['customer'],
		'cek'=>$data['cek'],
		'posting'=>$data['posting'],
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
?>
