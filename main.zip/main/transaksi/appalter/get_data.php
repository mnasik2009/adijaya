<?php
include '../../koneksi1.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';  
  
$arr_data=array();
$sql="select postinv.nilai,postinv.noinv,(postinv.nilai - (postinv.bayar + postinv.reinv)) as total, 
        mcustomer.nama,mcustomer.keu_code,kegiatan.remarks from postinv,mcustomer,invoice,kegiatan
        where postinv.noinv=invoice.noinvoice and invoice.customer=mcustomer.kode and left(invoice.keterangan,6) = kegiatan.kode 
        and (nilai - bayar - reinv) > 0
        and kegiatan.tipe = 'Invoice'
        and noinv like '%$q%' limit 20";
$result = mysql_query($sql);
while($obj = mysql_fetch_object($result)) {
 $arr_data[]=array("noinv"=>$obj->noinv,"nama"=>$obj->nama,"nilai"=>$obj->nilai,"total"=>$obj->total,
 "keu_code"=>$obj->keu_code,"invcode"=>$obj->remarks);
}

echo json_encode($arr_data);
?>
