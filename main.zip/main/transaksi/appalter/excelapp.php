<?php
include '../../koneksi1.php';
include '../../Classes/PHPExcel.php';
include '../../terbilang.php';
	
 $tanggal1 = $_POST['tanggal1'];
 $tanggal2 = $_POST['tanggal2'];
 $username = $_POST['username'];
 $tgl=date('d-m-Y H:i:s');

 $format1 = date('Y-m-d', strtotime($tanggal1));
 $format2 = date('Y-m-d', strtotime($tanggal2));

 $sql = "select * from invalter where tanggal >='$format1' and tanggal <= '$format2'";
 
 $result = mysql_query ($sql) or die (mysql_error ());
 $register = mysql_num_rows ($result);

$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:I1');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A2:I2');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A3:I3');
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A5:J5')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
$objPHPExcel->getActiveSheet()->getStyle('A2')->getFont()->setSize(16);
$objPHPExcel->getActiveSheet()->getStyle('A5:J5')->getFont()->setSize(12);

$objPHPExcel->getActiveSheet()->getStyle('A1:J1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A2:J2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A3:J3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A5:J5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A5:I5')->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
$objPHPExcel->getActiveSheet()->getStyle('C')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('F')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$objPHPExcel->getActiveSheet()->getStyle('G')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$objPHPExcel->getActiveSheet()->getStyle('H')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$objPHPExcel->getActiveSheet()->getStyle('I')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
$objPHPExcel->getActiveSheet()->getStyle('A5:I5')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFE8E5E5');

 
 $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A1", 'REKAP INVOICE ALTERTION')
            ->setCellValue("A2", "TANGGAL : " .$format1. "  S/D : " .$format2. "")
			
 
            ->setCellValue("A5", 'No')
            ->setCellValue("B5", 'No. Ref')
            ->setCellValue("C5", 'Tanggal')			
            ->setCellValue("D5", 'No. Invoice')
			->setCellValue("E5", 'Customer')
   			->setCellValue("F5", 'Nilai')
 			->setCellValue("G5", 'Keterangan')
 			->setCellValue("H5", 'Created By')
			->setCellValue("I5", 'Approved By');

   $i = 6;    
   $m = 1;
   while ($register = mysql_fetch_array ($result)) {
        
   $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A$i", "{$m}")
            ->setCellValue("B$i", "{$register['noref']}")
            ->setCellValue("C$i", "{$register['tanggal']}")
			->setCellValue("D$i", "{$register['noinv']}")
			->setCellValue("E$i", "{$register['customer']}")
			->setCellValue("F$i", "{$register['nilai']}")
			->setCellValue("G$i", "{$register['keterangan']}")
			->setCellValue("H$i", "{$register['userid']}")
			->setCellValue("I$i", "{$register['approvedby']}");
			$objPHPExcel->getActiveSheet()->getStyle("F$i")->getNumberFormat()->setFormatCode('#,##.00');			
		$objPHPExcel->getActiveSheet()->getStyle("A$i:I$i")->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
			
      $i++;
      $m++;
   }

	for($col = 'A'; $col !== 'J'; $col++) {
		$objPHPExcel->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
	}
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	header('Content-Disposition: attachment;filename="alteration.xlsx"');
	header('Cache-Control: max-age=0');
$objWriter=PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel2007');
$objWriter->save('php://output');
exit;

?>