<?php
include '../../koneksi1.php';

$username = $_POST['username'];
$tanggal = $_POST['tanggal'];
$noinv = $_POST['noinv'];
$noref = $_POST['noref'];
$keterangan = $_POST['keterangan'];
$customer = $_POST['customer'];
$nilai = $_POST['nilai'];
$keu_code = $_POST['keu_code'];
$invcode = $_POST['invcode'];
$cabang = $_POST['cabang'];

$tahun = $format = date('Y', strtotime($tanggal));
$bulan = $format = date('m', strtotime($tanggal));
$format1 = date('Y-m-d', strtotime($tanggal));
$bb = $format = date('y', strtotime($tanggal));
$tglinput = date('d/m/Y');
$nomor = mysql_query("select substr(max(noref),-9) as noref from inv_alter where year(tanggal)='$tahun' and month(tanggal)='$bulan'");

$data1 = mysql_fetch_array($nomor);
$idMax = $data1['noref'];
$idMax++;
$newID = 'ALT-' .$tahun .$bulan . sprintf('%09d',$idMax);
$ifbkk = 'AL.'. sprintf('%04d',$idMax). '/' .$bulan . $bb;

$row = mysql_num_rows(mysql_query("SELECT * FROM inv_alter WHERE noref='$noref'"));
if($row>0){
	$text = "UPDATE inv_alter SET noinv = '$noinv',
								tanggal = '$format1',
								tglinput = '$tglinput',
								keterangan = '$keterangan',
								customer = '$customer',
                                nilai = '$nilai',
                                keu_code = '$keu_code',
								invcode = '$invcode',
								keterangan = '$keterangan'
								WHERE noref='$noref'";
	mysql_query($text);
	echo "Update Sukses";
}else{
    $text = "INSERT INTO inv_alter (noref,tanggal,noinv,tglinput,userid,keterangan,customer,nilai,keu_code,invcode,ifalter,approvedby,cek)
			VALUES ('$newID','$format1','$noinv','$tglinput','$username','$keterangan','$customer','$nilai','$keu_code','$invcode','$ifbkk','','N')";
	mysql_query($text);
	echo "Simpan Sukses " .$newID;
}
?>
