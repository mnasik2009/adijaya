<?php
include '../../koneksi1.php';
$kode = $_POST['id'];
$row = mysql_num_rows(mysql_query("SELECT * FROM invalter WHERE noref='$kode'"));
$tgl = date('d/m/Y h:i:s');
$global = mysql_query("select * from globalset");
$result = mysql_fetch_array($global);
$kodept = $result['kode_fin'];
if($row > 0){
	$text = "SELECT * FROM invalter WHERE noref ='$kode'";
	$master1 = mysql_fetch_array(mysql_query($text));
	$notransaksi = $master1['noref'];
    $nojurnal = $master1['ifalter'];
    $tanggal = date('d/m/Y',strtotime($master1['tanggal']));
    //$if_code = $master1['invcode'];
		$if_code = '1118003';
    $if_code1 = $master1['keu_code'];
    $keterangan = $master1['keterangan'];
    $kredit = $master1['nilai'];
    $insert1 = "insert into if_finance set
               nojurnal = '$nojurnal',
               kodept = '$kodept',
               tanggal = '$tanggal',
               remarks1 ='Null',
               notransaksi = '$notransaksi',
               userid = 'Admin',
               tglinput = '$tgl',
               if_code = '$if_code',
               keterangan = '$keterangan',
               debet = '$kredit',
               kredit = 0,
               remarks2 ='Null',
               ref = '001',
               trf='N'";
    mysql_query($insert1);

    $insert2 = "insert into if_finance set
                nojurnal = '$nojurnal',
                kodept = '$kodept',
                tanggal = '$tanggal',
                remarks1 ='Null',
                notransaksi = '$notransaksi',
                userid = 'Admin',
                tglinput = '$tgl',
                if_code = '$if_code1',
                keterangan = '$keterangan',
                debet = 0,
                kredit = '$kredit',
                remarks2 ='Null',
                ref = '001',
                trf='N'";
    mysql_query($insert2);
    mysql_query("update invalter set posting='Y' where noref='$kode'");
    echo "Posting Sukses";

}else{
	echo "Tidak bisa diposting karena $kode ada yang kurang lengkap";
}
?>
