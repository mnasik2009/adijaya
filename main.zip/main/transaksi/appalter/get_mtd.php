<?php
include '../../koneksi1.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';  
  
$arr_data=array();
$sql="SELECT * from mtdbayar where tanda='I' or tanda='K' and kode like '%$q%'";
$result = mysql_query($sql);
while($obj = mysql_fetch_object($result)) {
 $arr_data[]=array("kode"=>$obj->kode,"nama"=>$obj->nama,"if_code"=>$obj->if_code);
}

echo json_encode($arr_data);
?>
