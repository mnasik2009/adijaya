<?php
session_start();
include '../../koneksi.php';

$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
$rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'tgltrans';
$order = isset($_POST['order']) ? strval($_POST['order']) : 'desc';
$cari = isset($_POST['cari']) ? mysql_real_escape_string($_POST['cari']) : '';
$cabang = $_SESSION['cabang'];

$offset = ($page-1) * $rows;

$where = " WHERE cabang='$cabang' and (notrans LIKE '%$cari%' OR pocust LIKE '%$cari%') ";

$text = "SELECT * FROM pc_master
	$where
	ORDER BY $sort $order
	LIMIT $rows OFFSET $offset";

$result = array();
$result['total'] = mysql_num_rows(mysql_query("SELECT * FROM pc_master $where"));
$row = array();

$criteria = mysql_query($text);
while($data=mysql_fetch_array($criteria))
{
	$total = $data['harga'] + ($data['harga'] + $data['ppn']) / 100 + ($data['harga'] + $data['pph']) / 100 + ($data['harga'] + $data['pbbkb']) / 100;
	$tharga = $total * $data['jumlah'] + $data['oat'] * $data['jumlah'];
	$row[] = array(
		'notrans'=>$data['notrans'],
		'tgltrans'=>$data['tgltrans'],
		'kodesupp'=>$data['kodesupp'],
		'lokasi'=>$data['lokasi'],
		'validto'=>$data['validto'],
		'jenisbbm'=>$data['jenisbbm'],
    	'uom'=>$data['uom'],
		'harga'=>$data['harga'],
		'total'=>number_format($tharga,2),
		'top'=>$data['top'],
		'lewat'=>$data['lewat'],
		'ppn'=>$data['ppn'],
		'pbbkb'=>$data['pbbkb'],
		'oat'=>$data['oat'],
		'cofrom'=>$data['cofrom'],
		'approval'=>$data['approval'],
		'spoint'=>$data['remarks'],
		'jumlah'=>$data['jumlah'],
		'pocust'=>$data['pocust'],
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
?>
