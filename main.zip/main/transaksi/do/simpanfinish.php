<?php
session_start();
include '../../koneksi.php';

$userid = $_SESSION['username'];
$tgltrans = date('Y-m-d',strtotime($_POST['tgltrans']));
$notrans = $_POST['notrans'];
$loses = $_POST['loses'];
$totaloses = $_POST['totaloses'];
$ntoleransi = $_POST['ntoleransi'];
$keterangan = $_POST['keterangan'];
$potongan = $_POST['potongan'];

$row = mysql_num_rows(mysql_query("SELECT * FROM do_master WHERE notrans='$notrans'"));
if($row>0){
	$text = "UPDATE do_master SET tglselesai='$tgltrans',
	 							loses='$loses',
								totaloses='$totaloses',
								ntoleransi='$ntoleransi',
								potongan='$potongan',
								keterangan = '$keterangan',
								selesai = 'Y'
			WHERE notrans='$notrans'";
	mysql_query($text);
	echo "Update Sukses $notrans";
}
?>
