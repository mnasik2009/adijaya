<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Surat Jalan</title>
    <link rel="stylesheet" type="text/css" href="../js/themes/metrogreen/easyui.css">
    <link rel="stylesheet" type="text/css" href="../js/themes/mobile.css">
    <link rel="stylesheet" type="text/css" href="../js/themes/icon.css">
    <script type="text/javascript" src="../js/jquery.min.js"></script>
    <script type="text/javascript" src="../js/jquery.easyui.min.js"></script>
    <script type="text/javascript" src="../js/jquery.easyui.mobile.js"></script>
<script type="text/javascript">
var url;
function hapus(){
	$('#nocontainer').textbox('setValue', '');
	$('#nojoa').textbox('setValue', '');
	$('#size').textbox('setValue', '');
	$('#tipe').textbox('setValue', '');
	$('#status').textbox('setValue', '');
	$('#remark').textbox('setValue', '');
	$('#tanggal').textbox('setValue', '');
}

$(function(){
    $('#notrans').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_mdo.php?',
				idField:'notrans',
				textField:'notrans',
				mode:'remote',
				fitColumns:true,
			    columns:[[
  			    {field:'notrans',title:'notrans',width:24},
  			    {field:'noplat',title:'noplat',width:20},
  			    {field:'nmsopir',title:'nmsopir',width:20},
    				{field:'tgltrans',title:'tgltrans',width:20},
			    ]],onClickRow:function(rowData){
			             var val =$('#notrans').combogrid('grid').datagrid('getSelected');
											 $('#notrans').textbox('setValue', val.notrans);
											 $('#tanggal').textbox('setValue', val.tgltrans);
											 $('#noplat').textbox('setValue', val.noplat);
											 $('#nmsopir').textbox('setValue', val.nmsopir);
			                                }
						});
		});
function simpansj(){
    	var notrans = $("#notrans").val();
    	var string = $("#ff").serialize();
    	if(tgltrans.length==0){
    		$.messager.show({
    			title:'Info',
    			msg:'Maaf, notrans tidak boleh kosong',
    			timeout:2000,
    			showType:'slide'
    		});
    		$("#notrans").focus();
    		return false();
    	}

    	$.ajax({
    		type	: "POST",
    		url		: "transaksi/do/simpansj.php",
    		data	: string,
    		success	: function(data){
    			$.messager.show({
    				title:'Info',
    				msg:data, //'Password Tidak Boleh Kosong.',
    				timeout:2000,
    				showType:'slide'
    			});
    		}
    	});
}

</script>
</head>
<body>
    <div class="easyui-navpanel" style="position:relative;padding:20px">
        <header>
            <div class="m-toolbar">
                <div class="m-title">Surat Jalan</div>
            </div>
        </header>
        <br/>
        <form id="ff" method="post" action="transaksi/do/simpansj.php">
            <div style="margin-bottom:10px">
                <input class="easyui-textbox" id="notrans"  name="notrans" label="No. Transaksi" data-options="editable:false,panelWidth:220,panelHeight:240,iconWidth:30" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input class="easyui-textbox"  id="tanggal"  name="tanggal" label="Tanggal" style="width:100%">
            </div>

            <div style="margin-bottom:10px">
                <input class="easyui-textbox"id="noplat"  name="noplat"  label="No. Plat" prompt="No. Plat" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input class="easyui-numberbox" id="nmsopir"  name="nmsopir" label="Nama Sopir" prompt="Nama Sopir" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input class="easyui-datebox" id="tglselesai"  name="tglselesai" label="Tgl Selesai"  style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input class="easyui-textbox" id="keterangan"  name="keterangan" label="Keterangan" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input class="easyui-filebox" id="dok1"  name="dok1" label="Dokumen Pendukung" style="width:100%">
                <input class="easyui-textbox" id="userid"  name="userid" value="<?php echo $username ?>" type="hidden">
            </div>
		<footer>
            <div style="text-align:center;margin-top:30px">
				<button type="submit" class="easyui-linkbutton" style="width:100%;height:40px" <span style="font-size:16px">Save Data</span></button>
            </div>
        </footer>
        </form>
    </div>
</html>
