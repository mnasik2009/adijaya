<script type="text/javascript">
var url;
function create(){
	$('#dialog-form').dialog('open').dialog('setTitle','Tambah Data');
	$('#form').form('clear');
}
function save(){
	var notrans = $("#notrans").val();
	var string = $("#form").serialize();
	if(tgltrans.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, notrans tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#notrans").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/do/simpan.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function simpand(){
	var notrans = $("#notrans").val();
	var string = $("#form-detail").serialize();
	if(tgltrans.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, notrans tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#notrans").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/do/simpand.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function savedo(){
	var notrans = $("#notrans").val();
	var string = $("#form-do").serialize();
	if(tgltrans.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, notrans tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#notrans").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/do/simpando.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function lihatdetail(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-lihat').dialog('open').dialog('setTitle','View Detail');
		$('#form3').form('load',row);
		doSearch1();
	}
}

function doSearch1(){
	$('#data1-crud').datagrid('load',{
				notrans: $('#test2').val()
    });
}
function hapus(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.sia == 'N'){
		$.messager.confirm('Confirm','Apakah Anda akan menghapus data ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/do/hapus.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dihapus, krn sudah di Approve',
		timeout:2000,
		showType:'slide'
	});
	}
}

function hapuslagi(){
	var row = $('#data1-crud').datagrid('getSelected');
	if (row){
		$.messager.confirm('Confirm','Apakah Anda akan menghapus data ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/do/hapuslagi.php",
					data	: 'id='+row.idnumber,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#data1-crud').datagrid('reload');
					}
				});
			}
		});
	}
}

function proforma(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.pinv == 'N'){
		$.messager.confirm('Confirm','Apakah Anda akan Membuat Proforma Invoice : '+row.notrans+' ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/do/proforma.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dibuat Proforma, krn sudah di Pernah Dibuat',
		timeout:2000,
		showType:'slide'
		});
	}
}

function buatdo(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.sisa > 0){
		$('#dialog-do').dialog('open').dialog('setTitle','Create DO');
		$('#form-do').form('load',row);
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dicreate DO, krn sudah di Pernah Dibuat',
		timeout:2000,
		showType:'slide'
	});
	}
}

function update(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-form').dialog('open').dialog('setTitle','Edit Data');
		$('#form').form('load',row);
	}
}

function cetak(){
	var row = $('#datagrid-crud').datagrid('getSelected');
		$('#dialog-excel').dialog('open').dialog('setTitle','Cetak Data');
		$('#form-excel').form('load',row);

}

function detail(){
	var row = $('#datagrid-crud').datagrid('getSelected');
		$('#dialog-detail').dialog('open').dialog('setTitle','Tambah Data Detail');
		$('#form-detail').form('load',row);

}

function fresh(){
	$('#datagrid-crud').datagrid('reload');
}
function doSearch(value){
	$('#datagrid-crud').datagrid('load',{
        cari: value
    });
}

$(function(){
    $('#kodecust').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_cust.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
					{field:'nohp',title:'nohp'},
			    ]],onClickRow:function(rowData){
			                 var val =$('#kodecust').combogrid('grid').datagrid('getSelected');
											 $('#kodecust').textbox('setValue', val.kode);
			                                }
						});
	$('#mitra').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_mitra.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
				{field:'nohp',title:'nohp'},
			    ]],onClickRow:function(rowData){
			                 var val =$('#mitra').combogrid('grid').datagrid('getSelected');
									$('#mitra').textbox('setValue', val.kode);
									$('#nama').textbox('setValue', val.nama);
			                  }
						});
	$('#jenisbbm').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_bbm.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'keterangan',title:'keterangan'},
		    ]],onClickRow:function(rowData){
		                 var val =$('#jenisbbm').combogrid('grid').datagrid('getSelected');
										 $('#jenisbbm').textbox('setValue', val.kode);
		             }
			});
	$('#cofrom').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_pt.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    	columns:[[
		    {field:'kode',title:'kode'},
		    {field:'nama',title:'nama'},
		    {field:'alamat',title:'alamat'},
				{field:'kota',title:'kota'},
	    ]],onClickRow:function(rowData){
	                var val =$('#cofrom').combogrid('grid').datagrid('getSelected');
								 $('#cofrom').textbox('setValue', val.kode);
	          }
				});
  $('#spoint').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_spoint.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    	columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
				{field:'pic',title:'pic'},
	    		]],onClickRow:function(rowData){
	              var val =$('#spoint').combogrid('grid').datagrid('getSelected');
								 $('#spoint').textbox('setValue', val.kode);
	          }
			});
  $('#noplat').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_mobil.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    	columns:[[
			    {field:'kode',title:'kode'},
			    {field:'noplat',title:'noplat'},
			    {field:'namasopir',title:'namasopir'},
	    		]],onClickRow:function(rowData){
	              var val =$('#noplat').combogrid('grid').datagrid('getSelected');
				  		$('#noplat').textbox('setValue', val.noplat);
				  		$('#nmsopir').textbox('setValue', val.namasopir);
	          }
			});
  $('#noqtn').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_qtn.php?',
			idField:'notrans',
			textField:'notrans',
			mode:'remote',
			fitColumns:true,
	    	columns:[[
			    {field:'notrans',title:'notrans'},
			    {field:'tgltrans',title:'tgltrans'},
			    {field:'kodecust',title:'kodecust'},
					{field:'nama',title:'nama'},
					{field:'jenisbbm',title:'jenisbbm'},
					{field:'harga',title:'harga'},
					{field:'ppn',title:'ppn'},
					{field:'pbbkb',title:'pbbkb'},
					{field:'top',title:'top'},
					{field:'oat',title:'oat'},
					{field:'cofrom',title:'cofrom'},
					{field:'validto',title:'validto'},
	    		]],onClickRow:function(rowData){
	              	var val =$('#noqtn').combogrid('grid').datagrid('getSelected');
									$('#noqtn').textbox('setValue', val.notrans);
									$('#kodecust').textbox('setValue', val.kodecust);
									$('#jenisbbm').textbox('setValue', val.jenisbbm);
									$('#harga').textbox('setValue', val.harga);
									$('#ppn').textbox('setValue', val.ppn);
									$('#pbbkb').textbox('setValue', val.pbbkb);
									$('#top').textbox('setValue', val.top);
									$('#oat').textbox('setValue', val.oat);
									$('#cofrom').textbox('setValue',val.cofrom);
									$('#validto').textbox('setValue',val.validto);
	          }
			});
$('#nopo').combogrid({
	panelWidth:600,
	url: 'transaksi/_get/get_nopo1.php?',
	idField:'notrans',
	textField:'notrans',
	mode:'remote',
	fitColumns:true,
	columns:[[
				{field:'notrans',title:'notrans'},
				{field:'tgltrans',title:'tgltrans'},
				{field:'jenisbbm',title:'jenisbbm'},
				{field:'harga',title:'harga'},
				{field:'jumlah',title:'jumlah'},
				{field:'ketpo',title:'nopo'},
							]],onClickRow:function(rowData){
											var val =$('#nopo').combogrid('grid').datagrid('getSelected');
											$('#nopo').textbox('setValue', val.notrans);
											$('#jenisbbm').textbox('setValue', val.jenisbbm);
											$('#harga').textbox('setValue', val.harga);
											$('#jumlahso').textbox('setValue', val.jumlah);
											$('#ketpo').textbox('setValue', val.ketpo);
								}
					});
$('#kodetjn').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_tarif.php?',
			idField:'kodetjn',
			textField:'kodetjn',
			mode:'remote',
			fitColumns:true,
			columns:[[
				{field:'kodetjn',title:'kode'},
				{field:'nama',title:'nama'},
				{field:'tarif',title:'tarif'},
				{field:'tarifsopir',title:'tarifsopir'},
				{field:'solar',title:'solar'},
									]],onClickRow:function(rowData){
													var val =$('#kodetjn').combogrid('grid').datagrid('getSelected');
													$('#kodetjn').textbox('setValue', val.kodetjn);
													$('#tarif').textbox('setValue', val.tarif);
													$('#tarifsopir').textbox('setValue', val.tarifsopir);
						}
		});
	});
</script>
</head>
<body>

	<div style="margin:10px 0;"></div>

	<table id="datagrid-crud" title="Sales Order" class="easyui-datagrid" style="width:auto; height: auto;" url="transaksi/do/json.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
            <th data-options="field:'notrans'" sortable="true">No Trans </th>
            <th data-options="field:'kodecust'" sortable="true">Customer </th>
            <th data-options="field:'tgltrans'">Tanggal</th>
            <th data-options="field:'validto'">Berlaku</th>
            <th data-options="field:'jenisbbm'">BBM</th>
			<th data-options="field:'jumlah'">Jumlah</th>
			<th data-options="field:'harga'">Harga</th>
			<th data-options="field:'ppn'">PPN</th>
			<th data-options="field:'pbbkb'">PBBKB</th>
			<th data-options="field:'oat'">OAT</th>
			<th data-options="field:'top'">TOP</th>
            <th data-options="field:'cofrom'">CO From</th>
			<th data-options="field:'noqtn'">Quotation#</th>
			<th data-options="field:'createdo'">DO</th>
			<th data-options="field:'jumlahdo'">Jumlah DO</th>
			<th data-options="field:'sisa'">Sisa</th>
			<th data-options="field:'pinv'">Proforma</th>
			<th data-options="field:'nopinv'">No. Proforma</th>
        </tr>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px;">
		<div style="float:left;">
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-plus-square-o fa-lg" plain="true" onclick="create()">Tambah</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-pencil-square-o fa-lg" plain="true" onclick="update()">Edit</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-minus-square-o fa-lg" plain="true" onclick="hapus()">Hapus</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-hdd-o fa-lg" plain="true" onclick="detail()">Add Detail</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-bars fa-lg" plain="true" onclick="lihatdetail()">View Detail</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-truck fa-lg" plain="true" onclick="buatdo()">Create DO</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" plain="true" onclick="cetak()">Print</a>
      <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-refresh fa-lg" plain="true" onclick="fresh()">Refresh</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-money fa-lg" plain="true" onclick="proforma()">Proforma Invoice</a>
		</div>
		<div style="float:right;">
        	Pencarian <input id="cari" class="easyui-searchbox" data-options="prompt:'Cari notrans / kodecust..',searcher:doSearch" style="width:200px"></input>
		</div>
	</div>

<!-- Dialog Form -->
<div id="dialog-form" class="easyui-dialog" style="width:600px; height:700px; padding: 10px 20px" closed="true" buttons="#dialog-buttons">
	<form id="form" method="post" novalidate>
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Quotation</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="noqtn" id="noqtn" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Customer &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Valid To</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="validto" id="validto" class="easyui-textbox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="validto">Jenis BBM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Jumlah (Liter) &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Harga</label><br />
			<input type="text" name="jenisbbm" id="jenisbbm" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="jumlah" id="jumlah" class="easyui-textbox" disabled="disabled" required="true" style="width:30%"/>
			<input type="text" name="harga" id="harga" class="easyui-textbox" required="true" style="width:38%"/>
		</div>
		<div class="form-item">
			<label for="jenisbbm">PPN (%) &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PBBKB (%)&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; OAT</label><br />
			<input type="text" name="ppn" id="ppn" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="pbbkb" id="pbbkb" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="oat" id="oat" class="easyui-textbox" required="true" style="width:38%"/>
		</div>
		<div class="form-item">
			<label for="top">Term Of payment</label><br />
			<input type="text" name="top" id="top" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
    <div class="form-item">
			<label for="cofrom">CO From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="lewat">No. Transaksi</label><br />
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="dialog-buttons">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" onclick="save()">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-form').dialog('close')">Batal</a>
</div>


<!-- Pencetakan ke Printer -->
<div id="dialog-excel" class="easyui-dialog" style="width:600px; height:300px; padding: 10px 20px" closed="true" buttons="#dialog-btn">
	<form id="form-excel" method="post" action="transaksi/do/cetak.php" target="_blank">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Customer &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Valid To</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="validto" id="validto" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="cofrom">CO From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="dialog-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" onclick="$('#form-excel').submit();">Cetak</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-excel').dialog('close')">Batal</a>
</div>

<div id="dialog-do" class="easyui-dialog" style="width:600px; height:525px; padding: 10px 20px" closed="true" buttons="#dialog-btn">
	<form id="form-do" method="post" action="transaksi/do/simpando.php">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="cofrom">CO From&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Jenis & Jumlah</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="jenisbbm" id="jenisbbm" class="easyui-textbox" required="true" style="width:24%"/>
			<input type="text" name="jumlah" id="jumlah" class="easyui-textbox" required="true" style="width:25%"/>
		</div>
		<div class="form-item">
			<label for="tgltrans">Customer &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Valid To</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="validto" id="validto" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="kodetjn">Tujuan</label><br />
			<input type="text" name="kodetjn" id="kodetjn" class="easyui-textbox" required="true" prompt="Tujuan" style="width:30%"/>
			<input type="text" name="tarif" id="tarif" class="easyui-textbox" required="true" prompt="Tarif" style="width:33%"/>
			<input type="text" name="tarifsopir" id="tarifsopir" class="easyui-textbox" required="true" prompt="Gaji Sopir" style="width:35%"/>
		</div>
		<div class="form-item">
			<label for="noplat">Jenis Armada</label><br />
			<input type="text" name="angkutan" id="angkutan" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="lewat" id="lewat" class="easyui-textbox" required="true" prompt="Via/Lewat" style="width:49%"/>
		</div>
		<!--div class="form-item">
			<label for="noplat">No Plat</label><br />
			<input type="text" name="noplat" id="noplat" class="easyui-textbox" required="true" prompt="No. Plat" style="width:40%"/>
			<input type="text" name="nmsopir" id="nmsopir" class="easyui-textbox" required="true" prompt="Nama Driver" style="width:59%"/>
		</div>
		<div class="form-item">
			<label for="mitra">Transportir</label><br />
			<input type="text" name="mitra" id="mitra" class="easyui-textbox" required="true" prompt="Transportir" style="width:50%"/>
			<input type="text" name="nama" id="nama" class="easyui-textbox" required="true" prompt="Nama Transportir" style="width:49%"/>
		</div-->

	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="dialog-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-save fa-lg" onclick="savedo();">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-do').dialog('close')">Batal</a>
</div>


<!-- Add Detail -->
<div id="dialog-detail" class="easyui-dialog" style="width:500px; height:400px; padding: 10px 20px" closed="true" buttons="#dialog-dtl">
	<form id="form-detail" method="post">
		<div class="form-item">
			<label for="type">No Transaksi</label><br />
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:79%"/>
			<input type="text" name="idnumber" id="idnumber" class="easyui-textbox" style="width:20%"/>
		</div>
		<div class="form-item">
			<label for="tgltrans">NO Purchase Order</label><br />
			<input type="text" name="nopo" id="nopo" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="tgltrans">Jenis BBM</label><br />
			<input type="text" name="jenisbbm" id="jenisbbm" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="jumlah">Jumlah</label><br />
			<input type="text" name="jumlahso" id="jumlahso" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="ketpo">No. PO Cust</label><br />
			<input type="text" name="ketpo" id="ketpo" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="dialog-dtl">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" onclick="simpand();">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-detail').dialog('close')">Batal</a>
</div>

<!-- Lihat Detail -->
<div id="dialog-lihat" class="easyui-dialog" style="width:800px; height:500px;padding: 10x 20px" closed="true" buttons="#dg-btn1">
<form id="form3">
	<table id="data1-crud" class="easyui-datagrid" style="width:auto; height:450;" singleSelect="true" url="transaksi/do/jsondetail.php" rownumbers="true" toolbar="#ta1" fitColumns="true" >
    <thead>
        <tr>
			<th data-options="field:'notrans'" sortable="true">No Transaksi</th>
			<th data-options="field:'jenisbbm'" sortable="true">Jenis BBM</th>
			<th data-options="field:'jumlahso'" sortable="true">Jumlah</th>
			<th data-options="field:'nopo'" sortable="true">PO Number</th>
			<th data-options="field:'idnumber'" sortable="true">ID#</th>
        </tr>
    </thead>
	</table>
</form>
    <div id="ta1" style="padding:2px;height:30px">
	<form id="detail1" method="post" action="#" novalidate>
		<div style="float:left;">
            No Trans <input type="text" id="test2" name="notrans" class="easyui-textbox"  style="width:250px"></input>
		</div>
		<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-search" plain="true" onclick="doSearch1()">Cari Data</a>
		<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-remove" plain="true" onclick="hapuslagi()">Hapus Data</a>
	</form>
	</div>
</div>
<div id="dg-btn1">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" onclick="javascript:jQuery('#dialog-lihat').dialog('close')">Batal</a>
</div>
</body>
