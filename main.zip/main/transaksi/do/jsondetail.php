<?php
include '../../koneksi.php';

$notrans = $_POST['notrans']; 
$offset = ($page-1) * $rows;

$text = "select * from so_detail where notrans='$notrans'";

$result = array();
$result['total'] = mysql_num_rows(mysql_query("select * from so_detail where notrans='$notrans'"));
$row = array();

$criteria = mysql_query($text);
while($data=mysql_fetch_array($criteria))
{	
	$row[] = array(
		'notrans'=>$data['notrans'],
		'jenisbbm'=>$data['jenisbbm'],
		'jumlahso'=>$data['jumlah'],
		'nopo'=>$data['nopo'],
		'idnumber'=>$data['idnumber'],
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
  
?>