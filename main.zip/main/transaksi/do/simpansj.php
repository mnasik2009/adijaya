<?php
session_start();
include '../../koneksi.php';

$userid = $_SESSION['username'];
$tglselesai = date('Y-m-d',strtotime($_POST['tglselesai']));
$notrans = $_POST['notrans'];
$keterangan = $_POST['keterangan'];
$noplat = $_POST['noplat'];
$nmsopir = $_POST['nmsopir'];
$namadok = basename($_FILES['dok1']['name']);
//$namadok = $dok1['name'];
move_uploaded_file($_FILES['dok1']['tmp_name'], 'temp/'.$namadok);

$row = mysql_num_rows(mysql_query("SELECT * FROM do_master WHERE notrans='$notrans'"));
if($row>0){
	$text = "UPDATE do_master SET tglselesai='$tglselesai',
	 							keterangan='$keterangan', selesai = 'Y',
								dokumen = '$namadok' WHERE notrans='$notrans'";
	mysql_query($text);
	echo "Simpan Sukses $notrans";
}
?>
