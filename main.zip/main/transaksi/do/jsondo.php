<?php
session_start();
include '../../koneksi.php';

$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
$rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'tgltrans';
$order = isset($_POST['order']) ? strval($_POST['order']) : 'desc';
$cari = isset($_POST['cari']) ? mysql_real_escape_string($_POST['cari']) : '';
$cabang = $_SESSION['cabang'];

$offset = ($page-1) * $rows;

$where = " WHERE cabang='$cabang' and (notrans LIKE '%$cari%' OR noplat LIKE '%$cari%') ";

$text = "SELECT * FROM do_master
	$where
	ORDER BY $sort $order
	LIMIT $rows OFFSET $offset";

$result = array();
$result['total'] = mysql_num_rows(mysql_query("SELECT * FROM do_master $where"));
$row = array();

$criteria = mysql_query($text);
while($data=mysql_fetch_array($criteria))
{
	$kodetjn = $data['kodetjn'];
    $tj = mysql_fetch_array(mysql_query("select * from tarif where kode='$kodetjn'"));
	$row[] = array(
		'notrans'=>$data['notrans'],
		'tgltrans'=>date('m/d/Y',strtotime($data['tgltrans'])),
		'kodecust'=>$data['kodecust'],
		'validto'=>date('m/d/Y',strtotime($data['validto'])),
		'noplat'=>$data['noplat'],
    	'nmsopir'=>$data['nmsopir'],
		'mitra'=>$data['mitra'],
		'nama'=>$data['nama'],
		'angkutan'=>$data['angkutan'],
		'lewat'=>$data['lewat'],
		'cofrom'=>$data['cofrom'],
		'selesai'=>$data['selesai'],
		'kodetjn'=>$data['kodetjn'],
		'namatjn'=>$tj['nama'],
		'tarif'=>$data['tarif'],
        'tarifsopir'=>$data['tarifsopir'],
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
?>
