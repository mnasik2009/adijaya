<html>
<head>
	<meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../../easyui/themes/material/easyui.css">
    <link rel="stylesheet" type="text/css" href="../../easyui/themes/icon.css">
    <script type="text/javascript" src="../../easyui/jquery.min.js"></script>
    <script type="text/javascript" src="../../easyui/jquery.easyui.min.js"></script>
<?php
//koneksi ke database, username,password  dan namadatabase menyesuaikan
include "../../koneksi.php";
//memanggil file excel_reader
$kode = $_GET['kode'];
$data = mysql_fetch_array(mysql_query("select * from do_master where notrans='$kode'"));
$dok1 = 'images/'.$data['dok1'];
$dok2 = 'images/'.$data['dok2'];
$dok3 = 'images/'.$data['dok3'];
$dok4 = 'images/'.$data['dok4'];
$nama = $data['kodesupp'];
?>
<body>
    <div id="p" class="easyui-panel" title="Import Data" style="width:575px;height:500px;padding:10px;">
    <form name="myForm" id="myForm" method="post" action="aksi.php" enctype="multipart/form-data">
		<div class="form-item">
			<label for="notrans">Kode</label>
			<input type="text" name="nomor" id="nomor" value="<?php echo $kode; ?>" class="easyui-textbox" disabled="disabled" required="true"style="width:100%"/>
		</div>
		<div style="margin-bottom:20px">
				<input id="nama" name="nama" class="easyui-textbox" label="Nama" labelPosition="top" value="<?php echo $nama; ?>" disabled="disabled" style="width:100%">
		</div>
		<div style="margin-bottom:20px">
				<?php echo "Dokumen 1"; ?><br/>
                <img src="<?php echo $dok1; ?>" alt="Dokumen" width="400">
		</div>
		<div style="margin-bottom:20px">
                <?php echo "Dokumen 2"; ?><br/>
                <img src="<?php echo $dok2; ?>" alt="Dokumen" width="400">
        </div>
		<div style="margin-bottom:20px">
				<?php echo "Dokumen 3"; ?><br/>
                <img src="<?php echo $dok3; ?>" alt="Dokumen" width="400">
		</div>
		<div style="margin-bottom:20px">
                <?php echo "Dokumen 4"; ?><br/>
                <img src="<?php echo $dok4; ?>" alt="Dokumen" width="400">
        </div>
		<br/>
		<input type="submit" name="submit" value="Upload" /><br/>

	</form>
    </div>
</body>
<script type="text/javascript">
//    validasi form (hanya file .xls yang diijinkan)
    function validateForm()
    {
        function hasExtension(inputID, exts) {
            var fileName = document.getElementById(inputID).value;
            return (new RegExp('(' + exts.join('|').replace(/\./g, '\\.') + ')$')).test(fileName);
        }

        if(!hasExtension('namafile', ['.png','.jpg'])){
            alert("Hanya file XLS (Excel 2003) yang diijinkan.");
            return false;
        }
    }
</script>
</html>
