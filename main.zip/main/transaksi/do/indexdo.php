<script type="text/javascript">
var url;
function create(){
	$('#dialog-form').dialog('open').dialog('setTitle','Tambah Data');
	$('#form').form('clear');
}
function save(){
	var notrans = $("#notrans").val();
	var string = $("#form").serialize();
	if(tgltrans.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, notrans tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#notrans").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/do/simpan.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function savedo(){
	var notrans = $("#notrans").val();
	var string = $("#form-do").serialize();
	if(tgltrans.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, notrans tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#notrans").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/do/simpando.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}
function hapus(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.selesai == 'N'){
		$.messager.confirm('Confirm','Apakah Anda akan menghapus data ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/do/hapusdo.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dihapus, krn sudah di Approve',
		timeout:2000,
		showType:'slide'
	});
	}
}

function update(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-do').dialog('open').dialog('setTitle','Edit Data DO');
		$('#form-do').form('load',row);
	}
}

function selesai(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row.selesai == 'N'){
		$('#dialog-finish').dialog('open').dialog('setTitle','Penyelesaian DO');
		$('#form-finish').form('load',row);
	}else{
			$.messager.show({
			title:'Info',
			msg:'Data tidak bisa diselesaikan, krn sudah di Selesai',
			timeout:2000,
			showType:'slide'
		});
	}
}

function completed(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row.selesai == 'Y'){
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa diselesaikan, krn sudah di Selesai',
		timeout:2000,
		showType:'slide'
	});
	}else{
		$.ajax({
			type	: "POST",
			url		: "transaksi/do/selesai.php",
			data	: 'id='+row.notrans,
			success	: function(data){
				$.messager.show({
					title:'Info',
					msg:data, //'Password Tidak Boleh Kosong.',
					timeout:2000,
					showType:'slide'
				});
				$('#datagrid-crud').datagrid('reload');
			}
		});
	}
}

function cetak(){
	var row = $('#datagrid-crud').datagrid('getSelected');
		$('#dialog-excel').dialog('open').dialog('setTitle','Cetak Data');
		$('#form-excel').form('load',row);

}

function fresh(){
	$('#datagrid-crud').datagrid('reload');
}
function doSearch(value){
	$('#datagrid-crud').datagrid('load',{
        cari: value
    });
}

$(function(){
	$('#mitra').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_spoint.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
				{field:'nohp',title:'nohp'},
			    ]],onClickRow:function(rowData){
			                 var val =$('#mitra').combogrid('grid').datagrid('getSelected');
									$('#mitra').textbox('setValue', val.kode);
									$('#nama').textbox('setValue', val.nama);
			                  }
						});
	$('#transport').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_transport.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'pic',title:'pic'},
			    ]],onClickRow:function(rowData){
			                 var val =$('#transport').combogrid('grid').datagrid('getSelected');
									$('#transport').textbox('setValue', val.kode);
									$('#namatransport').textbox('setValue', val.nama);
			                  }
						});
	$('#cofrom').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_pt.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    	columns:[[
		    {field:'kode',title:'kode'},
		    {field:'nama',title:'nama'},
		    {field:'alamat',title:'alamat'},
				{field:'kota',title:'kota'},
	    ]],onClickRow:function(rowData){
	                var val =$('#cofrom').combogrid('grid').datagrid('getSelected');
								 $('#cofrom').textbox('setValue', val.kode);
	          }
				});
  $('#noplat').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_mobil.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    	columns:[[
			    {field:'kode',title:'kode'},
			    {field:'noplat',title:'noplat'},
			    {field:'namasopir',title:'namasopir'},
	    		]],onClickRow:function(rowData){
	              var val =$('#noplat').combogrid('grid').datagrid('getSelected');
				  		$('#noplat').textbox('setValue', val.noplat);
				  		$('#nmsopir').textbox('setValue', val.namasopir);
	          }
			});
	$('#kodetjn').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_tarif.php?',
			idField:'kodetjn',
			textField:'kodetjn',
			mode:'remote',
			fitColumns:true,
			columns:[[
						{field:'kodetjn',title:'kode'},
						{field:'nama',title:'nama'},
						{field:'tarif',title:'tarif'},
						{field:'tarifsopir',title:'tarifsopir'},
									]],onClickRow:function(rowData){
												var val =$('#kodetjn').combogrid('grid').datagrid('getSelected');
														$('#kodetjn').textbox('setValue', val.kodetjn);
														$('#tarif').textbox('setValue', val.tarif);
														$('#tarifsopir').textbox('setValue', val.tarifsopir);
							}
					});
	});
</script>
</head>
<body>

	<div style="margin:10px 0;"></div>

	<table id="datagrid-crud" title="Delivery Order" class="easyui-datagrid" style="width:auto; height: auto;" url="transaksi/do/jsondo.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
            <th data-options="field:'notrans'" sortable="true">No Trans </th>
            <th data-options="field:'kodecust'" sortable="true">Customer </th>
            <th data-options="field:'tgltrans'">Tanggal</th>
            <th data-options="field:'validto'">Berlaku</th>
            <th data-options="field:'noplat'">No Plat</th>
            <th data-options="field:'nmsopir'">Nama Sopir</th>
            <th data-options="field:'mitra'">Supply Point</th>
            <th data-options="field:'nama'">Nama S.Point</th>
            <th data-options="field:'angkutan'">Angkutan</th>
            <th data-options="field:'lewat'">Via</th>
            <th data-options="field:'cofrom'">CO From</th>
            <th data-options="field:'kodetjn'">Tujuan</th>
            <th data-options="field:'namatjn'">Nama Tujuan</th>
			<th data-options="field:'tarif'" hidden="true"></th>
			<th data-options="field:'tarifsopir'" hidden="true"></th>
            <th data-options="field:'loses'">Loses</th>
            <th data-options="field:'totaloses'">T. Loses</th>
            <th data-options="field:'potongan'">Potongan</th>
            <th data-options="field:'ntoleransi'">Toleransi</th>
            <th data-options="field:'keterangan'">Keterangan</th>
            <th data-options="field:'selesai'">Selesai</th>
        </tr>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px;">
		<div style="float:left;">
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-pencil-square-o fa-lg" plain="true" onclick="update()">Edit</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-minus-square-o fa-lg" plain="true" onclick="hapus()">Hapus</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-cloud-upload fa-lg" plain="true"
				onclick="javascript:wincal=window.open('transaksi/do/aksi.php?kode='+$('#datagrid-crud').datagrid('getSelected').notrans
			,'popuppage','width=600,toolbar=0,resizable=0,scrollbars=yes,height=550,top=100,left=100');">Upload Dok</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-picture-o fa-lg" plain="true"
				onclick="javascript:wincal=window.open('transaksi/do/lihat.php?kode='+$('#datagrid-crud').datagrid('getSelected').notrans
			,'popuppage','width=600,toolbar=0,resizable=0,scrollbars=yes,height=550,top=100,left=100');">View Dok</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-check-square-o fa-lg" plain="true" onclick="selesai()">Selesai</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-sign-out fa-lg" plain="true" onclick="completed()">Completed</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" plain="true" onclick="cetak()">Print</a>
            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-refresh fa-lg" plain="true" onclick="fresh()">Refresh</a>
		</div>
		<div style="float:right;">
        	Pencarian <input id="cari" class="easyui-searchbox" data-options="prompt:'Cari notrans / kodecust..',searcher:doSearch" style="width:200px"></input>
		</div>
	</div>


<!-- Pencetakan ke Printer -->
<div id="dialog-excel" class="easyui-dialog" style="width:600px; height:300px; padding: 10px 20px" closed="true" buttons="#dialog-btn">
	<form id="form-excel" method="post" action="transaksi/do/cetak.php" target="_blank">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Customer &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Shipment Date</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="validto" id="validto" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="cofrom">CO From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="dialog-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" onclick="$('#form-excel').submit();">Cetak</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-excel').dialog('close')">Batal</a>
</div>

<div id="dialog-do" class="easyui-dialog" style="width:600px; height:560px; padding: 10px 20px" closed="true" buttons="#dialog-btn">
	<form id="form-do" method="post" action="transaksi/do/simpando.php">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="cofrom">CO From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="tgltrans">Customer &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Shipment Date</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="validto" id="validto" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="noplat">No Plat</label><br />
			<input type="text" name="noplat" id="noplat" class="easyui-textbox" required="true" prompt="No. Plat" style="width:40%"/>
			<input type="text" name="nmsopir" id="nmsopir" class="easyui-textbox" required="true" prompt="Nama Driver" style="width:59%"/>
		</div>
		<div class="form-item">
			<label for="noplat">Jenis Armada</label><br />
			<input type="text" name="angkutan" id="angkutan" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="lewat" id="lewat" class="easyui-textbox" required="true" prompt="Via/Lewat" style="width:49%"/>
		</div>
		<div class="form-item">
			<label for="noplat">Angkutan</label><br />
			<input type="text" name="transport" id="transport" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="namatransport" id="namatransport" class="easyui-textbox" required="true" prompt="Via/Lewat" style="width:49%"/>
		</div>
		<div class="form-item">
			<label for="mitra">Supply Point</label><br />
			<input type="text" name="mitra" id="mitra" class="easyui-textbox" required="true" prompt="Supply Point" style="width:50%"/>
			<input type="text" name="nama" id="nama" class="easyui-textbox" required="true" prompt="Nama S.Point" style="width:49%"/>
		</div>
		<div class="form-item">
			<label for="mitra">Tujuan</label><br />
			<input type="text" name="kodetjn" id="kodetjn" class="easyui-textbox" required="true" prompt="Tujuan" style="width:30%"/>
			<input type="text" name="tarif" id="tarif" class="easyui-textbox" required="true" prompt="Tarif" style="width:35%"/>
			<input type="text" name="tarifsopir" id="tarifsopir" class="easyui-textbox" required="true" prompt="Gaji Sopir" style="width:34%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="dialog-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-save fa-lg" onclick="savedo();">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-do').dialog('close')">Batal</a>
</div>

<!-- Penyelesaian DO -->
<div id="dialog-finish" class="easyui-dialog" style="width:500px; height:425px; padding: 10px 20px" closed="true" buttons="#btn-finish">
	<form id="form-finish" method="post" action="transaksi/do/simpanfinish.php">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="cofrom">Nilai Toleransi</label><br />
			<input type="text" name="ntoleransi" id="ntoleransi" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="tgltrans">Loses &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Total Loses</label><br />
			<input type="text" name="loses" id="loses" class="easyui-textbox" required="true" style="width:49%"/>
			<input type="text" name="totaloses" id="totaloses" class="easyui-textbox" required="true" style="width:50%"/>
		</div>
		<div class="form-item">
			<label for="potongan">Potongan</label><br />
			<input type="text" name="potongan" id="potongan" class="easyui-textbox" required="true" prompt="Potongan" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="mitra">Keterangan</label><br />
			<input type="text" name="Keterangan" id="Keterangan" class="easyui-textbox" required="true" prompt="Keterangan" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="btn-finish">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-save fa-lg" onclick="savedo();">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-finish').dialog('close')">Batal</a>
</div>
</body>
