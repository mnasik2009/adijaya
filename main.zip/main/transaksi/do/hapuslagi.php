<?php
include '../../koneksi.php';
$idnumber = $_POST['id'];
$row = mysql_num_rows(mysql_query("SELECT * FROM so_detail WHERE idnumber='$idnumber'"));
if($row>0){
	$text = "DELETE FROM so_detail
			WHERE idnumber='$idnumber'";
	mysql_query($text);
	echo "Hapus Detail Sukses";
}else{
	echo "Tidak ada data yang dihapus";
}
?>
