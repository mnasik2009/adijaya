<?php
session_start();
include '../../koneksi.php';

$tgltrans = date('Y-m-d',strtotime($_POST['tgltrans']));
$notrans = $_POST['notrans'];
$nopo = $_POST['nopo'];
$jenisbbm = $_POST['jenisbbm'];
$jumlah = $_POST['jumlahso'];
$idnumber = $_POST['idnumber'];

$row = mysql_num_rows(mysql_query("SELECT * FROM so_detail WHERE idnumber='$idnumber'"));
if($row>0){
	$text = "UPDATE so_detail SET jenisbbm='$jenisbbm',
								jumlah='$jumlah',
								nopo='$nopo'
			WHERE idnumber='$idnumber'";
	mysql_query($text);
	echo "Update Sukses $notrans";
}else{
	$text = "INSERT INTO so_detail SET notrans='$notrans',
								jenisbbm='$jenisbbm',
								jumlah='$jumlah',
								nopo='$nopo'";
	mysql_query($text);
	echo "Simpan Detail Sukses $notrans";
}
?>
