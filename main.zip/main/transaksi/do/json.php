<?php
session_start();
include '../../koneksi.php';

$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
$rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'tgltrans';
$order = isset($_POST['order']) ? strval($_POST['order']) : 'desc';
$cari = isset($_POST['cari']) ? mysql_real_escape_string($_POST['cari']) : '';
$cabang = $_SESSION['cabang'];

$offset = ($page-1) * $rows;

$where = " WHERE cabang='$cabang' and (notrans LIKE '%$cari%' OR kodecust LIKE '%$cari%') ";

$text = "SELECT * FROM so_master
	$where
	ORDER BY $sort $order
	LIMIT $rows OFFSET $offset";

$result = array();
$result['total'] = mysql_num_rows(mysql_query("SELECT * FROM so_master $where"));
$row = array();

$criteria = mysql_query($text);
while($data=mysql_fetch_array($criteria))
{
	$sisa = $data['jumlah'] - $data['jumlahdo'];
	$row[] = array(
		'notrans'=>$data['notrans'],
		'tgltrans'=>$data['tgltrans'],
		'kodecust'=>$data['kodecust'],
		'lokasi'=>$data['lokasi'],
		'validto'=>$data['validto'],
		'jenisbbm'=>$data['jenisbbm'],
    'jumlah'=>$data['jumlah'],
		'harga'=>$data['harga'],
		'top'=>$data['top'],
		'ppn'=>$data['ppn'],
		'pbbkb'=>$data['pbbkb'],
		'oat'=>$data['oat'],
		'cofrom'=>$data['cofrom'],
		'noqtn'=>$data['noqtn'],
		'createdo'=>$data['createdo'],
		'jumlahdo'=>$data['jumlahdo'],
		'pinv'=>$data['pinv'],
		'nopinv'=>$data['nopinv'],
		'sisa'=>$sisa,
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
?>
