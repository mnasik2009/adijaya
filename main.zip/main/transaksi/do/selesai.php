<?php
include '../../koneksi.php';
$notrans = $_POST['id'];
$row = mysql_num_rows(mysql_query("SELECT * FROM do_master WHERE notrans='$notrans'"));
if($row>0){
	$text = "UPDATE do_master set selesai='Y'
			WHERE notrans='$notrans'";
	mysql_query($text);
	echo "Completed Sukses";
}else{
	echo "Tidak ada data yang dicompleted $notrans";
}
?>
