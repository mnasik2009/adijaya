<html>
<head>
	<meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../../easyui/themes/material/easyui.css">
    <link rel="stylesheet" type="text/css" href="../../easyui/themes/icon.css">
    <script type="text/javascript" src="../../easyui/jquery.min.js"></script>
    <script type="text/javascript" src="../../easyui/jquery.easyui.min.js"></script>
<?php
//koneksi ke database, username,password  dan namadatabase menyesuaikan
include "../../koneksi.php";
//memanggil file excel_reader
$kode = $_GET['kode'];
if(isset($_POST['submit'])){
$kode = $_POST['nomor'];
$dok1 = basename($_FILES['dok1']['name']) ;
move_uploaded_file($_FILES['dok1']['tmp_name'], 'images/'.$dok1);
$dok2 = basename($_FILES['dok2']['name']) ;
move_uploaded_file($_FILES['dok2']['tmp_name'], 'images/'.$dok2);
$dok3 = basename($_FILES['dok3']['name']) ;
move_uploaded_file($_FILES['dok3']['tmp_name'], 'images/'.$dok3);
$dok4 = basename($_FILES['dok4']['name']) ;
move_uploaded_file($_FILES['dok4']['tmp_name'], 'images/'.$dok4);
$tglinput = date('Y-m-d');

$query = "update do_master set dok1 = '$dok1', dok2='$dok2', dok3='$dok3', dok4='$dok4' where notrans='$kode'";
$hasil = mysql_query($query);

if(!$hasil){
//          jika import gagal
    die(mysql_error());
}else{
//          jika impor berhasil
   echo "Data berhasil diimpor.";
}
}
?>
<body>
    <div id="p" class="easyui-panel" title="Import Data" style="width:575px;height:500px;padding:10px;">
    <form name="myForm" id="myForm" method="post" action="aksi.php" enctype="multipart/form-data">
		<div class="form-item">
			<label for="notrans">Kode</label>
			<input type="text" name="nomor" id="nomor" value="<?php echo $kode; ?>" class="easyui-textbox" required="true"style="width:100%"/>
		</div>
		<div style="margin-bottom:20px">
				<input id="dok1" name="dok1" class="easyui-filebox" label="Dokumen 1" labelPosition="top" data-options="prompt:'Choose a file...'" style="width:100%">
		</div>
		<div style="margin-bottom:20px">
				<input id="dok2" name="dok2" class="easyui-filebox" label="Dokumen 2" labelPosition="top" data-options="prompt:'Choose a file...'" style="width:100%">
		</div>
		<div style="margin-bottom:20px">
				<input id="dok3" name="dok3" class="easyui-filebox" label="Dokumen 3" labelPosition="top" data-options="prompt:'Choose a file...'" style="width:100%">
		</div>
		<div style="margin-bottom:20px">
				<input id="dok4" name="dok4" class="easyui-filebox" label="Dokumen 4" labelPosition="top" data-options="prompt:'Choose a file...'" style="width:100%">
		</div>
		<br/>
		<input type="submit" name="submit" value="Upload" /><br/>

	</form>
    </div>
</body>
<script type="text/javascript">
//    validasi form (hanya file .xls yang diijinkan)
    function validateForm()
    {
        function hasExtension(inputID, exts) {
            var fileName = document.getElementById(inputID).value;
            return (new RegExp('(' + exts.join('|').replace(/\./g, '\\.') + ')$')).test(fileName);
        }

        if(!hasExtension('namafile', ['.xls'])){
            alert("Hanya file XLS (Excel 2003) yang diijinkan.");
            return false;
        }
    }
</script>
</html>
