<?php
error_reporting(0);
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';

$arr_data=array();
$sql="select * from master_sopir where jenis='Driver' and (kode like '%$q%' or nama like '%$q%') limit 10";
$result = mysql_query($sql);
while($obj = mysql_fetch_object($result)) {
 $arr_data[]=array("kode"=>$obj->kode,"namasopir"=>$obj->nama);
}

echo json_encode($arr_data);
?>
