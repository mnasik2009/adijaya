<?php
session_start();
error_reporting(0);
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';
$platno = $_SESSION['platno'];
$arr_data=array();
$sql="select * from do_master where selesai='N' and (notrans like '%$q%' or noplat like '%$q%')";
$result = mysql_query($sql);
while($obj = mysql_fetch_array($result)) {
  $arr_data[]=array(
   'notrans'=>$obj['notrans'],
   'tgltrans'=>$obj['tgltrans'],
   'nmsopir'=>$obj['nmsopir'],
   'noplat'=>$obj['noplat'],
 );
}

echo json_encode($arr_data);
?>
