<?php
error_reporting(0);
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';

$arr_data=array();
$sql="select * from spoint where kode like '%$q%' or nama like '%$q%'";
$result = mysql_query($sql);
while($obj = mysql_fetch_object($result)) {
 $arr_data[]=array("kode"=>$obj->kode,"nama"=>$obj->nama,"alamat"=>$obj->lokasi,"pic"=>$obj->pic);
}

echo json_encode($arr_data);
?>
