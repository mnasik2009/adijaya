<?php
error_reporting(0);
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';

$arr_data=array();
$sql="select * from vehicle where kode like '%$q%' or noplat like '%$q%'";
$result = mysql_query($sql);
while($obj = mysql_fetch_object($result)) {
 $arr_data[]=array("kode"=>$obj->kode,"namasopir"=>$obj->namasopir,"noplat"=>$obj->noplat);
}

echo json_encode($arr_data);
?>
