<?php
error_reporting(0);
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';

$arr_data=array();
$sql="select * from so_master where notrans like '%$q%' or kodecust like '%$q%'";
$result = mysql_query($sql);
while($obj = mysql_fetch_array($result)) {
  $nodo = $obj['nodo'];
  $mydo = mysql_fetch_array(mysql_query("select * from do_master where notrans='$nodo'"));
  $lewat = $mydo['lewat'];
  $angkutan = $mydo['angkutan'];
  $shipment = $mydo['validto'];
  $nmsopir = $mydo['nmsopir'];
  $noplat = $mydo['noplat'];
 $arr_data[]=array(
   'notrans'=>$obj['notrans'],
   'tgltrans'=>$obj['tgltrans'],
   'kodecust'=>$obj['kodecust'],
   'lokasi'=>$obj['lokasi'],
   'validto'=>$obj['validto'],
   'jenisbbm'=>$obj['jenisbbm'],
   'uom'=>$obj['uom'],
   'harga'=>$obj['harga'],
   'top'=>$obj['top'],
   'lewat'=>$obj['lewat'],
   'ppn'=>$obj['ppn'],
   'pbbkb'=>$obj['pbbkb'],
   'oat'=>$obj['oat'],
   'cofrom'=>$obj['cofrom'],
   'nodo'=>$obj['nodo'],
   'spoint'=>$obj['remarks'],
   'shipment'=>$shipment,
   'lewat'=>$lewat,
   'angkutan'=>$angkutan,
   'nmsopir'=>$nmsopir,
   'noplat'=>$noplat,
 );
}

echo json_encode($arr_data);
?>
