<?php
error_reporting(0);
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';

$arr_data=array();
$sql="select * from mitra where jenis='Supplier' and (kode like '%$q%' or nama like '%$q%') limit 10";
$result = mysql_query($sql);
while($obj = mysql_fetch_object($result)) {
 $arr_data[]=array("kode"=>$obj->kode,"nama"=>$obj->nama,"alamat"=>$obj->alamat,"nohp"=>$obj->nohp);
}

echo json_encode($arr_data);
?>
