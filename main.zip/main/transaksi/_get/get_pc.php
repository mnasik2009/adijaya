<?php
error_reporting(0);
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';

$arr_data=array();
$sql="select * from pc_master where inv='N' and (notrans like '%$q%' or kodesupp like '%$q%')";
$result = mysql_query($sql);
while($obj = mysql_fetch_array($result)) {
  $kodesupp =  $obj['kodesupp'];
  $datasupp = mysql_fetch_array(mysql_query("select * from mitra where kode='$kodesupp'"));
 $arr_data[]=array(
   'notrans'=>$obj['notrans'],
   'tgltrans'=>$obj['tgltrans'],
   'kodecust'=>$obj['kodesupp'],
   'namacust'=>$datasupp['nama'],
   'lokasi'=>$obj['lokasi'],
   'validto'=>$obj['validto'],
   'jenisbbm'=>$obj['jenisbbm'],
   'uom'=>$obj['uom'],
   'harga'=>$obj['harga'],
   'top'=>$obj['top'],
   'lewat'=>$obj['lewat'],
   'ppn'=>$obj['ppn'],
   'pbbkb'=>$obj['pbbkb'],
   'oat'=>$obj['oat'],
   'cofrom'=>$obj['cofrom'],
   'jumlah'=>$obj['jumlah'],
   'lewat'=>$obj['lewat'],
   'pocust'=>$obj['pocust'],
 );
}

echo json_encode($arr_data);
?>
