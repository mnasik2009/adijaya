<?php
error_reporting(0);
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';

$arr_data=array();
$sql="select po_master.jenisbbm, po_detail.* from po_master, po_detail where po_master.notrans = po_detail.notrans
     and (po_detail.jumlahpo - po_detail.jumlahdo) > 0 and po_master.notrans like '%$q%'";
$result = mysql_query($sql);
while($obj = mysql_fetch_object($result)) {
 $arr_data[]=array(
   "notrans"=>$obj->notrans,
   "tgltrans"=>$obj->tanggalpo,
   "jumlah"=>$obj->jumlahpo,
   "harga"=>$obj->hargapo,
   "top"=>$obj->top,
   "lewat"=>$obj->lewat,
   "ppn"=>$obj->ppnpo,
   "pbbkb"=>$obj->pbbkbpo,
   "pph"=>$obj->pphpo,
   "jenisbbm"=>$obj->jenisbbm,
   "ketpo"=>$obj->ketpo,
 );
}

echo json_encode($arr_data);
?>
