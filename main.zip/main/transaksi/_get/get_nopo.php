<?php
error_reporting(0);
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';

$arr_data=array();
$sql="select * from po_master where notrans like '%$q%' or kodesupp like '%$q%'";
$result = mysql_query($sql);
while($obj = mysql_fetch_object($result)) {
 $arr_data[]=array(
   "notrans"=>$obj->notrans,
   "tgltrans"=>$obj->tgltrans,
   "kodecust"=>$obj->kodecust,
   "lokasi"=>$obj->lokasi,
   "validto"=>$obj->validto,
   "jenisbbm"=>$obj->jenisbbm,
   "uom"=>$obj->uom,
   "harga"=>$obj->harga,
   "top"=>$obj->top,
   "lewat"=>$obj->lewat,
   "ppn"=>$obj->ppn,
   "pbbkb"=>$obj->pbbkb,
   "oat"=>$obj->oat,
   "cofrom"=>$obj->cofrom,
   "jumlah"=>$obj->jumlah,
   "spoint"=>$obj->remarks,
 );
}

echo json_encode($arr_data);
?>
