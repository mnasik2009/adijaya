<?php
error_reporting(0);
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';

$arr_data=array();
$sql="select * from lokasicust where kode like '%$q%' or nama like '%$q%' limit 10";
$result = mysql_query($sql);
while($obj = mysql_fetch_object($result)) {
 $arr_data[]=array("kodetjn"=>$obj->kode,"nama"=>$obj->nama,"tarif"=>$obj->tarif,"tarifsopir"=>$obj->tarifsopir);
}

echo json_encode($arr_data);
?>
