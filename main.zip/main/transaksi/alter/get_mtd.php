<?php
include '../../koneksi1.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';

$arr_data=array();
$sql="SELECT * from kegiatan where kode like '%$q%' or nama like '%$q%'";
$result = mysql_query($sql);
while($obj = mysql_fetch_object($result)) {
 $arr_data[]=array("kode"=>$obj->kode,"nama"=>$obj->nama,"if_code"=>$obj->remarks);
}

echo json_encode($arr_data);
?>
