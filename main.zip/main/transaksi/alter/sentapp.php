<?php
include '../../koneksi1.php';
$kode = $_POST['id'];
$row = mysql_num_rows(mysql_query("SELECT * FROM inv_alter WHERE noref='$kode'"));
if($row>0){
	$text = "UPDATE inv_alter set cek='S' WHERE noref='$kode'";
	mysql_query($text);
	echo "Sent Approval Sukses";
}else{
	echo "Tidak bisa sent Approval untuk $kode";
}
?>
