<?php
session_start();
include '../../koneksi.php';

$username = $_SESSION['username'];
$tanggal = $_POST['tanggal'];
$noinv = $_POST['noinv'];
$noref = $_POST['noref'];
$keterangan = $_POST['keterangan'];
$customer = $_POST['customer'];
$nilai = $_POST['nilai'];

$tahun = $format = date('Y', strtotime($tanggal));
$bulan = $format = date('m', strtotime($tanggal));
$format1 = date('Y-m-d', strtotime($tanggal));
$bb = $format = date('y', strtotime($tanggal));
$tglinput = date('d/m/Y');
$nomor = mysql_query("select max(substr(noref,-6)) as noref from inv_alter where year(tanggal)='$tahun'");

$data1 = mysql_fetch_array($nomor);
$idMax = $data1['noref'];
$idMax++;
$newID = 'INV-ALT/' .$tahun .$bulan . sprintf('%06d',$idMax);
$ifbkk = 'AL.'. sprintf('%04d',$idMax). '/' .$bulan . $bb;

$row = mysql_num_rows(mysql_query("SELECT * FROM inv_alter WHERE noref='$noref'"));
if($row>0){
	$text = "UPDATE inv_alter SET noinv = '$noinv',
								tanggal = '$format1',
								tglinput = '$tglinput',
								keterangan = '$keterangan',
								customer = '$customer',
                nilai = '$nilai',
								keterangan = '$keterangan'
								WHERE noref='$noref'";
	mysql_query($text);
	echo "Update Sukses ".$noref;
}else{
    $text = "INSERT INTO inv_alter (noref,tanggal,noinv,tglinput,userid,keterangan,customer,nilai,ifalter,approvedby,cek)
			VALUES ('$newID','$format1','$noinv','$tglinput','$username','$keterangan','$customer','$nilai','$ifbkk','','N')";
	mysql_query($text);
	echo "Simpan Sukses " .$newID;
}
?>
