<script type="text/javascript">
var url;
function createalter(){
	$('#dialog-alter').dialog('open').dialog('setTitle','Entry Invoice Alteration');
	$('#tanggal').textbox('setValue', '');
	$('#noref').textbox('setValue', '');
	$('#noinv').textbox('setValue', '');
	$('#nilai').textbox('setValue', '');
    $('#keu_code').textbox('setValue', '');
	$('#invcode').textbox('setValue', '');
	$('#keterangan').textbox('setValue', '');
	$('#customer').textbox('setValue', '');
}

function savealter(){
	var noref = $("#noref").val();
	var string = $("#form-alter").serialize();
	if(noinv.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, No Referensi tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#noref").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/alter/simpan.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function hapus(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row){
		$.messager.confirm('Confirm','Yakin akan menghapus data ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/alter/hapus.php",
					data	: 'id='+row.noref,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}
}

function sentapp(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.cek == 'N'){
		$.messager.confirm('Confirm','Sent to Approval ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/alter/sentapp.php",
					data	: 'id='+row.noref,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
			$.messager.show({
			title:'Info',
			msg:'Maaf, tidak bisa di sent Approval karena status bukan N',
			timeout:2000,
			showType:'slide'
		});
	}
}
function cetakexcel(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-excel').dialog('open').dialog('setTitle','Print to Excel');
		$('#form-excel').form('load',row);
	}
}

function editmaster(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row.cek == 'N'){
		$('#dialog-alter').dialog('open').dialog('setTitle','Edit Data Alteration');
		$('#form-alter').form('load',row);
	}else{
			$.messager.show({
			title:'Info',
			msg:'Maaf, tidak bisa di edit karena status bukan N',
			timeout:2000,
			showType:'slide'
		});
	}
}

function fresh(){
	$('#datagrid-crud').datagrid('reload');
}
function doSearch(){
	$('#datagrid-crud').datagrid('load',{
        cabang: $('#cabang').val(),
		cari: $('#cari').val()
    });
}
$(function(){
    $('#noinv').combogrid({
				panelWidth:600,
				url		: 'transaksi/alter/get_data.php?',
				idField:'noinv',
				textField:'noinv',
				mode:'remote',
				fitColumns:true,
			    columns:[[
						{field:'noinv',title:'notrans',width:25},
					  {field:'nama',title:'nama',width:25},
					  {field:'total',title:'total',width:10},
						{field:'sisa',title:'sisa',width:10},
			    ]],onClickRow:function(rowData){
			            var val =$('#noinv').combogrid('grid').datagrid('getSelected');
											 $('#customer').textbox('setValue', val.nama);
											 $('#nilai').textbox('setValue', val.sisa);
			                                }
						});
	$('#invcode').combogrid({
			panelWidth:600,
			url		: 'transaksi/alter/get_mtd.php?',
			idField:'kode',
			textField:'if_code',
			mode:'remote',
			fitColumns:true,
			columns:[[
						{field:'kode',title:'kode',width:10},
						{field:'nama',title:'nama',width:25},
						{field:'if_code',title:'if_code',width:10},
									    ]],onClickRow:function(rowData){
									        var val1 =$('#invcode').combogrid('grid').datagrid('getSelected');
																	 $('#invcode').textbox('setValue', val1.if_code);
									     }
						});
	$('#form-excel1').form(
        {
            url:'excelbkm.php',
            success:function(data){
                if(data)//check if data returned
                {
                alert('yes');
                }}
            }
    )
});
</script>
</head>
<body onload="doSearch()">


	<table id="datagrid-crud" title="Invoice Alteration" class="easyui-datagrid" style="width:auto; height: auto;" url="transaksi/alter/json.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
			<th data-options="field:'noref',width:15" >No Transaksi</th>
            <th data-options="field:'tanggal',width:8" sortable="true">Tanggal</th>
						<th data-options="field:'keterangan',width:17">Keterangan</th>
            <th data-options="field:'nilai',width:10" align="right">Nilai</th>
						<th data-options="field:'noinv',width:15">No Invoice</th>
            <th data-options="field:'customer',width:25">Customer</th>
						<th data-options="field:'cek',width:5">Status</th>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px">
		<div style="float:left;">
						<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-plus-square-o fa-lg" plain="true" onclick="createalter()">Add</a>
						<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-pencil-square-o fa-lg" plain="true" onclick="editmaster()">Edit</a>
						<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-minus-square-o fa-lg" plain="true" onclick="hapus()">Delete</a>
            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-refresh fa-lg" plain="true" onclick="fresh()">Refresh</a>
						<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-share-square-o fa-lg" plain="true" onclick="sentapp()">Sent to App</a>
            <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-file-excel-o fa-lg" plain="true" onclick="cetakexcel()">Print to Excel</a>
		</div>
		<div style="float:right;">
        	Pencarian <input id="cari" class="easyui-searchbox" data-options="prompt:'No. Trans ../Tanggal (YYYY-MM-DD)..',searcher:doSearch" style="width:250px"></input>
			<input name="cabang" type="hidden" id="cabang" value="<?php echo $_SESSION['cabang']?>">
		</div>
	</div>

<!-- Dialog Form -->
<div id="dialog-alter" class="easyui-dialog" style="width:400px; height:550px; padding: 10px 20px" closed="true" buttons="#btn-bkk">
	<form id="form-alter" method="post" novalidate>
		<div class="form-item">
			<label for="tanggal">Tanggal</label><br />
			<input type="text" name="tanggal" id="tanggal" class="easyui-datebox" required="true" data-options="prompt:'YYYY-MM-DD'" size="20" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="noref">No Transaksi</label><br/>
			<input type="text" name="noref" id="noref" class="easyui-textbox" style="width:100%" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="keterangan">Keterangan</label><br/>
			<input type="text" name="keterangan" id="keterangan" class="easyui-textbox" required="true"  style="width:100%;height:60px" data-options="multiline:true" />
		</div>
		<div class="form-item">
			<label for="noinv">Post to Inv</label><br />
			<input type="text" name="noinv" id="noinv" class="easyui-textbox" required="true" style="width:100%"/>
			<input type="hidden" name="username" id="username" value="<?php echo $_SESSION['username']?>"/>
			<input name="cabang" type="hidden" id="cabang" value="<?php echo $_SESSION['cabang']?>">
		</div>
		<div class="form-item">
			<label for="nilai">Nilai</label><br/>
			<input type="text" name="nilai" id="nilai" class="easyui-textbox" required="true" style="width:100%" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="customer">Customer</label><br/>
			<input type="text" name="customer" id="customer" class="easyui-textbox" required="true"  style="width:100%" maxlength="100"/>
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="btn-bkk">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" onclick="savealter()">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-alter').dialog('close')">Batal</a>
</div>

<div id="dialog-excel" class="easyui-dialog" style="width:400px; height:350px; padding: 10px 20px" closed="true" buttons="#btn-excel">
	<form id="form-excel" method="post" novalidate>
		<div class="form-item">
			<label for="tanggal">Tanggal</label><br/>
			<input type="text" name="tanggal" id="tanggal" class="easyui-textbox" required="true" size="20" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="noref">No Transaksi</label><br/>
			<input type="text" name="noref" id="noref" class="easyui-textbox" style="width:100%" maxlength="20" />
		</div>
		<div class="form-item">
			<label for="noinv">noinv</label><br />
			<input type="text" name="noinv" id="noinv" class="easyui-textbox" required="true" style="width:100%" data-options="multiline:true"/>
			<input type="hidden" name="username" id="username" value="<?php echo $_SESSION['username']?>"/>
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="btn-excel">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" onclick="$('#form-excel').submit();">Print</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-excel').dialog('close')">Batal</a>
</div>
</body>
