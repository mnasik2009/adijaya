<?php
include '../../koneksi1.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';

$arr_data=array();
$sql="select inv_master.*,mitra.nama, (total - bayar - potongan - invalter) as sisa from inv_master, mitra
      where inv_master.kodecust = mitra.kode
      and (total - bayar - potongan - invalter)>0 and notrans like '%$q%'";
$result = mysql_query($sql);
while($obj = mysql_fetch_object($result)) {
 $arr_data[]=array("noinv"=>$obj->notrans,"nama"=>$obj->nama,"total"=>$obj->total,"sisa"=>$obj->sisa);
}

echo json_encode($arr_data);
?>
