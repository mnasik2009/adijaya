<?php
include '../../koneksi.php';
$notrans = $_POST['id'];
$text1 = "SELECT * FROM po_master WHERE notrans='$notrans'";
$row = mysql_num_rows(mysql_query($text1));
if($row>0){
	$data = mysql_fetch_array(mysql_query($text1));
	$jumlahpo = $data['jumlahpo'];
	$text = "update po_master set jumlah = '$jumlahpo' WHERE notrans='$notrans'";
	mysql_query($text);
	echo "Completed Sukses $notrans";
}else{
	echo "Tidak ada data yang dihapus $notrans";
}
?>
