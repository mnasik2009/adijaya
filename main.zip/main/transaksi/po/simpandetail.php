<?php
session_start();
include '../../koneksi.php';

$idnumber = $_POST['idnumber'];
$userid = $_SESSION['username'];
$tanggalpo = date('Y-m-d',strtotime($_POST['tanggalpo']));
$notrans = $_POST['notrans'];
$hargapo = $_POST['hargapo'];
$jumlahpo = $_POST['jumlahpo1'];
$pphpo = $_POST['pphpo'];
$ppnpo = $_POST['ppnpo'];
$pbbkbpo = $_POST['pbbkbpo'];
$oatpo = $_POST['oatpo'];
$hcostpo = $_POST['hcostpo'];
$ketpo = $_POST['ketpo'];

$text = "SELECT * FROM po_detail WHERE notrans='$notrans' and idnumber='$idnumber'";
$dmas = "SELECT * FROM po_master WHERE notrans='$notrans'";
$row = mysql_num_rows(mysql_query($text));
if($row>0){
	$text1 = "UPDATE po_detail SET tanggalpo='$tanggalpo',
								hargapo='$hargapo',
								jumlahpo='$jumlahpo',
								pphpo='$pphpo',
								ppnpo='$ppnpo',
								pbbkbpo='$pbbkbpo',
								oatpo = '$oatpo',
								hcostpo = '$hcostpo',
								ketpo = '$ketpo',
								userid = '$userid'
								where notrans='$notrans' and idnumber='$idnumber'";
	mysql_query($text1);
	echo "Update Detail Sukses $notrans";
	
}else{
	$data = mysql_fetch_array(mysql_query($dmas));
	$jumlah = $data['jumlah'];
	$jumlahpo1 = $data['jumlahpo'];
	$jtotal = $jumlahpo + $jumlahpo1;

	if ($jtotal <= $jumlah){
		$text1 = "INSERT INTO po_detail SET notrans='$notrans',
									tanggalpo='$tanggalpo',
									jumlahpo='$jumlahpo',
									hargapo='$hargapo',
									pbbkbpo='$pbbkbpo',
									ppnpo='$ppnpo',
									pphpo='$pphpo',
									oatpo = '$oatpo',
									hcostpo = '$hcostpo',
									ketpo = '$ketpo',
									userid = '$userid'";
		mysql_query($text1);
		mysql_query("update po_master set jumlahpo = jumlahpo + $jumlahpo where notrans='$notrans'");
		echo "Simpan Detail Sukses $notrans";
	}else{
		echo "Jumlah Lebih Besar dari Seluruh Total Alokasi Jumlah";
	}
}
?>
