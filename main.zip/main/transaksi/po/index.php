<script type="text/javascript">
var url;
function hitung1(){
			var jpo = document.getElementById("jumlahpo1").value;
			var tpo = document.getElementById("hargapo").value;
			var upo = document.getElementById("ppnpo").value;
			var spo = document.getElementById("pphpo").value;
			var vpo = document.getElementById("pbbkbpo").value;
			var xpo = document.getElementById("hcostpo").value;
			var rpo = document.getElementById("oatpo").value;
			var total = parseFloat(tpo) + parseFloat((tpo*upo)/100) + parseFloat((tpo*vpo)/100) + parseFloat((tpo*spo)/100) + parseFloat((xpo*vpo)/100) + parseFloat((xpo*spo)/100);
			//var totalh = parseFloat(t) + parseFloat((w*u)/100) + parseFloat((w*v)/100) + parseFloat((w*s)/100) + parseFloat((x*v)/100) + parseFloat((x*s)/100);
			var harga1 = parseFloat(rpo*jpo) + parseFloat(total*jpo);
			$('#tharga1').textbox('setValue', harga1);
			//$('#thargatebus').textbox('setValue', totalh);
	}
function create(){
	$('#dialog-form').dialog('open').dialog('setTitle','Tambah Data');
	$('#form').form('clear');
}
function save(){
	var notrans = $("#notrans").val();
	var string = $("#form").serialize();
	if(tgltrans.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, notrans tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#notrans").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/po/simpan.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function simpannewpo(){
	var notrans = $("#notrans").val();
	var string = $("#form-newpo").serialize();
	if(tgltrans.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, notrans tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#notrans").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/po/simpannewpo.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function simpandetail(){
	var notrans = $("#notrans").val();
	var string1 = $("#form-podetail").serialize();
	if(hargapo.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, notrans tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#notrans").focus();
		return false();
	}
	$.ajax({
		type	: "POST",
		url		: "transaksi/po/simpandetail.php",
		data	: string1,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function selesai(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.jumlahpo > row.jumlah){
		$.messager.confirm('Confirm','Apakah Completed data ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/po/completedpo.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dihapus, krn sudah di Approve',
		timeout:2000,
		showType:'slide'
	});
	}
}

function hapus(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.approval == 'N'){
		$.messager.confirm('Confirm','Apakah Anda akan menghapus data ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/po/hapus.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dihapus, krn sudah di Approve',
		timeout:2000,
		showType:'slide'
	});
	}
}

function hapusDetail(){
	var row = $('#data-crud').datagrid('getSelected');
		$.messager.confirm('Confirm','Apakah Anda akan menghapus data ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/po/hapusdetail.php",
					data	: 'id='+row.notrans+row.idnumber,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}else{
				$.messager.show({
				title:'Info',
				msg:'Data tidak bisa dihapus, krn sudah di Approve',
				timeout:2000,
				showType:'slide'
			});
			}
		});
	}

function approve(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.approval == 'N'){
		$.messager.confirm('Confirm','Apakah Approve penawaran ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/po/approve.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dihapus, krn sudah di Approve',
		timeout:2000,
		showType:'slide'
	});
	}
}

function update(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-form').dialog('open').dialog('setTitle','Edit Data');
		$('#form').form('load',row);
	}
}

function detail(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-podetail').dialog('open').dialog('setTitle','Tambah Data Detail');
		$('#form-podetail').form('load',row);
	}
}

function editDetail(){
	var row = $('#data-crud').datagrid('getSelected');
	if(row){
		$('#dialog-podetail').dialog('open').dialog('setTitle','Edit Data Detail');
		$('#form-podetail').form('load',row);
	}
}

function newpo(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row.jumlahpo > row.jumlah ){
		$('#dialog-newpo').dialog('open').dialog('setTitle','New PO');
		$('#form-newpo').form('load',row);
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dibuat PO Baru karena jumlahnya sudah sesuai',
		timeout:2000,
		showType:'slide'
	});
	}
}

function lihat(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-viewpodetail').dialog('open').dialog('setTitle','View Data Detail');
		$('#form-viewpodetail').form('load',row);
		doCari();
	}
}

function cetak(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row.approval == 'Y'){
		$('#dialog-excel').dialog('open').dialog('setTitle','Cetak Data');
		$('#form-excel').form('load',row);
	}else{
				$.messager.show({
				title:'Info',
				msg:'Data tidak bisa di Cetak, krn karena belum di Approve',
				timeout:2000,
				showType:'slide'
			});
	}
}

function fresh(){
	$('#datagrid-crud').datagrid('reload');
}
function doSearch(value){
	$('#datagrid-crud').datagrid('load',{
        cari: value
    });
}

function doCari(){
	$('#data-crud').datagrid('load',{
				notrans: $('#test1').val()
    });
}

$(function(){
    $('#kodesupp').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_supp.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
					{field:'nohp',title:'nohp'},
			    ]],onClickRow:function(rowData){
			                 var val =$('#kodesupp').combogrid('grid').datagrid('getSelected');
											 $('#kodesupp').textbox('setValue', val.kode);
			                                }
						});
		$('#jenisbbm').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_bbm.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'keterangan',title:'keterangan'},
		    ]],onClickRow:function(rowData){
		                 var val =$('#jenisbbm').combogrid('grid').datagrid('getSelected');
										 $('#jenisbbm').textbox('setValue', val.kode);
		             }
			});
	$('#cofrom').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_pt.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    columns:[[
		    {field:'kode',title:'kode'},
		    {field:'nama',title:'nama'},
		    {field:'alamat',title:'alamat'},
				{field:'kota',title:'kota'},
	    ]],onClickRow:function(rowData){
	                var val =$('#cofrom').combogrid('grid').datagrid('getSelected');
								 $('#cofrom').textbox('setValue', val.kode);
	          }
				});
  $('#spoint').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_spoint.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    	columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
					{field:'pic',title:'pic'},
	    ]],onClickRow:function(rowData){
	              var val =$('#spoint').combogrid('grid').datagrid('getSelected');
								 $('#spoint').textbox('setValue', val.kode);
	          }
			});
		});

</script>
</head>
<body>

	<div style="margin:10px 0;"></div>

	<table id="datagrid-crud" title="Purchase Order" class="easyui-datagrid" style="width:auto; height: auto;" url="transaksi/po/json.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
            <th data-options="field:'notrans'" sortable="true">No Trans </th>
            <th data-options="field:'kodesupp'" sortable="true">Customer </th>
            <th data-options="field:'tgltrans'">Tanggal</th>
            <th data-options="field:'validto'">Berlaku</th>
            <th data-options="field:'jenisbbm'">BBM</th>
						<th data-options="field:'uom'">UOM</th>
						<th data-options="field:'harga'">Harga</th>
						<th data-options="field:'jumlah'">Jumlah</th>
						<th data-options="field:'jumlahpo'">Jumlah PO</th>
						<th data-options="field:'ppn'">PPN</th>
						<th data-options="field:'pbbkb'">PBBKB</th>
						<th data-options="field:'pph'">PPH</th>
						<th data-options="field:'hcost'">Handling Cost</th>
						<th data-options="field:'oat'">OAT</th>
						<th data-options="field:'top'">TOP</th>
            <th data-options="field:'approval'">Approval</th>
            <th data-options="field:'cofrom'">CO From</th>
						<th data-options="field:'spoint'">Supply Point</th>
        </tr>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px;">
		<div style="float:left;">
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-plus-square-o fa-lg" plain="true" onclick="create()">Tambah</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-pencil-square-o fa-lg" plain="true" onclick="update()">Edit</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-minus-square-o fa-lg" plain="true" onclick="hapus()">Hapus</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-hdd-o fa-lg" plain="true" onclick="detail()">Add Detail</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-file-text-o fa-lg" plain="true" onclick="lihat()">View Detail</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-bookmark-o fa-lg" plain="true" onclick="selesai()">Completed</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-share-square-o fa-lg" plain="true" onclick="newpo()">Create New PO</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-check fa-lg" plain="true" onclick="approve()">Approval</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" plain="true" onclick="cetak()">Print</a>
      <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-refresh fa-lg" plain="true" onclick="fresh()">Refresh</a>
		</div>
		<div style="float:right;">
        	Pencarian <input id="cari" class="easyui-searchbox" data-options="prompt:'Cari notrans / kodesupp..',searcher:doSearch" style="width:200px"></input>
		</div>
	</div>

<!-- Dialog Form -->
<div id="dialog-form" class="easyui-dialog" style="width:600px; height:650px; padding: 10px 20px" closed="true" buttons="#dialog-buttons">
	<form id="form" method="post" novalidate>
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Supplier &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Valid To</label><br />
			<input type="text" name="kodesupp" id="kodesupp" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="validto" id="validto" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="validto">Jenis BBM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; UOM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Harga</label><br />
			<input type="text" name="jenisbbm" id="jenisbbm" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="uom" id="uom" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="harga" id="harga" class="easyui-textbox" required="true" style="width:38%"/>
		</div>
		<div class="form-item">
			<label for="lewat">Jumlah (Liter)</label><br />
			<input type="text" name="jumlah" id="jumlah" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="jenisbbm">PPN (%) &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PBBKB (%)&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; PPH</label><br />
			<input type="text" name="ppn" id="ppn" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="pbbkb" id="pbbkb" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="pph" id="pph" class="easyui-textbox" required="true" style="width:38%"/>
		</div>
		<div class="form-item">
			<label for="jenisbbm">Handling Cost &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;OAT</label><br />
			<input type="text" name="hcost" id="hcost" class="easyui-textbox" required="true" style="width:49%"/>
			<input type="text" name="oat" id="oat" class="easyui-textbox" required="true" style="width:50%"/>
		</div>
		<div class="form-item">
			<label for="top">Term Of payment</label><br />
			<input type="text" name="top" id="top" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
    <div class="form-item">
			<label for="cofrom">CO From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	<div class="form-item">
		<label for="lokasi">Site / Lokasi &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Via / Lewat</label><br />
		<input type="text" name="lokasi" id="lokasi" class="easyui-textbox" required="true" style="width:50%"/>
		<input type="text" name="lewat" id="lewat" class="easyui-textbox" required="true" style="width:49%"/>
	</div>
		<div class="form-item">
			<label for="lewat">Supply Point</label><br />
			<input type="text" name="spoint" id="spoint" class="easyui-textbox" required="true" style="width:100%"/>
		</div>

	</form>
</div>

<!-- Dialog Button -->
<div id="dialog-buttons">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" onclick="save()">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-form').dialog('close')">Batal</a>
</div>


<!-- Pencetakan ke Printer -->
<div id="dialog-excel" class="easyui-dialog" style="width:600px; height:300px; padding: 10px 20px" closed="true" buttons="#dialog-btn">
	<form id="form-excel" method="post" action="transaksi/po/cetak.php" target="_blank">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Customer &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Valid To</label><br />
			<input type="text" name="kodesupp" id="kodesupp" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="validto" id="validto" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="cofrom">CO From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="dialog-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" onclick="$('#form-excel').submit();">Cetak</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-excel').dialog('close')">Batal</a>
</div>
</body>


<!-- Add PO Detail -->
<div id="dialog-podetail" class="easyui-dialog" style="width:500px; height:500px; padding: 10px 20px" closed="true" buttons="#btn-podetail">
	<form id="form-podetail" method="post">
		<div class="form-item">
			<label for="type">No Transaksi &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Tanggal</label><br />
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="tanggalpo" id="tanggalpo" class="easyui-datebox" required="true" style="width:49%"/>

		</div>
		<div class="form-item">
			<label for="hargapo">Harga BBM (Rupiah) &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Jumlah BBM (Liter)</label><br />
			<input type="text" name="hargapo" id="hargapo" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="jumlahpo1" id="jumlahpo1" class="easyui-textbox" required="true" style="width:49%"/>
		</div>
		<div class="form-item">
			<label for="pbbkbpo">PBBKB (%)&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PPN (%) &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PPH (%)</label><br />
			<input type="text" name="pbbkbpo" id="pbbkbpo" value="7.5" class="easyui-textbox" required="true" style="width:38%"/>
			<input type="text" name="ppnpo" id="ppnpo" value="11" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="pphpo" id="pphpo" value="2" class="easyui-textbox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="jenisbbm">Handling Cost &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;OAT</label><br />
			<input type="text" name="hcostpo" id="hcostpo" class="easyui-textbox" required="true" style="width:49%"/>
			<input type="text" name="oatpo" id="oatpo" class="easyui-textbox" required="true" style="width:50%"/>
		</div><br/>
		<div class="form-item">
			<a class="easyui-linkbutton" onclick="hitung1()" style="width:100%">Calculate</a>
		</div>
		<div class="form-item">
			<label for="tharga1">Total Harga</label><br />
			<input type="text" name="tharga1" id="tharga1" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="ketpo">Keterangan</label><br />
			<input type="text" name="ketpo" id="ketpo" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="btn-podetail">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-save fa-lg" onclick="simpandetail()">Save</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-podetail').dialog('close')">Batal</a>
</div>

<!-- View PO Detail -->
<div id="dialog-viewpodetail" class="easyui-dialog" style="width:800px; height:400px;" closed="true" buttons="#btn-viewpodetail">
	<form id="form-viewpodetail" method="post">
		<table id="data-crud" class="easyui-datagrid" style="width:800px; height: auto;" url="transaksi/po/jsondetail.php" toolbar="#ta" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
		<thead>
        <tr>
            <th data-options="field:'notrans'" sortable="true">No Trans </th>
            <th data-options="field:'tanggalpo'">Tanggal</th>
						<th data-options="field:'hargapo'">Harga</th>
						<th data-options="field:'jumlahpo'">Jumlah PO</th>
						<th data-options="field:'ppnpo'">PPN</th>
						<th data-options="field:'pbbkbpo'">PBBKB</th>
						<th data-options="field:'pphpo'">PPH</th>
						<th data-options="field:'hcostpo'">H. Cost</th>
						<th data-options="field:'oatpo'">OAT</th>
						<th data-options="field:'total'">Total</th>
						<th data-options="field:'ketpo'">Keterangan</th>
						<th data-options="field:'idnumber'">ID#</th>
        </tr>
    </thead>
	</table>
	</form>
			<div id="ta" style="padding:2px;height:30px">
					<form id="detail" method="post" action="#" novalidate>
						<div style="float:left;">
										No Trans <input type="text" id="test1" name="notrans" class="easyui-textbox"  style="width:250px"></input>
						</div>
						<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-search" plain="true" onclick="doCari()">Cari Data</a>
						<!--a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-edit" plain="true" onclick="editDetail()">Edit</a-->
						<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-remove" plain="true" onclick="hapusDetail()">Hapus Data</a>
					</form>
		</div>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="btn-viewpodetail">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-viewpodetail').dialog('close')">Batal</a>
</div>

<!-- Add New PO -->
<div id="dialog-newpo" class="easyui-dialog" style="width:600px; height:650px; padding: 10px 20px" closed="true" buttons="#btn-newpo">
	<form id="form-newpo" method="post">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Supplier &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Valid To</label><br />
			<input type="text" name="kodesupp" id="kodesupp" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="validto" id="validto" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="validto">Jenis BBM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; UOM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Harga</label><br />
			<input type="text" name="jenisbbm" id="jenisbbm" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="uom" id="uom" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="harga" id="harga" class="easyui-textbox" required="true" style="width:38%"/>
		</div>
		<div class="form-item">
			<label for="lewat">Jumlah (Liter) &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Jumlah PO</label><br />
			<input type="text" name="jumlah" id="jumlah" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="jumlahpo" id="jumlahpo" class="easyui-textbox" required="true" style="width:49%"/>
		</div>
		<div class="form-item">
			<label for="jenisbbm">PPN (%) &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PBBKB (%)&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; PPH</label><br />
			<input type="text" name="ppn" id="ppn" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="pbbkb" id="pbbkb" class="easyui-textbox" required="true" style="width:30%"/>
			<input type="text" name="pph" id="pph" class="easyui-textbox" required="true" style="width:38%"/>
		</div>
		<div class="form-item">
			<label for="jenisbbm">Handling Cost &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;OAT</label><br />
			<input type="text" name="hcost" id="hcost" class="easyui-textbox" required="true" style="width:49%"/>
			<input type="text" name="oat" id="oat" class="easyui-textbox" required="true" style="width:50%"/>
		</div>
		<div class="form-item">
			<label for="top">Term Of payment</label><br />
			<input type="text" name="top" id="top" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
    <div class="form-item">
			<label for="cofrom">CO From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	<div class="form-item">
		<label for="lokasi">Site / Lokasi &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Via / Lewat</label><br />
		<input type="text" name="lokasi" id="lokasi" class="easyui-textbox" required="true" style="width:50%"/>
		<input type="text" name="lewat" id="lewat" class="easyui-textbox" required="true" style="width:49%"/>
	</div>
		<div class="form-item">
			<label for="lewat">Supply Point</label><br />
			<input type="text" name="spoint" id="spoint" class="easyui-textbox" required="true" style="width:100%"/>
		</div>

	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="btn-newpo">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-save fa-lg" onclick="simpannewpo();">Save</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-newpo').dialog('close')">Batal</a>
</div>
</body>
