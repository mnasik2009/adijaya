<?php
session_start();
include '../../koneksi.php';

$userid = $_SESSION['username'];
$cabang = $_SESSION['cabang'];
$tgltrans = date('Y-m-d',strtotime($_POST['tgltrans']));
$notrans = $_POST['notrans'];
$kodesupp = $_POST['kodesupp'];
$validto = date('Y-m-d',strtotime($_POST['validto']));
$jenisbbm = $_POST['jenisbbm'];
$uom = $_POST['uom'];
$harga = $_POST['harga'];
$jumlah = $_POST['jumlah'];
$jumlahpo = $_POST['jumlahpo'];
$oat = $_POST['oat'];
$ppn = $_POST['ppn'];
$pbbkb = $_POST['pbbkb'];
$hcost = $_POST['hcost'];
$pph = $_POST['pph'];
$top = $_POST['top'];
$cofrom = $_POST['cofrom'];
$lokasi = $_POST['lokasi'];
$lewat = $_POST['lewat'];
$spoint = $_POST['spoint'];
$bulan = date('m',strtotime($_POST['tgltrans']));
$tahun = date('Y',strtotime($_POST['tgltrans']));

$jsisa = $jumlah - $jumlahpo;
if ($cofrom == 'AJ0001'){
	$kode = 'ABJ';
}else{
	$kode = 'PAJ';
}
if ($bulan == 1) {
	$roma = 'I';
}else if ($bulan == 2) {
	$roma = 'II';
}else if ($bulan == 3) {
	$roma = 'III';
}else if ($bulan == 4) {
	$roma = 'IV';
}else if ($bulan == 5) {
	$roma = 'V';
}else if ($bulan == 6) {
	$roma = 'VI';
}else if ($bulan == 7) {
	$roma = 'VII';
}else if ($bulan == 8) {
	$roma = 'VIII';
}else if ($bulan == 9) {
	$roma = 'IX';
}else if ($bulan == 10) {
	$roma = 'X';
}else if ($bulan == 11) {
	$roma = 'XI';
}else if ($bulan == 12) {
	$roma = 'XII';
}
$nomor = mysql_query("select max(substr(notrans,1,6)) as noref from po_master where year(tgltrans)='$tahun' cabang='$cabang'");

$data1 = mysql_fetch_array($nomor);
$idMax = $data1['noref'];
$idMax++;
$newID = sprintf('%06d',$idMax).'/PO/'.$kode.'-'.$cabang.'/'.$roma.'/'.$tahun;
$tglinput = date('Y-m-d');

	$text = "INSERT INTO po_master SET notrans='$newID',
								tgltrans='$tgltrans',
								kodesupp='$kodesupp',
								validto = '$validto',
								jenisbbm='$jenisbbm',
								harga='$harga',
								jumlah='$jsisa',
								uom='$uom',
								ppn='$ppn',
								pbbkb='$pbbkb',
								oat = '$oat',
								pph = '$pph',
								hcost = '$hcost',
								top = '$top',
								cofrom = '$cofrom',
								lokasi='$lokasi',
								lewat='$lewat',
								tglinput='$tglinput',
								remarks = '$spoint',
								userid = '$userid'";
	mysql_query($text);
	echo "Simpan Sukses $newID";
?>
