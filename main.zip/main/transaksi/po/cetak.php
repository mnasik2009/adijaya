<?php
require('../../fpdf/fpdf.php');
include '../../koneksi.php';
include '../../phpqrcode/qrlib.php';

$notrans = $_POST['notrans'];
$data = mysql_fetch_array(mysql_query("SELECT * FROM qtn_master where notrans='$notrans'"));

$tanggal = date('d M Y',strtotime($data['tgltrans']));
$validto = date('d M Y',strtotime($data['validto']));
$lokasi = $data['lokasi'];
$cofrom = $data['cofrom'];
$lewat = $data['lewat'];
$kodecust = $data['kodecust'];
$jenisbbm = $data['jenisbbm'];
$harga = $data['harga'];
$term = $data['top'];
$suppoint = $data['remarks'];

$ppn = ($data['ppn'] * $harga)/100;
$pbbkb = ($data['pbbkb'] * $harga)/100;
$oat = $data['oat'];
$total = $harga + $ppn + $pbbkb + $oat;
$dcus = mysql_fetch_array(mysql_query("SELECT * FROM mitra where kode='$kodecust'"));
$namacust = $dcus['nama'];


$dglobal = mysql_fetch_array(mysql_query("SELECT * FROM globalset where kode='$cofrom'"));
$namafr = $dglobal['nama'];
$alamat = $dglobal['alamat'];
$kota = $dglobal['kota'];
$notelp = $dglobal['notelp'];
$direktur = $dglobal['direktur'];
$nohp = $dglobal['nohp'];
$email = $dglobal['email'];
$bri = $dglobal['bri'];
$mandiri = $dglobal['mandiri'];

$point = mysql_fetch_array(mysql_query("SELECT * FROM spoint WHERE kode='$suppoint'"));
$namapoint = $point['nama'];

$tempdir = "temp/";
if (!file_exists($tempdir))
   mkdir($tempdir);
$isi = substr($notrans,0,6);
$namafile = sha1($isi).'.png';
$qua = 'H';
$ukuran = 5;
$padding = 0;
$namafile1 = substr($notrans,1,4).'.png';
$logo = $direktur.sha1($isi);
QRCode::png($notrans,$tempdir.$namafile,$qua,$ukuran,$padding);
QRCode::png($logo,$tempdir.$namafile1,$qua,$ukuran,$padding);
// Insert a logo in the top-left corner at 300 dpi
$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();
if ($kodecust == 'AJ0001'){
  $pdf->Image('../../dist/img/logo_aj.png',10,10,70,20);
}else{
  $pdf->Image('../../dist/img/logo_paj.png',10,10,70,20);
}

$pdf->Image('../../dist/img/patra.png',140,10,40,20);
$pdf->Image('temp/'.$namafile,148,55,20,20);
$pdf->Image('temp/'.$namafile1,148,255,20,20);
$pdf->Ln();
$pdf->SetFont('Times','',11);

// Membuat Dari
$pdf->Text(15, 40, 'Dari:');
$pdf->Text(15, 45, $namafr);
$pdf->Text(15, 50, $alamat.' '.$kota.' - KALTIM');
$pdf->Text(15, 55, 'Telp. '.$notelp);
$pdf->Text(15, 60, 'CP. '.$direktur);
$pdf->Text(15, 65, $nohp);
$pdf->Text(15, 70, 'email: '.$email);

// Membuat Nomor Penawaran
$pdf->Text(120, 40, 'Nomor');
$pdf->Text(145, 40, ':');
$pdf->Text(148, 40, $notrans);
$pdf->Text(120, 45, 'Tanggal');
$pdf->Text(145, 45, ':');
$pdf->Text(148, 45, 'Samarinda, '.$tanggal);
$pdf->Text(120, 50, 'Berlaku s/d');
$pdf->Text(145, 50, ':');
$pdf->Text(148, 50, $validto);

// Bagian kepada / Customer
$pdf->Text(15, 85, 'Kepada');
$pdf->Text(40, 85, ':');
$pdf->Text(42, 85, $namacust);
$pdf->Text(15, 90, 'UP');
$pdf->Text(40, 90, ':');
$pdf->Text(42, 90, '');
$pdf->Text(15, 95, 'Email');
$pdf->Text(40, 95, ':');
$pdf->Text(42, 95, '');
$pdf->Text(15, 100, 'Site');
$pdf->Text(40, 100, ':');
$pdf->Text(42, 100, $lokasi);
$pdf->Text(15, 105, 'Via');
$pdf->Text(40, 105, ':');
$pdf->Text(42, 105, $lewat);

// Bagian isi dari Dengan Hormat
$pdf->Text(15, 115, 'Dengan hormat,');
$pdf->Text(15, 120, 'Bersama ini  kami  informasikan  penawaran  harga  '.$jenisbbm.' Periode '.$tanggal.' s/d '.$validto.' dengan rincian');
$pdf->Text(15, 125, 'sebagai berikut:');
// tabel
$pdf->ln(120);
$h = 8;
$h1 = 6;
$left = 40;
$left1 = 40;
$top = 80;
$left2 = 40;
$left3 = 40;
$left4 = 40;
$left5 = 40;
#tableheader
$pdf->SetFillColor(200,200,200);
$left = $pdf->GetX();
$left1 = $pdf->GetX();
$left2 = $pdf->GetX();
$left3 = $pdf->GetX();
$left4 = $pdf->GetX();
$left5 = $pdf->GetX();
$pdf->SetFont('Times','B',11);
$pdf->SetX($left += 20);$pdf->Cell(20,$h,'Item#',1,0,'C',true);
$pdf->SetX($left += 20); $pdf->Cell(70, $h, 'Desription', 1, 0, 'C',true);
$pdf->SetX($left += 70); $pdf->Cell(20, $h, 'UOM', 1, 0, 'C',true);
$pdf->SetX($left += 20); $pdf->Cell(40, $h, 'Unit Price', 1, 0, 'C',true);
$pdf->SetFont('Times','',11);
$pdf->ln();
$pdf->SetFillColor(255,255,255);
$pdf->SetX($left1 += 20);$pdf->Cell(20,$h1,'1.',1,0,'C',true);
$pdf->SetX($left1 += 20); $pdf->Cell(70, $h1, $jenisbbm, 1, 0, 'L',true);
$pdf->SetX($left1 += 70); $pdf->Cell(20, $h1, 'Liter', 1, 0, 'C',true);
$pdf->SetX($left1 += 20); $pdf->Cell(40, $h1, number_format($harga,2), 1, 0, 'R',true);
$pdf->ln();
$pdf->SetX($left2 += 20);$pdf->Cell(20,$h1,'',1,0,'C',true);
$pdf->SetX($left2 += 20); $pdf->Cell(70, $h1, 'PPN', 1, 0, 'L',true);
$pdf->SetX($left2 += 70); $pdf->Cell(20, $h1, '', 1, 0, 'L',true);
$pdf->SetX($left2 += 20); $pdf->Cell(40, $h1, number_format($ppn,2), 1, 0, 'R',true);
$pdf->ln();
$pdf->SetX($left3 += 20);$pdf->Cell(20,$h1,'',1,0,'C',true);
$pdf->SetX($left3 += 20); $pdf->Cell(70, $h1, 'PBBKB', 1, 0, 'L',true);
$pdf->SetX($left3 += 70); $pdf->Cell(20, $h1, '', 1, 0, 'L',true);
$pdf->SetX($left3 += 20); $pdf->Cell(40, $h1, number_format($pbbkb,2), 1, 0, 'R',true);
$pdf->ln();
$pdf->SetX($left4 += 20);$pdf->Cell(20,$h1,'2',1,0,'C',true);
$pdf->SetX($left4 += 20); $pdf->Cell(70, $h1, 'OAT', 1, 0, 'L',true);
$pdf->SetX($left4 += 70); $pdf->Cell(20, $h1, '', 1, 0, 'L',true);
$pdf->SetX($left4 += 20); $pdf->Cell(40, $h1, number_format($oat,2), 1, 0, 'R',true);
$pdf->ln();
//$pdf->SetX($left5 += 20);$pdf->Cell(20,$h1,'',1,0,'C',true);
$pdf->SetX($left5 += 20); $pdf->Cell(110, $h1, 'Total Keseluruhan', 1, 0, 'C',true);
//$pdf->SetX($left5 += 70); $pdf->Cell(20, $h1, '', 1, 0, 'L',true);
$pdf->SetX($left5 += 110); $pdf->Cell(40, $h1, number_format($total,2), 1, 0, 'R',true);
$pdf->Text(15, 180, 'Demikian penawaran harga ini kami buat, atas perhatian dan kerjasamanya diucapkan terima kasih.');
$pdf->Text(15, 190, '-');
$pdf->Text(20, 190, 'Sounding Bahan Bakar Minyak '.$jenisbbm.' Berdasarkan Flow Meter pihak penerima yang telah memiliki sertifikat');
$pdf->Text(20, 195, 'dari Badan Meteorologi (Certificate of Flow Meter) dan toleransi losses 0.5% dari kuanttas pemesanan ');
$pdf->Text(15, 200, '-');
$pdf->Text(20, 200, 'Untuk  mesin yang tidak bergerak dikenakan PBBKB 0% dengan memberikan atau  rekomendasi dari  Pemerintah ');
$pdf->Text(20, 205, 'daerah dan kami akan mengeluarkan Ship To atas nama konsumen dari Pertamina Patraniaga');
$pdf->Text(15, 210, '-');
$pdf->Text(20, 210, 'PO harap diterbitkan maksimal 2 hari sebelum pengiriman BBM');
$pdf->SetFont('Times','B',11);
$pdf->Text(15, 215, '-');
$pdf->Text(20, 215, 'Tidak termasuk biaya Portal, penyeberangan dan kondisi masyarakat setempat (bila ada)');
$pdf->SetFont('Times','',11);
$pdf->Text(15, 220, '-');
$pdf->Text(20, 220, 'Supply Point : '.$namapoint);
$pdf->Text(15, 225, '-');
$pdf->Text(20, 225, 'Harga diatas sudah termasuk biaya Pengiriman');
$pdf->Text(15, 235, 'Term Of Payment : '.$term);
$pdf->Text(140,240, 'Hormat Kami');
$pdf->SetFont('Times','B',11);
$pdf->Text(140,245, $namafr);
$pdf->SetFont('Times','',11);
$pdf->Text(15, 245, 'Pembayaran Melalui:');
$pdf->Text(15, 250, '-');
$pdf->Text(20, 250, 'Bank Rakyat Indonesia');
$pdf->Text(65, 250, ':');
$pdf->SetFont('Times','B',11);
$pdf->Text(70, 250, $bri);
$pdf->SetFont('Times','',11);
$pdf->Text(15, 255, '-');
$pdf->Text(20, 255, 'Bank Mandiri');
$pdf->Text(65, 255, ':');
$pdf->SetFont('Times','B',11);
$pdf->Text(70, 255, $mandiri);
$pdf->SetFont('Times','B',11);
$pdf->Text(15, 260, 'AN '.$namafr);
$pdf->SetFont('Times','',11);
$pdf->Output($notrans.'.PDF','I');
unlink('temp/'.$namafile);
unlink('temp/'.$namafile1);
?>
