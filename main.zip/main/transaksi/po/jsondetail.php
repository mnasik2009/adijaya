<?php
include '../../koneksi.php';

$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
$rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'tanggalpo';
$order = isset($_POST['order']) ? strval($_POST['order']) : 'desc';
$cari = isset($_POST['notrans']) ? mysql_real_escape_string($_POST['notrans']) : '';

$offset = ($page-1) * $rows;

$where = " WHERE notrans LIKE '%$cari%'";

$text = "SELECT * FROM po_detail
	$where
	ORDER BY $sort $order
	LIMIT $rows OFFSET $offset";

$result = array();
$result['total'] = mysql_num_rows(mysql_query("SELECT * FROM po_detail$where"));
$row = array();

$criteria = mysql_query($text);
while($data=mysql_fetch_array($criteria))
{
	$total = $data['hargapo'] + ($data['hargapo'] + $data['ppnpo']) / 100 + ($data['hargapo'] + $data['pphpo']) / 100 + ($data['hargapo'] + $data['pbbkb']) / 100 +
	         ($data['hcostpo'] + $data['pphpo']) / 100 + ($data['hcostpo'] + $data['pbbkb']) / 100 ;
	$tharga = $total * $data['jumlahpo'] + $data['oat'] * $data['jumlahpo'];
	$row[] = array(
		'notrans'=>$data['notrans'],
		'tanggalpo'=>$data['tanggalpo'],
		'hargapo'=>$data['hargapo'],
		'jumlahpo'=>$data['jumlahpo'],
		'lewat'=>$data['lewat'],
		'ppnpo'=>$data['ppnpo'],
		'pbbkbpo'=>$data['pbbkbpo'],
		'pphpo'=>$data['pphpo'],
		'hcostpo'=>$data['hcostpo'],
		'oatpo'=>$data['oatpo'],
		'ketpo'=>$data['ketpo'],
		'idnumber'=>$data['idnumber'],
		'total'=>number_format($tharga,2),
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
?>
