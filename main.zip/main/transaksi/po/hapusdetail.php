<?php
include '../../koneksi.php';
$notrans = $_POST['id'];
$row = mysql_num_rows(mysql_query("SELECT * FROM po_detail WHERE concat(notrans,idnumber)='$notrans'"));
if($row>0){
	$text = "DELETE FROM po_detail
			WHERE concat(notrans,idnumber)='$notrans'";
	mysql_query($text);
	echo "Hapus Sukses";
}else{
	echo "Tidak ada data yang dihapus $notrans";
}
?>
