<?php
include '../../terbilang.php';
require('../../fpdf/fpdf.php');
include '../../koneksi.php';
include '../../phpqrcode/qrlib.php';

$notrans = $_POST['notrans'];
$data = mysql_fetch_array(mysql_query("SELECT * FROM do_master where notrans='$notrans'"));

$tanggal = date('d M Y',strtotime($data['tgltrans']));
$validto = date('d M Y',strtotime($data['validto']));
$lewat = $data['lewat'];
$cofrom = $data['cofrom'];
$lewat = $data['lewat'];
$kodecust = $data['kodecust'];
$angkutan = $data['angkutan'];
$noplat = $data['noplat'];
$nmsopir = $data['nmsopir'];
$mitra = $data['mitra'];
$nama = $data['nama'];

$dcus = mysql_fetch_array(mysql_query("SELECT * FROM mitra where kode='$kodecust'"));
$namacust = $dcus['nama'];
$npwpcust = $dcus['npwp'];
$alamatcust = $dcus['alamat'];


$dmitra = mysql_fetch_array(mysql_query("SELECT * FROM mitra where kode='$mitra'"));
$npwpmitra = $dmitra['npwp'];
$alamatmitra = $dmitra['alamat'];

$dataso = mysql_fetch_array(mysql_query("SELECT * FROM so_master where nodo='$notrans'"));
$jenisbbm = $dataso['jenisbbm'];
$jumlah = $dataso['jumlah'];

$dglobal = mysql_fetch_array(mysql_query("SELECT * FROM globalset where kode='$cofrom'"));
$namafr = $dglobal['nama'];
$alamat = $dglobal['alamat'];
$kota = $dglobal['kota'];
$notelp = $dglobal['notelp'];
$direktur = $dglobal['direktur'];
$nohp = $dglobal['nohp'];
$email = $dglobal['email'];
$bri = $dglobal['bri'];
$mandiri = $dglobal['mandiri'];

$tempdir = "temp/";
if (!file_exists($tempdir))
   mkdir($tempdir);
$isi = substr($notrans,0,6);
$namafile = sha1($isi).'.png';
$qua = 'H';
$ukuran = 5;
$padding = 0;
$namafile1 = substr($notrans,1,4).'.png';
$logo = $direktur.sha1($isi);
QRCode::png($notrans,$tempdir.$namafile,$qua,$ukuran,$padding);
QRCode::png($logo,$tempdir.$namafile1,$qua,$ukuran,$padding);
// Insert a logo in the top-left corner at 300 dpi
$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();
if ($kodecust == 'AJ0001'){
  $pdf->Image('../../dist/img/logo_aj.png',120,10,70,20);
}else{
  $pdf->Image('../../dist/img/logo_paj.png',120,10,70,20);
}

$pdf->Image('../../dist/img/patra.png',10,5,40,20);
$pdf->Image('temp/'.$namafile,170,38,20,20);
$pdf->Ln();
$pdf->SetFont('Arial','',8);
$pdf->Text(10, 25, 'Gedung Wisma Tugu II Lt. 2');
$pdf->Text(10, 29, 'Jl. Rasuna Said Kav. C 7-9 Kuningan');
$pdf->Text(10, 33, 'Jakarta 12920');
// Membuat Dari
$pdf->SetFont('Times','BU',14);
$pdf->Cell(180, 55, 'D E L I V E R Y  O R D E R',0,1,'C');
$pdf->SetFont('Times','',11);
$pdf->Text(15, 50, 'DO No');
$pdf->Text(40, 50, ':');
$pdf->Text(43, 50, $notrans);
$pdf->Text(15, 55, 'PO No');
$pdf->Text(40, 55, ':');
$pdf->Text(43, 55, $nopo);

// Membuat Nomor Penawaran
$pdf->Text(100, 50, 'No./Nama Armada');
$pdf->Text(133, 50, ':');
$pdf->Text(136, 50, $noplat);
$pdf->Text(100, 55, 'Nama Pengemudi');
$pdf->Text(133, 55, ':');
$pdf->Text(136, 55, $nmsopir);
// Garis Atas
$pdf->Line(10,60,200,60);
// Garis Kiri
$pdf->Line(10,60,10,93);
// Garis Kanan
$pdf->Line(200,60,200,93);
// Garis Tengah
$pdf->Line(115,60,115,93);
$pdf->Text(15, 68, 'DELIVERED TO:');
$pdf->Text(15, 73, $namacust);
$pdf->Text(15, 78, $alamatcust);
$pdf->Text(15, 88, 'N P W P');
$pdf->Text(40, 88, ': '.$npwpcust);

$pdf->Text(120, 68, 'Penyalur/Transportir');
$pdf->Text(155, 68, ': '.$nama);

$pdf->Text(120, 78, 'N P W P');
$pdf->Text(155, 78, ': '.$npwpmitra);
$pdf->Text(120, 88, 'Alamat');
$pdf->Text(155, 88, ': '.$alamatmitra);
// Garis Bawah
$pdf->Line(10,93,200,93);

$pdf->ln(35);
$h = 8;
$h1 = 6;
$h2 = 12;
$left = 40;
$left1 = 40;
$top = 80;
$left2 = 40;
$left3 = 40;
$left4 = 40;
$left5 = 40;
$left6 = 40;
$pdf->SetFillColor(200,200,200);
$left = $pdf->GetX();
$left1 = $pdf->GetX();
$left2 = $pdf->GetX();
$left3 = $pdf->GetX();
$left4 = $pdf->GetX();
$left5 = $pdf->GetX();
$left6 = $pdf->GetX();
$pdf->SetFont('Times','B',10);
$pdf->SetX($left);$pdf->Cell(70,$h,'TANGGAL PENGIRIMAN',1,0,'C',true);
$pdf->SetX($left += 70); $pdf->Cell(60, $h, 'JENIS PRODUK', 1, 0, 'C',true);
$pdf->SetX($left += 60); $pdf->Cell(60, $h, 'KUANTITAS', 1, 0, 'C',true);

// Bagian isi dari Dengan Hormat
// tabel
$pdf->SetFont('Times','',11);
$pdf->ln();
$pdf->SetFillColor(255,255,255);
$pdf->SetX($left1);$pdf->Cell(70,$h1,'Kamis, 01 Juli 2022',1,0,'C',true);
$pdf->SetX($left1 += 70); $pdf->Cell(70, $h1, $jenisbbm, 1, 0, 'C',true);
$pdf->SetX($left1 += 60); $pdf->Cell(60, $h1, $jumlah, 1, 0, 'C',true);

$pdf->ln();
$pdf->SetX($left2);$pdf->Cell(35,$h1,'Jenis Armada',1,0,'C',true);
$pdf->SetX($left2 += 35); $pdf->Cell(35, $h1, $angkutan, 1, 0, 'C',true);
$pdf->ln();
$pdf->SetX($left3);$pdf->Cell(35,$h1,'Via',1,0,'C',true);
$pdf->SetX($left3 += 35); $pdf->Cell(35, $h1, $lewat, 1, 0, 'C',true);
$pdf->ln();
$pdf->SetX($left4);$pdf->Cell(35,$h1,'KM Awal',1,0,'C',true);
$pdf->SetX($left4 += 35); $pdf->Cell(35, $h1, '', 1, 0, 'L',true);
$pdf->ln();
$pdf->SetX($left5);$pdf->Cell(35,$h1,'KM Akhir',1,0,'C',true);
$pdf->SetX($left5 += 35); $pdf->Cell(35, $h1, '', 1, 0, 'L',true);
$pdf->ln();
$pdf->SetX($left6);$pdf->Cell(35,$h1,'SG Meter',1,0,'C',true);
$pdf->SetX($left6 += 35); $pdf->Cell(35, $h1, '', 1, 0, 'L',true);
$pdf->ln();

// Garis Tengah 1
$pdf->Line(80,126,200,126);
$pdf->Line(80,138,200,138);
$pdf->Line(80,144,200,144);
$pdf->Line(200,114,200,144);
$pdf->Line(140,114,140,144);
$pdf->Line(110,114,110,144);
$pdf->Line(170,114,170,144);
$pdf->Text(83, 122, 'Segel Atas');
$pdf->Text(83, 133, 'Segel Bawah');
$pdf->Text(83, 142, 'Temperatur');
$pdf->Text(143, 122, 'Jam Berangkat');
$pdf->Text(143, 133, 'Jam Tiba');
$pdf->Text(143, 142, 'No. SO');
$pdf->Text(15, 150, 'Kuantitas (Liter)');
$pdf->Text(45, 150, Terbilang($jumlah));
$pdf->Line(45,152,200,152);
$pdf->Text(15,162,'Note:');
// Garis Posisi Left=30, Baris=160, Panjang = 200, Sampai Baris = 160
$pdf->Line(30,158,200,158);
$pdf->Line(30,158,30,210);
$pdf->Line(30,210,200,210);
$pdf->Line(200,158,200,210);
//$pdf->SetX($left5 += 70); $pdf->Cell(20, $h1, '', 1, 0, 'L',true);
$pdf->Text(35, 165, '-');
$pdf->Text(40, 165, 'Aktual Penerimaan BBM');
$pdf->Line(90,161,96,161);
$pdf->Line(90,165,96,165);
$pdf->Line(90,161,90,165);
$pdf->Line(96,161,96,165);
$pdf->Text(100,165, 'Sesuai');
$pdf->Line(120,161,126,161);
$pdf->Line(120,165,126,165);
$pdf->Line(120,161,120,165);
$pdf->Line(126,161,126,165);
$pdf->Text(130,165, 'Tidak Sesuai');
$pdf->SetFont('Times','B',11);
$pdf->Text(35, 175, 'Keterangan');
$pdf->SetFont('Times','',11);
$pdf->Text(35, 180, '-');
$pdf->Text(40, 180, 'Sebelum unit meninggalkan tempat penyerahan dan/atau sebelum ditandatanganinya Surat DO (Tanda ');
$pdf->Text(40, 185, 'Terima) ini mohon periksa kembali kualitas dan kuantitas BBM yang diterima ');
$pdf->Text(35, 190, '-');
$pdf->Text(40, 190, 'Di  luar tanggung  jawab penyalur / Transportir apabila ada  komplain terhadap kualitas dan kuantitas');
$pdf->Text(40, 195, 'BBM yang diterima jika  unit  Pengirim  telah meninggalkan  tempat  penyerahan dan/atau  Surat DO');
$pdf->Text(40, 200, '(Tanda Terima) ini telah ditanda tangani oleh kedua belah pihak.');
$pdf->Line(15,220,200,220);
$pdf->Line(15,228,200,228);
$pdf->Line(15,250,200,250);
$pdf->Line(15,258,200,258);
$pdf->Line(15,266,200,266);
$pdf->Line(15,220,15,266);
$pdf->Line(62,228,62,266);
$pdf->Line(109,220,109,266);
$pdf->Line(156,220,156,266);
$pdf->Line(200,220,200,266);
$pdf->Text(52, 225, 'Mengetahui');
$pdf->Text(126, 225, 'Pengirim');
$pdf->Text(160, 225, 'diterima dan disetujui');
$pdf->Text(115,255,$noplat);
$pdf->Text(115,264,$nmsopir);
$pdf->Text(20,255,'Hero');
$pdf->Text(20,264,'M. Operasional');
$pdf->Text(70,255,'Dianing Wulan');
$pdf->Text(70,264,'Keuangan');
$pdf->SetFont('Times','',7);
$pdf->Text(15,275,'1. Lembar Asli (Putih) untuk Customer');
$pdf->Text(15,279,'2. Lembar warna biru untuk Transportir');
$pdf->Text(160,275,'3. Lembar warna hijau untuk Agen');
$pdf->Text(160,279,'4. Lembar warna kuning untuk File');
$pdf->Output($notrans.'.PDF','I');
unlink('temp/'.$namafile);
unlink('temp/'.$namafile1);
?>
