<?php
include '../../koneksi.php';
$notrans = $_POST['notrans'];
$nip = $_POST['no_id'];
$cek = $_POST['cek'];
$lama = $_POST['lama'];
$tglselesai = date('Y-m-d',strtotime($_POST['tglselesai']));
$data = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM cuti WHERE notrans='$notrans'"));
$hakcuti = $data['hakcuti'];
$tglmulai = $data['tglmulai'];

//$lama = date_diff($tglmulai,$tglselesai);
$row = mysql_num_rows(mysqli_query($conn,"SELECT * FROM cuti WHERE notrans='$notrans'"));
if($row>0){
	if ($cek == 'Y'){
		$text = "update cuti set cek='$cek', tglselesai='$tglselesai', realisasi='$tglselesai' WHERE notrans='$notrans'";
		mysqli_query($conn,$text);
	  $updatesaldo = "UPDATE saldocuti set pakai = pakai + $lama where hakcuti='$hakcuti' and no_id='$nip'";
	  mysqli_query($conn,$updatesaldo);
		echo "Approval Sukses";
	}else{
		echo "Pilih Approval Yes Dulu";
	}
}else{
	echo "Tidak ada data yang di Approval $nip";
}
?>
