<script type="text/javascript">
var url;
function create(){
	$('#dialog-form').dialog('open').dialog('setTitle','Tambah Data');
	$('#form').form('clear');
}

function save(){
	var no_id = $("#no_id").val();
	var string = $("#form").serialize();
	if(nama.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, no_id tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#no_id").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/cuti/simpansaldo.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function save1(){
	var no_id = $("#no_id").val();
	var string = $("#form").serialize();
	if(nama.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, no_id tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#no_id").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/cuti/simpanedit.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function hapus(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row){
		$.messager.confirm('Confirm','Apakah Anda akan menghapus data ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/cuti/hapusaldo.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}
}
function update(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-real').dialog('open').dialog('setTitle','Realisasi Cuti');
		$('#real').form('load',row);
	}
}

function fresh(){
	$('#datagrid-crud').datagrid('reload');
}
function doSearch(value){
	$('#datagrid-crud').datagrid('load',{
        cari: value
    });
}

$(function() {
    $('#cek').change(function() {
        if ($(this).val() == 'Y') {
            console.log(true);
            $('#no_id').removeAttr('disabled');
        }
        else {
            console.log(false);
            $('#no_id').attr('disabled', 'disabled');
        }
    });
});
</script>
</head>
<body>
	<table id="datagrid-crud" title="Master Vendor" class="easyui-datagrid" style="width:auto; height:auto;" url="transaksi/cuti/jsonsaldo.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
            <th data-options="field:'no_id'" sortable="true">N I K</th>
            <th data-options="field:'nama'" sortable="true">Nama</th>
            <th data-options="field:'tglproses'">Tanggal</th>
            <th data-options="field:'hakcuti'">Hak Cuti</th>
						<th data-options="field:'saldo'">Saldo</th>
						<th data-options="field:'pakai'">pakai</th>
            <th data-options="field:'cutilebaran'">CB Lebaran</th>
            <th data-options="field:'cutinataru'">CB Nataru</th>
            <th data-options="field:'notrans'" sortable="true">No Trans</th>
        </tr>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px;">
		<div style="float:left;">
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-bookmark-o fa-lg" plain="true" onclick="create()">Approval</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-calendar fa-lg" plain="true" onclick="update()">Realisasi</a>
      <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-refresh fa-lg" plain="true" onclick="fresh()">Refresh</a>
		</div>
		<div style="float:right;">
        	Pencarian <input id="cari" class="easyui-searchbox" data-options="prompt:'Cari no_id / Nama..',searcher:doSearch" style="width:200px"></input>
		</div>
	</div>

<!-- Dialog Form -->
<div id="dialog-form" class="easyui-dialog" style="width:400px; height:520px; padding: 10px 20px" closed="true" buttons="#dialog-buttons">
	<form id="form" method="post" novalidate>
		<div class="form-item">
			<label for="type">Proses All</label><br />
			<select type="text" name="cek" id="cek" class="easyui-combobox" required="true" style="width:100%">
							<option value="Y">Yes</option>
							<option value="N">No</option></select>
		 </div>
		 <div class="form-item">
 			<label for="type">No Induk Karyawan</label><br />
 			<input type="text" name="no_id" id="no_id" class="easyui-textbox" required="true" style="width:100%">
 		</div>
		<div class="form-item">
			<label for="type">Hak Cuti Tahun</label><br />
			<input type="text" name="hakcuti" id="hakcuti" class="easyui-textbox" required="true" style="width:100%">
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="dialog-buttons">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-ok" onclick="save()">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" onclick="javascript:jQuery('#dialog-form').dialog('close')">Batal</a>
</div>


<!-- Dialog Realisasi -->
<div id="dialog-real" class="easyui-dialog" style="width:600px; height:520px; padding: 10px 20px" closed="true" buttons="#dialog-real">
	<form id="real" method="post" novalidate>
		<div class="form-item">
			<label for="type">No. ID &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Nama</label><br />
			<input type="text" name="no_id" id="no_id" class="easyui-textbox" required="true" style="width:32%"/>
			<input type="text" name="nama" id="nama" class="easyui-textbox" required="true" style="width:67%">
		</div>
		<div class="form-item">
			<label for="type">Tanggal Realisasi</label><br />
			<input type="text" name="tglselesai" id="tglselesai" class="easyui-datebox" required="true" style="width:28%">

		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="dialog-real">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-ok" onclick="save1()">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" onclick="javascript:jQuery('#dialog-real').dialog('close')">Batal</a>
</div>
</body>
