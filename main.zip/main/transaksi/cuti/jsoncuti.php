<?php
session_start();
include '../../koneksi.php';

//$level = $_SESSION['level'];
$username = $_SESSION['username'];
$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
$rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'tglmulai';
$order = isset($_POST['order']) ? strval($_POST['order']) : 'desc';
$cari = isset($_POST['cari']) ? mysql_real_escape_string($_POST['cari']) : '';

$offset = ($page-1) * $rows;
$where = " where no_id like '%$cari%' and (app1 = '$username' or app2 = '$username') and cek='N'";
$text = "select * from cuti
	$where
	ORDER BY $sort $order
	LIMIT $rows OFFSET $offset";

$result = array();
$result['total'] = mysql_num_rows(mysqli_query($conn,"select * from cuti $where"));
$row = array();

$criteria = mysqli_query($conn,$text);
while($data=mysqli_fetch_array($criteria))
{
  $no_id = $data['no_id'];
  $dt = mysqli_fetch_array(mysqli_query($conn,"select * from karyawan_induk where no_id ='$no_id'"));
	$row[] = array(
		'no_id'=>$data['no_id'],
		'notrans'=>$data['notrans'],
		'tglmulai'=>$data['tglmulai'],
		'tglselesai'=>$data['tglselesai'],
		'keperluan'=>$data['keperluan'],
		'pengganti'=>$data['pengganti'],
    'nama'=>$dt['nama'],
		'nohp'=>$data['nohp'],
		'cek'=>$data['cek'],
		'hakcuti'=>$data['hakcuti'],
		'app1'=>$data['app1'],
    'app2'=>$data['app2'],
		'lama'=>$data['lama'],
    'notrans'=>$data['notrans'],
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
?>
