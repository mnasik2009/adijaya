<html>
<head>

<script type="text/javascript">
var url;
function hapus(){
	$('#hakcuti').textbox('setValue', '');
	$('#nojoa').textbox('setValue', '');
	$('#size').textbox('setValue', '');
	$('#tipe').textbox('setValue', '');
	$('#status').textbox('setValue', '');
	$('#remark').textbox('setValue', '');
	$('#tanggal').textbox('setValue', '');
}

$(function(){
    $('#hakcuti').combogrid({
				panelWidth:400,
				url: 'transaksi/cuti/get_cuti.php?',
				idField:'hakcuti',
				textField:'hakcuti',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'no_id',title:'no_id'},
			    {field:'hakcuti',title:'hakcuti'},
			    {field:'saldo',title:'saldo'},
			    ]],onClickRow:function(rowData){
			                 var val =$('#hakcuti').combogrid('grid').datagrid('getSelected');
											 $('#hakcuti').textbox('setValue', val.hakcuti);
											 $('#saldo').textbox('setValue', val.saldo);
			                                }
						});
	  $('#pengganti').combogrid({
				panelWidth:400,
				url: 'transaksi/cuti/get_kar.php?',
				idField:'no_id',
				textField:'no_id',
				mode:'remote',
				fitColumns:true,
					columns:[[
					{field:'no_id',title:'no_id'},
					{field:'nama',title:'nama'},
					]],onClickRow:function(rowData){
							         var val =$('#pengganti').combogrid('grid').datagrid('getSelected');
												$('#pengganti').textbox('setValue', val.no_id);
							                        }
					});
		});
</script>
</head>
<body>
    <div class="easyui-panel" style="position:relative;padding:20px">
        <header>
            <div class="m-toolbar">
                <div class="m-title">Entry Cuti</div>
            </div>
        </header>
        <form id="ff" method="post" action="transaksi/cuti/simpan.php">
            <div style="margin-bottom:10px">
                <input class="easyui-datebox" id="tgl1"  name="tgl1" label="Tanggal Mulai" labelposition="top" prompt="Tanggal" data-options="editable:false,panelWidth:220,panelHeight:240,iconWidth:30" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input class="easyui-datebox"  id="tgl2"  name="tgl2" label="Tanggal Selesai" labelposition="top" prompt="Taggal" style="width:100%">
            </div>
						<div style="margin-bottom:10px">
                <input class="easyui-textbox"id="lama"  name="lama"  label="Jumlah Hari" labelposition="top" prompt="jumlah cuti" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input class="easyui-textbox"id="keperluan"  name="keperluan"  label="Keperluan" labelposition="top" prompt="keperluan" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input class="easyui-textbox" id="pengganti"  name="pengganti" label="Pengganti" labelposition="top" prompt="petugas ganti" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input class="easyui-textbox" id="nohp"  name="nohp" label="No. Handphone" labelposition="top" prompt="No. Telpon yang bisa dihubungi" style="width:100%">
            </div>
						<div style="margin-bottom:10px">
                <input class="easyui-textbox" id="hakcuti"  name="hakcuti" label="Hak Cuti Tahun" labelposition="top" prompt="Hak Cuti" style="width:100%">
            </div>
						<div style="margin-bottom:10px">
                <input class="easyui-textbox" id="saldo"  name="saldo" label="Saldo" labelposition="top" prompt="Saldo Cuti" style="width:100%">
            </div>
		<footer>
            <div style="text-align:center;margin-top:30px">
				<button type="submit" class="easyui-linkbutton" onclick="$('#ff').submit();" style="width:100%;height:40px" <span style="font-size:16px">Save Data</span></button>
            </div>
        </footer>
        </form>
    </div>
</html>
