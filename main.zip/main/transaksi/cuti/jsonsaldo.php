<?php
session_start();
include '../../koneksi.php';

//$level = $_SESSION['level'];
$username = $_SESSION['username'];
$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
$rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'hakcuti';
$order = isset($_POST['order']) ? strval($_POST['order']) : 'desc';
$cari = isset($_POST['cari']) ? mysql_real_escape_string($_POST['cari']) : '';

$offset = ($page-1) * $rows;
$where = " where no_id like '%$cari%' or hakcuti like '%$cari%'";
$text = "select * from saldocuti
	$where
	ORDER BY $sort $order
	LIMIT $rows OFFSET $offset";

$result = array();
$result['total'] = mysql_num_rows(mysqli_query($conn,"select * from saldocuti $where"));
$row = array();

$criteria = mysqli_query($conn,$text);
while($data=mysqli_fetch_array($criteria))
{
  $no_id = $data['no_id'];
  $dt = mysqli_fetch_array(mysqli_query($conn,"select * from karyawan_induk where no_id like '%$cari%'"));
	$row[] = array(
		'no_id'=>$data['no_id'],
		'notrans'=>$data['notrans'],
		'tglproses'=>$data['tglproses'],
		'hakcuti'=>$data['hakcuti'],
		'saldo'=>$data['saldo'],
		'cutinataru'=>$data['cutinataru'],
    'cutilebaran'=>$dt['nama'],
		'pakai'=>$data['pakai'],
    'notrans'=>$data['notrans'],
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
?>
