<?php
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';
$arr_data=array();
$sql="select * from karyawan_induk where no_id like '%$q%' or nama like '%$q%'";
$result = mysqli_query($conn,$sql);
while($obj = mysqli_fetch_object($result)) {
 $arr_data[]=array("no_id"=>$obj->no_id,"nama"=>$obj->nama);
}

echo json_encode($arr_data);
?>
