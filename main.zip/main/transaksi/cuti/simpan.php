<?php
session_start();
include '../../koneksi.php';

$keperluan = $_POST['keperluan'];
$pengganti = $_POST['pengganti'];
$lama = $_POST['lama'];
$nohp = $_POST['nohp'];
$username = $_SESSION['username'];
$hakcuti = $_POST['hakcuti'];
$tglinput = date('Y-m-d');
$tglmulai = date('Y-m-d',strtotime($_POST['tgl1']));
$tglselesai = date('Y-m-d',strtotime($_POST['tgl2']));
$datakaryawan = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM karyawan_induk WHERE no_id='$username'"));
$divisi = $datakaryawan['divisi'];
$datadepart = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM departemen WHERE kode='$divisi'"));
$tanda1 = $datadepart['tanda1'];
$tanda2 = $datadepart['tanda2'];

$text = "INSERT INTO cuti SET keperluan='$keperluan',
								pengganti='$pengganti',
								tglmulai='$tglmulai',
								tglselesai='$tglselesai',
								nohp='$nohp',
								tglinput ='$tglinput',
								app1='$tanda1',
                app2='$tanda2',
								hakcuti = '$hakcuti',
								no_id='$username',
								lama = '$lama'";
	mysqli_query($conn,$text);
	echo '<script type="text/javascript">alert("Data has been saved Successfully");</script>';
	?><script language="javascript">document.location.href="../../index.php?view=cuti";</script>
