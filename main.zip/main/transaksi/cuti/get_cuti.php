<?php
session_start();
include '../../koneksi.php';
$q = isset($_POST['q']) ? strval($_POST['q']) : '';
$username = $_SESSION['username'];
$arr_data=array();
$sql="select * from saldocuti where no_id='$username' and aktif='Y' and (saldo - pakai) > 0";
$result = mysqli_query($conn,$sql);
while($obj = mysqli_fetch_object($result)) {
 $arr_data[]=array("no_id"=>$obj->no_id,"hakcuti"=>$obj->hakcuti,"saldo"=>$obj->saldo);
}

echo json_encode($arr_data);
?>
