<?php
include '../../koneksi1.php';
$kode = $_POST['id'];
$row = mysql_num_rows(mysqli_query($conn,"SELECT * FROM cuti WHERE notrans='$kode'"));
if($row>0){
	$text = "DELETE FROM cuti
			WHERE notrans='$kode'";
	mysqli_query($conn,$text);
	echo "Hapus Sukses";
}else{
	echo "Tidak ada data yang dihapus $kode";
}
?>
