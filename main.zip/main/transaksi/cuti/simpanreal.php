<?php
include '../../koneksi.php';
$notrans = $_POST['notrans'];
$nip = $_POST['no_id'];
$cek = $_POST['cek'];
$tglselesai = date('Y-m-d',strtotime($_POST['tglselesai']));
$row = mysql_num_rows(mysqli_query($conn,"SELECT * FROM cuti WHERE notrans='$nip'"));
if($row>0){
	$text = "UPDATE cuti set tglselesai='$tglselesai', realisasi='$tglselesai'
			WHERE notrans='$kode'";
	mysqli_query($conn,$text);
	echo "Approval Sukses";
}else{
	echo "Tidak ada data yang di Approval $kode";
}
?>
