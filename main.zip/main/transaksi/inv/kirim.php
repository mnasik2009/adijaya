<?php
session_start();
include '../../koneksi.php';

$userid = $_SESSION['username'];
$tglkirim = date('Y-m-d',strtotime($_POST['tglkirim']));
$tglterima = date('Y-m-d',strtotime($_POST['tglterima']));
$notrans = $_POST['notrans'];
$kodecust = $_POST['kodecust'];
$ekspedisi = $_POST['ekspedisi'];
$noresi = $_POST['noresi'];
$row = mysql_num_rows(mysql_query("SELECT * FROM inv_master WHERE notrans='$notrans'"));
if($row>0){
	$text = "UPDATE inv_master SET tglkirim='$tglkirim',
	 							tglterima='$tglterima',
								ekspedisi = '$ekspedisi',
								noresi = '$noresi'
			WHERE notrans='$notrans'";
	mysql_query($text);
	echo "Update Sukses $notrans";
}else{

	echo "Data Tidak ditemukan untuk transaksi No:  $notrans";
}
?>
