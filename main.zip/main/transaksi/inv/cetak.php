<?php
session_start();
date_default_timezone_set('Asia/Makassar');
require('../../fpdf/fpdf.php');
include '../../koneksi.php';
include '../../phpqrcode/qrlib.php';
include '../../terbilang.php';

$notrans = $_POST['notrans'];
$text = "https://abadijayagroup.id/vipdata/lihatbarcode.php?kode=$notrans";
$id_admin = $_SESSION['id'];
$data = mysql_fetch_array(mysql_query("SELECT * FROM inv_master where notrans='$notrans'"));

$tanggal = date('d-m-Y',strtotime($data['tgltrans']));
$duedate = date('d-m-Y',strtotime($data['duedate']));
$lokasi = $data['lokasi'];
$cofrom = $data['cofrom'];
$pocust = $data['pocust'];
$kodecust = $data['kodecust'];
$jenisbbm = $data['jenisbbm'];
$jumlah = $data['jumlah'];
$harga = $data['harga'];
$top = $data['top'];
$nodo = $data['nodo'];
$shipment = date('d-m-Y',strtotime($data['shipment']));


$totalj = $harga * $jumlah;
$ppn1 = $data['ppn'];
$pbbkb1 = $data['pbbkb'];
$ppn = ($data['ppn'] * $totalj)/100;
$pbbkb = ($data['pbbkb'] * $totalj)/100;
$oat = $data['oat'] * $jumlah;
$total = $totalj + $ppn + $pbbkb + $oat;
$dcus = mysql_fetch_array(mysql_query("SELECT * FROM mitra where kode='$kodecust'"));
$namacust = $dcus['nama'];
$alamatcust = $dcus['alamat'];
$kota = $dcust['kota'];
$notelpcust = $dcus['notelp'];

$dglobal = mysql_fetch_array(mysql_query("SELECT * FROM globalset where kode='$cofrom'"));
$namafr = $dglobal['nama'];
$alamat = $dglobal['alamat'];
$kota = $dglobal['kota'];
$notelp = $dglobal['notelp'];
$direktur = $dglobal['direktur'];
$nohp = $dglobal['nohp'];
$email = $dglobal['email'];
$bri = $dglobal['bri'];
$mandiri = $dglobal['mandiri'];

$point = mysql_fetch_array(mysql_query("SELECT * FROM spoint WHERE kode='$suppoint'"));
$namapoint = $point['nama'];

$tempdir = "temp/";
if (!file_exists($tempdir))
   mkdir($tempdir);
$isi = substr($notrans,0,6);
$namafile = sha1($isi).'.png';
$qua = 'H';
$ukuran = 5;
$padding = 0;
$namafile1 = substr($notrans,1,4).'.png';
$logo = $direktur.sha1($isi);
QRCode::png($text,$tempdir.$namafile,$qua,$ukuran,$padding);
QRCode::png($logo,$tempdir.$namafile1,$qua,$ukuran,$padding);
// Insert a logo in the top-left corner at 300 dpi
$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();
if ($kodecust == 'AJ0001'){
  $pdf->Image('../../dist/img/logo_aj.png',10,10,70,20);
  $pt = 'PT. ABADI JAYA';
}else{
  $pdf->Image('../../dist/img/logo_paj.png',10,10,70,20);
  $pt = 'PT. PRIMA ABADI JAYA';
}

$pdf->Image('../../dist/img/patra.png',140,10,40,20);
$pdf->Image('temp/'.$namafile,148,30,20,20);
//$pdf->Image('temp/'.$namafile1,148,230,20,20);
$pdf->Ln();
$pdf->SetFont('Times','',11);

// Membuat Dari
$pdf->Text(15, 40, 'Kepada:');
$pdf->Text(15, 45, $namacust);
$pdf->Text(15, 50, $alamat);
$pdf->Text(15, 55, $kota);
$pdf->Text(15, 60, 'Telp. '.$notelp);

// Membuat Nomor Penawaran
$pdf->SetFont('Times','B',16);
$pdf->Text(120, 58, 'I N V O I C E');
$pdf->SetFont('Times','',11);
$pdf->Text(120, 65, 'Nomor');
$pdf->Text(145, 65, ':');
$pdf->Text(148, 65, $notrans);
$pdf->Text(120, 70, 'Tanggal');
$pdf->Text(145, 70, ':');
$pdf->Text(148, 70, 'Samarinda, '.$tanggal);
//$pdf->Text(120, 75, 'ID Customer');
//$pdf->Text(145, 75, ':');
//$pdf->Text(148, 75, $kodecust);

// Bagian kepada / Customer
$pdf->SetFont('Times','B',11);
$pdf->Text(15, 70, 'Site');
$pdf->SetFont('Times','',11);
$pdf->Text(15, 75, $lokasi);

// tabel
$pdf->ln(75);
$h = 8;
$h0 = 5;
$h1 = 6;
$left = 15;
$left1 = 15;
//$top = 80;
$left2 = 15;
$left3 = 15;
$left4 = 15;
$left5 = 40;
$left6 = 40;
$left7 = 40;
$left8 = 40;
$left9 = 40;
$left10 = 40;
$left10 = 15;
#tableheader
$pdf->SetFillColor(200,200,200);
$left = $pdf->GetX();
$left0 = $pdf->GetX();
$left1 = $pdf->GetX();
$left2 = $pdf->GetX();
$left3 = $pdf->GetX();
$left4 = $pdf->GetX();
$left5 = $pdf->GetX();
$left6 = $pdf->GetX();
$left7 = $pdf->GetX();
$left8 = $pdf->GetX();
$left9 = $pdf->GetX();
$left10 = $pdf->GetX();
$left11 = $pdf->GetX();
$pdf->SetFont('Times','B',11);
$pdf->SetX($left += 0);$pdf->Cell(35,$h,'No. PO',1,0,'C',true);
$pdf->SetX($left += 35); $pdf->Cell(35, $h, 'Tgl Kirim', 1, 0, 'C',true);
$pdf->SetX($left += 35); $pdf->Cell(30, $h, 'Pengiriman', 1, 0, 'C',true);
$pdf->SetX($left += 30); $pdf->Cell(30, $h, 'Tipe Servis', 1, 0, 'C',true);
$pdf->SetX($left += 30); $pdf->Cell(30, $h, 'Terms', 1, 0, 'C',true);
$pdf->SetX($left += 30); $pdf->Cell(30, $h, 'Jatuh Tempo', 1, 0, 'C',true);
$pdf->SetFont('Times','',11);
$pdf->ln();
$pdf->SetFillColor(255,255,255);
$pdf->SetX($left1 += 0);$pdf->Cell(35,$h1,$pocust,1,0,'C',true);
$pdf->SetX($left1 += 35); $pdf->Cell(35, $h1, $shipment, 1, 0, 'C',true);
$pdf->SetX($left1 += 35); $pdf->Cell(30, $h1, 'Darat', 1, 0, 'C',true);
$pdf->SetX($left1 += 30); $pdf->Cell(30, $h1, 'Fuel + Trans', 1, 0, 'C',true);
$pdf->SetX($left1 += 30); $pdf->Cell(30, $h1, $top, 1, 0, 'C',true);
$pdf->SetX($left1 += 30); $pdf->Cell(30, $h1, $duedate, 1, 0, 'C',true);
$pdf->ln(10);
$pdf->SetFont('Times','B',11);
$pdf->SetFillColor(200,200,200);
$pdf->SetX($left2 += 0);$pdf->Cell(20,$h,'Item',1,0,'C',true);
$pdf->SetX($left2 += 20); $pdf->Cell(50, $h, 'Deskripsi', 1, 0, 'C',true);
$pdf->SetX($left2 += 50); $pdf->Cell(30, $h, 'DO', 1, 0, 'C',true);
$pdf->SetX($left2 += 30); $pdf->Cell(18, $h, 'Qty', 1, 0, 'C',true);
$pdf->SetX($left2 += 18); $pdf->Cell(12, $h, 'UOM', 1, 0, 'C',true);
$pdf->SetX($left2 += 12); $pdf->Cell(30, $h, 'Harga', 1, 0, 'C',true);
$pdf->SetX($left2 += 30); $pdf->Cell(30, $h, 'Total', 1, 0, 'C',true);
$pdf->ln();
$pdf->SetFont('Times','',11);
$pdf->SetFillColor(255,255,255);
$pdf->SetX($left3 += 0);$pdf->Cell(20,$h,'1',1,0,'C',true);
$pdf->SetX($left3 += 20); $pdf->Cell(50, $h, $jenisbbm, 1, 0, 'C',true);
$pdf->SetX($left3 += 50); $pdf->Cell(30, $h, $nodo, 1, 0, 'C',true);
$pdf->SetX($left3 += 30); $pdf->Cell(18, $h, $jumlah, 1, 0, 'C',true);
$pdf->SetX($left3 += 18); $pdf->Cell(12, $h, 'Liter', 1, 0, 'C',true);
$pdf->SetX($left3 += 12); $pdf->Cell(30, $h, number_format($harga,2), 1, 0, 'C',true);
$pdf->SetX($left3 += 30); $pdf->Cell(30, $h, number_format($totalj,2), 1, 0, 'R',true);
$pdf->ln();
$pdf->SetX($left4 += 100);$pdf->Cell(60,$h1,'SUB TOTAL',1,0,'L',true);
$pdf->SetX($left4 += 60);$pdf->Cell(30,$h1,number_format($totalj,2),1,0,'R',true);
$pdf->ln();
//$pdf->SetX($left5 += 20);$pdf->Cell(20,$h1,'',1,0,'C',true);
$pdf->SetX($left5 += 100); $pdf->Cell(60, $h1, 'PPN   ( '.$ppn1.' % )', 1, 0, 'L',true);
$pdf->SetX($left5 += 60);$pdf->Cell(30,$h1,number_format($ppn,2),1,0,'R',true);
$pdf->ln();
$pdf->SetX($left6 += 100); $pdf->Cell(60, $h1, 'PBBKB   ( '.$pbbkb1.' % )', 1, 0, 'L',true);
$pdf->SetX($left6 += 60);$pdf->Cell(30,$h1,number_format($pbbkb,2),1,0,'R',true);
$pdf->ln();
$pdf->SetX($left7 += 100); $pdf->Cell(60, $h1, '-', 1, 0, 'L',true);
$pdf->SetX($left7 += 60);$pdf->Cell(30,$h1,'',1,0,'R',true);
$pdf->ln();
$pdf->SetX($left8 += 100); $pdf->Cell(60, $h1, 'OAT', 1, 0, 'L',true);
$pdf->SetX($left8 += 60);$pdf->Cell(30,$h1,number_format($oat,2),1,0,'R',true);
$pdf->ln();
$pdf->SetX($left9 += 100); $pdf->Cell(60, $h1, '-', 1, 0, 'L',true);
$pdf->SetX($left9 += 60);$pdf->Cell(30,$h1,'',1,0,'R',true);
$pdf->ln();
$pdf->SetFont('Times','B',11);
$pdf->SetX($left10 += 100); $pdf->Cell(60, $h1, 'TOTAL KESELURUHAN', 1, 0, 'C',true);
$pdf->SetX($left10 += 60);$pdf->Cell(30,$h1,number_format($total,2),1,0,'R',true);
$pdf->SetFont('Times','',11);
$pdf->ln();
$pdf->Text(10, 170, 'Terbilang : ');
$pdf->SetFont('Times','BI',10);
$pdf->ln(10);
$pdf->SetX($left11 += 0); $pdf->Cell(190, $h1, penyebut($total).' Rupiah', 1, 0, 'L',true);
$pdf->SetFont('Times','',11);
$pdf->Text(15, 185, 'Keterangan Tambahan');
$pdf->Text(15, 190, '1.');
$pdf->Text(20, 190, 'Mohon cantumkan No. Invoice dalam berita acara pembayaran');
$pdf->Text(15, 195, '2.');
$pdf->Text(20, 195, 'Pembayaran di transfer melalui rekening '.$pt.' sebagai berikut:');
$pdf->Text(15, 200, '');
$pdf->Text(20, 200, 'Bank Rakyat Indonesia');
$pdf->Text(65, 200, ':');
$pdf->SetFont('Times','B',11);
$pdf->Text(70, 200, $bri);
$pdf->SetFont('Times','',11);
$pdf->Text(15, 205, '');
$pdf->Text(20, 205, 'Bank Mandiri');
$pdf->Text(65, 205, ':');
$pdf->SetFont('Times','B',11);
$pdf->Text(70, 205, $mandiri);
$pdf->SetFont('Times','',11);
$pdf->Text(15, 210, '3.');
$pdf->Text(20, 210, 'Pembayaran dengan Cek / Giro dianggap sah apabila telah dicairkan');
$pdf->SetFont('Times','',11);
$pdf->Text(140,215, 'Hormat Kami');
$pdf->SetFont('Times','B',11);
//$pdf->Text(140,225, $namafr);
$pdf->Text(140,255, $namafr);

$tglprint = date('d-M-Y');
$pref = date('His');
$pdf->SetFont('Times','',9);
$pdf->Text(15,280, 'Keterangan: Invoice ini di buat dan tercatat berdasarkan Sistem' );
$pdf->SetFont('Times','I',9);
$pdf->Text(15,285, 'Print Date: '.$tglprint.' by '.$pref.'-'.$id_admin);
$pdf->Output($notrans.'.PDF','I');
unlink('temp/'.$namafile);
unlink('temp/'.$namafile1);
?>
