<?php
session_start();
include '../../koneksi.php';

$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
$rows = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'tgltrans';
$order = isset($_POST['order']) ? strval($_POST['order']) : 'desc';
$cari = isset($_POST['cari']) ? mysql_real_escape_string($_POST['cari']) : '';
$cabang = $_SESSION['cabang'];

$offset = ($page-1) * $rows;

$where = " WHERE cabang='$cabang' and (notrans LIKE '%$cari%' OR kodecust LIKE '%$cari%') ";

$text = "SELECT * FROM inv_master
	$where
	ORDER BY $sort $order
	LIMIT $rows OFFSET $offset";

$result = array();
$result['total'] = mysql_num_rows(mysql_query("SELECT * FROM inv_master $where"));
$row = array();

$criteria = mysql_query($text);
while($data=mysql_fetch_array($criteria))
{
	$kodecust = $data['kodecust'];
	$datacust = mysql_fetch_array(mysql_query("select * from mitra where kode='$kodecust'"));
	$row[] = array(
		'notrans'=>$data['notrans'],
		'tgltrans'=>date('m/d/Y', strtotime($data['tgltrans'])),
		'kodecust'=>$data['kodecust'],
		'namacust'=>$datacust['nama'],
		'shipment'=>date('m/d/Y', strtotime($data['shipment'])),
		'jenisbbm'=>$data['jenisbbm'],
    	'uom'=>$data['uom'],
		'jumlah'=>$data['jumlah'],
		'harga'=>$data['harga'],
		'top'=>$data['top'],
		'pocust'=>$data['pocust'],
		'ppn'=>$data['ppn'],
		'pbbkb'=>$data['pbbkb'],
		'oat'=>$data['oat'],
		'cofrom'=>$data['cofrom'],
		'lokasi'=>$data['lokasi'],
		'duedate'=>$data['duedate'],
		'faktur'=>$data['faktur'],
		'noso'=>$data['noso'],
		'approval'=>$data['approval'],
		'tglkirim'=>$data['tglkirim'],
		'ekspedisi'=>$data['ekspedisi'],
		'noresi'=>$data['noresi'],
		'tglterima'=>$data['tglterima'],
	);
}
$result=array_merge($result,array('rows'=>$row));
echo json_encode($result);
?>
