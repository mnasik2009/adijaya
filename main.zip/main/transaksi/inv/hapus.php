<?php
include '../../koneksi.php';
$notrans = $_POST['id'];
$row = mysql_num_rows(mysql_query("SELECT * FROM inv_master WHERE notrans='$notrans'"));
if($row>0){
	$text = "DELETE FROM inv_master
			WHERE notrans='$notrans'";
	mysql_query($text);
	echo "Hapus Sukses";
}else{
	echo "Tidak ada data yang dihapus $notrans";
}
?>
