<html>
<head>
	<meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../../easyui/themes/material/easyui.css">
    <link rel="stylesheet" type="text/css" href="../../easyui/themes/icon.css">
    <script type="text/javascript" src="../../easyui/jquery.min.js"></script>
    <script type="text/javascript" src="../../easyui/jquery.easyui.min.js"></script>
<?php
//koneksi ke database, username,password  dan namadatabase menyesuaikan
include "../../koneksi.php";
//memanggil file excel_reader
$kode = $_GET['kode'];
if(isset($_POST['submit'])){
$kode = $_POST['nomor'];
$faktur = basename($_FILES['faktur']['name']) ;
move_uploaded_file($_FILES['faktur']['tmp_name'], 'temp/'.$faktur);
//$fotosim = basename($_FILES['fotosim']['name']) ;
//move_uploaded_file($_FILES['fotosim']['tmp_name'], 'images/'.$fotosim);
$//fotonpwp = basename($_FILES['fotonpwp']['name']) ;
//move_uploaded_file($_FILES['fotonpwp']['tmp_name'], 'images/'.$fotonpwp);
//$foto = basename($_FILES['foto']['name']) ;
//move_uploaded_file($_FILES['foto']['tmp_name'], 'images/'.$foto);
$tglinput = date('Y-m-d');

$query = "update inv_master set faktur = '$faktur' where notrans='$kode'";
$hasil = mysql_query($query);

if(!$hasil){
//          jika import gagal
    die(mysql_error());
}else{
//          jika impor berhasil
   echo "Data berhasil diimpor.";
}
}
?>
<body>
    <div id="p" class="easyui-panel" title="Import Data" style="width:575px;height:300px;padding:10px;">
    <form name="myForm" id="myForm" method="post" action="aksi.php" enctype="multipart/form-data">
		<div class="form-item">
			<label for="notrans">Kode</label>
			<input type="text" name="nomor" id="nomor" value="<?php echo $kode; ?>" class="easyui-textbox" required="true"style="width:100%"/>
		</div>
		<div style="margin-bottom:20px">
				<input id="faktur" name="faktur" class="easyui-filebox" label="Upload Faktur" labelPosition="top" data-options="prompt:'Choose a file...'" style="width:100%">
		</div>
		<br/>
		<input type="submit" name="submit" value="Upload" /><br/>

	</form>
    </div>
</body>
<script type="text/javascript">
//    validasi form (hanya file .xls yang diijinkan)
    function validateForm()
    {
        function hasExtension(inputID, exts) {
            var fileName = document.getElementById(inputID).value;
            return (new RegExp('(' + exts.join('|').replace(/\./g, '\\.') + ')$')).test(fileName);
        }

        if(!hasExtension('namafile', ['.pdf'])){
            alert("Hanya file PDF yang diizinkan.");
            return false;
        }
    }
</script>
</html>
