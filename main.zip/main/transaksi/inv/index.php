<script type="text/javascript">
var url;
function create(){
	$('#dialog-form').dialog('open').dialog('setTitle','Tambah Data');
	$('#form').form('clear');
}
function save(){
	document.getElementById("jenisbbm").removeAttribute('disabled');
	document.getElementById("uom").removeAttribute('disabled');
	document.getElementById("harga").removeAttribute('disabled');
	document.getElementById("ppn").removeAttribute('disabled');
	document.getElementById("pbbkb").removeAttribute('disabled');
	document.getElementById("oat").removeAttribute('disabled');
	var notrans = $("#notrans").val();
	var string = $("#form").serialize();
	if(tgltrans.length==0){
		$.messager.show({
			title:'Info',
			msg:'Maaf, notrans tidak boleh kosong',
			timeout:2000,
			showType:'slide'
		});
		$("#notrans").focus();
		return false();
	}

	$.ajax({
		type	: "POST",
		url		: "transaksi/inv/simpan.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function savekirim(){
	var notrans = $("#notrans").val();
	var string = $("#form-kirim").serialize();
	$.ajax({
		type	: "POST",
		url		: "transaksi/inv/kirim.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}

function saveintern(){
	var notrans = $("#notrans").val();
	var string = $("#form-intern").serialize();
	$.ajax({
		type	: "POST",
		url		: "transaksi/inv/saveintern.php",
		data	: string,
		success	: function(data){
			$.messager.show({
				title:'Info',
				msg:data, //'Password Tidak Boleh Kosong.',
				timeout:2000,
				showType:'slide'
			});
			$('#datagrid-crud').datagrid('reload');
		}
	});
}


function hapus(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.approval == 'N'){
		$.messager.confirm('Confirm','Apakah Anda akan menghapus data ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/inv/hapus.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dihapus, krn sudah di Approve',
		timeout:2000,
		showType:'slide'
	});
	}
}

function approve(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.approval == 'N'){
		$.messager.confirm('Confirm','Apakah Approve Invoice ini ?',function(r){
			if (r){
				$.ajax({
					type	: "POST",
					url		: "transaksi/inv/approve.php",
					data	: 'id='+row.notrans,
					success	: function(data){
						$.messager.show({
							title:'Info',
							msg:data, //'Password Tidak Boleh Kosong.',
							timeout:2000,
							showType:'slide'
						});
						$('#datagrid-crud').datagrid('reload');
					}
				});
			}
		});
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa dihapus, krn sudah di Approve',
		timeout:2000,
		showType:'slide'
	});
	}
}

function update(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if(row){
		$('#dialog-form').dialog('open').dialog('setTitle','Edit Data');
		$('#form').form('load',row);
	}
}

function cetak(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.approval == 'Y'){
		$('#dialog-excel').dialog('open').dialog('setTitle','Cetak Data');
		$('#form-excel').form('load',row);
	}else{
		$.messager.show({
		title:'Info',
		msg:'Data tidak bisa di Print karena belum Approve',
		timeout:2000,
		showType:'slide'
	});
	}

}

function kirim(){
	var row = $('#datagrid-crud').datagrid('getSelected');
		$('#dialog-kirim').dialog('open').dialog('setTitle','Kirim dan Terima');
		$('#form-kirim').form('load',row);

}

function ambil(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.faktur == ''){
		$.messager.show({
		title:'Info',
		msg:'File / Data Tidak Ada',
		timeout:2000,
		showType:'slide'
	});
	}else{
		$('#dialog-download').dialog('open').dialog('setTitle','Download File');
		$('#form-download').form('load',row);
	}

}

function lihat(){
	var row = $('#datagrid-crud').datagrid('getSelected');
	if (row.faktur == ''){
		$.messager.show({
		title:'Info',
		msg:'File / Data Tidak Ada',
		timeout:2000,
		showType:'slide'
	});
	}else{
		$('#dialog-lihat').dialog('open').dialog('setTitle','Lihat File');
		$('#form-lihat').form('load',row);
	}

}
function createinv(){
	var row = $('#datagrid-crud').datagrid('getSelected');
		$('#dialog-intern').dialog('open').dialog('setTitle','Create Invoice Internal');
		$('#form-intern').form('load',row);

}

function fresh(){
	$('#datagrid-crud').datagrid('reload');
}
function doSearch(value){
	$('#datagrid-crud').datagrid('load',{
        cari: value
    });
}

$(function(){
    $('#kodecust').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_cust.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
					{field:'nohp',title:'nohp'},
			    ]],onClickRow:function(rowData){
			                 var val =$('#kodesupp').combogrid('grid').datagrid('getSelected');
											 $('#kodesupp').textbox('setValue', val.kode);
			                                }
						});
	$('#jenisbbm').combogrid({
				panelWidth:400,
				url: 'transaksi/_get/get_bbm.php?',
				idField:'kode',
				textField:'kode',
				mode:'remote',
				fitColumns:true,
			    columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'keterangan',title:'keterangan'},
		    ]],onClickRow:function(rowData){
		                 var val =$('#jenisbbm').combogrid('grid').datagrid('getSelected');
										 $('#jenisbbm').textbox('setValue', val.kode);
		             }
			});
	$('#cofrom').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_pt.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    columns:[[
		    {field:'kode',title:'kode'},
		    {field:'nama',title:'nama'},
		    {field:'alamat',title:'alamat'},
				{field:'kota',title:'kota'},
	    ]],onClickRow:function(rowData){
	                var val =$('#cofrom').combogrid('grid').datagrid('getSelected');
								 $('#cofrom').textbox('setValue', val.kode);
	          }
				});
  $('#spoint').combogrid({
			panelWidth:400,
			url: 'transaksi/_get/get_spoint.php?',
			idField:'kode',
			textField:'kode',
			mode:'remote',
			fitColumns:true,
	    	columns:[[
			    {field:'kode',title:'kode'},
			    {field:'nama',title:'nama'},
			    {field:'alamat',title:'alamat'},
					{field:'pic',title:'pic'},
	    ]],onClickRow:function(rowData){
	              var val =$('#spoint').combogrid('grid').datagrid('getSelected');
								 $('#spoint').textbox('setValue', val.kode);
	          }
			});
	$('#noso').combogrid({
		panelWidth:400,
		url: 'transaksi/_get/get_pc.php?',
		idField:'notrans',
		textField:'notrans',
		mode:'remote',
		fitColumns:true,
		columns:[[
			{field:'notrans',title:'notrans'},
			{field:'tgltrans',title:'tgltrans'},
			{field:'kodecust',title:'kodecust'},
			{field:'namacust',title:'nama'},
			{field:'jenisbbm',title:'jenisbbm'},
			{field:'harga',title:'harga'},
			{field:'ppn',title:'ppn'},
			{field:'pbbkb',title:'pbbkb'},
			{field:'top',title:'top'},
			{field:'oat',title:'oat'},
			{field:'cofrom',title:'cofrom'},
			{field:'lewat',title:'lewat'},
			{field:'angkutan',title:'angkutan'},
			{field:'pocust',title:'pocust'},
			]],onClickRow:function(rowData){
							var val =$('#noso').combogrid('grid').datagrid('getSelected');
							$('#noso').textbox('setValue', val.notrans);
							$('#kodecust').textbox('setValue', val.kodecust);
							$('#jenisbbm').textbox('setValue', val.jenisbbm);
							$('#jumlah').textbox('setValue', val.jumlah);
							$('#harga').textbox('setValue', val.harga);
							$('#ppn').textbox('setValue', val.ppn);
							$('#pbbkb').textbox('setValue', val.pbbkb);
							$('#top').textbox('setValue', val.top);
							$('#oat').textbox('setValue', val.oat);
							$('#cofrom').textbox('setValue',val.cofrom);
							$('#validto').textbox('setValue',val.validto);
							$('#uom').textbox('setValue','Liter');
							$('#lewat').textbox('setValue',val.lewat);
							$('#angkutan').textbox('setValue',val.angkutan);
							$('#shipment').textbox('setValue',val.shipment);
							$('#pocust').textbox('setValue', val.pocust);
				}
			});
	});
</script>
</head>
<body>

	<div style="margin:10px 0;"></div>

	<table id="datagrid-crud" title="Create Invoice" class="easyui-datagrid" style="width:auto; height: auto;" url="transaksi/inv/json.php" toolbar="#tb" pagination="true" rownumbers="true" fitColumns="true" singleSelect="true" collapsible="true">
    <thead>
        <tr>
            <th data-options="field:'notrans'" sortable="true">No Trans </th>
            <th data-options="field:'kodecust'" sortable="true">Kode </th>
			<th data-options="field:'namacust'" sortable="true">Nama </th>
            <th data-options="field:'tgltrans'">Tanggal</th>
            <th data-options="field:'shipment'">Berlaku</th>
            <th data-options="field:'jenisbbm'">BBM</th>
			<th data-options="field:'jumlah'">Jumlah</th>
			<th data-options="field:'uom'">UOM</th>
			<th data-options="field:'harga'">Harga</th>
			<th data-options="field:'ppn'">PPN</th>
			<th data-options="field:'pbbkb'">PBBKB</th>
			<th data-options="field:'oat'">OAT</th>
			<th data-options="field:'top'">TOP</th>
			<th data-options="field:'cofrom'">CO From</th>
			<th data-options="field:'lokasi'">Job SIte</th>
			<th data-options="field:'pocust'">PO# Customer</th>
			<th data-options="field:'tglkirim'">Tgl Kirim</th>
			<th data-options="field:'ekspedisi'">Ekspedisi</th>
			<th data-options="field:'noresi'">No Resi</th>
			<th data-options="field:'tglterima'">Tgl Terima</th>
			<th data-options="field:'approval'">Approval</th>
			<th data-options="field:'faktur'">Faktur</th>
        </tr>
    </thead>
	</table>
    <div id="tb" style="padding:2px;height:30px;">
		<div style="float:left;">
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-plus-square-o fa-lg" plain="true" onclick="create()">Tambah</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-pencil-square-o fa-lg" plain="true" onclick="update()">Edit</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-minus-square-o fa-lg" plain="true" onclick="hapus()">Hapus</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-check fa-lg" plain="true" onclick="approve()">Approval</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-file-pdf-o fa-lg" plain="true"
				onclick="javascript:wincal=window.open('transaksi/inv/aksi.php?kode='+$('#datagrid-crud').datagrid('getSelected').notrans
			,'popuppage','width=600,toolbar=0,resizable=0,scrollbars=yes,height=350,top=100,left=100');">Upload Faktur</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-download fa-lg" plain="true" onclick="ambil()">Download</a>
			<!--a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-newspaper-o fa-lg" plain="true"
				onclick="javascript:wincal=window.open('transaksi/inv/lihat.php?kode='+$('#datagrid-crud').datagrid('getSelected').faktur
			,'popuppage','width=600,toolbar=0,resizable=0,scrollbars=yes,height=350,top=100,left=100');">Viw File</a-->
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-picture-o fa-lg" plain="true" onclick="lihat()"> Lihat Faktur</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" plain="true" onclick="cetak()">Print</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-external-link fa-lg" plain="true" onclick="kirim()">Kirim</a>
       		<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-refresh fa-lg" plain="true" onclick="fresh()">Refresh</a>
			<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-money fa-lg" plain="true" onclick="createinv()">Inv Internal</a>
		</div>
		<div style="float:right;">
        	Pencarian <input id="cari" class="easyui-searchbox" data-options="prompt:'Cari notrans / kodesupp..',searcher:doSearch" style="width:200px"></input>
		</div>
	</div>

<!-- Dialog Form -->
<div id="dialog-form" class="easyui-dialog" style="width:600px; height:650px; padding: 10px 20px" closed="true" buttons="#dialog-buttons">
	<form id="form" method="post" novalidate>
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No PO</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="noso" id="noso" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Supplier &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Shipment Date</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="shipment" id="shipment" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="tgltrans">Volume (Jumlah)</label><br />
			<input type="text" name="jumlah" id="jumlah" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="validto">Jenis BBM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; UOM &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Harga</label><br />
			<input type="text" name="jenisbbm" id="jenisbbm" class="easyui-textbox" required="true" style="width:30%" />
			<input type="text" name="uom" id="uom" class="easyui-textbox" required="true" style="width:30%" />
			<input type="text" name="harga" id="harga" class="easyui-textbox" required="true" style="width:38%" />
		</div>
		<div class="form-item">
			<label for="jenisbbm">PPN (%) &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PBBKB (%)&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; OAT</label><br />
			<input type="text" name="ppn" id="ppn" class="easyui-textbox" required="true" style="width:30%" />
			<input type="text" name="pbbkb" id="pbbkb" class="easyui-textbox" required="true" style="width:30%" />
			<input type="text" name="oat" id="oat" class="easyui-textbox" required="true" style="width:38%" />
		</div>
		<div class="form-item">
			<label for="top">Term Of payment &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; CO From</label><br />
			<input type="text" name="top" id="top" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:49%"/>
		</div>
		<div class="form-item">
			<label for="lokasi">PO# Customer</label><br />
			<input type="text" name="pocust" id="pocust" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="lewat">Jobsite</label><br />
			<input type="text" name="lokasi" id="lokasi" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
		<div class="form-item">
			<label for="lewat">Due Date &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="duedate" id="duedate" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>
		</div>
	</form>
</div>

<!-- Dialog Button -->
<div id="dialog-buttons">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-floppy-o fa-lg" onclick="save()">Simpan</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-form').dialog('close')">Batal</a>
</div>


<!-- Pencetakan ke Printer -->
<div id="dialog-excel" class="easyui-dialog" style="width:500px; height:300px; padding: 10px 20px" closed="true" buttons="#dialog-btn">
	<form id="form-excel" method="post" action="transaksi/inv/cetak.php" target="_blank">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="tgltrans" id="tgltrans" class="easyui-datebox" required="true" style="width:30%"/>
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:69%"/>

		</div>
		<div class="form-item">
			<label for="tgltrans">Customer &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Due Date</label><br />
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="duedate" id="duedate" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="cofrom">CO From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="dialog-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" onclick="$('#form-excel').submit();">Cetak</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-excel').dialog('close')">Batal</a>
</div>

<!-- Pegiriman Invoice ke Customer -->
<div id="dialog-kirim" class="easyui-dialog" style="width:500px; height:300px; padding: 10px 20px" closed="true" buttons="#kirim-btn">
	<form id="form-kirim" method="post">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:49%"/>

		</div>
		<div class="form-item">
			<label for="tglkirim">Ekspedisi &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Tgl Kirim</label><br />
			<input type="text" name="ekspedisi" id="ekspedisi" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="tglkirim" id="tglkirim" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
		<div class="form-item">
			<label for="noresi">No Resi Ekspedisi &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Tgl Terima</label></br>
			<input type="text" name="noresi" id="noresi" class="easyui-textbox" required="true" style="width:69%"/>
			<input type="text" name="tglterima" id="tglterima" class="easyui-datebox" required="true" style="width:30%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="kirim-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" onclick="savekirim();">Cetak</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-kirim').dialog('close')">Batal</a>
</div>

<!-- Download File -->
<div id="dialog-download" class="easyui-dialog" style="width:400px; height:250px; padding: 10px 20px" closed="true" buttons="#download-btn">
	<form id="form-download" method="post" action="transaksi/inv/download.php">
		<div class="form-item">
			<label for="type">No Transaksi</label><br />
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:100%"/>

		</div>
		<div class="form-item">
			<label for="tglkirim">Nama File</label><br />
			<input type="text" name="faktur" id="faktur" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="download-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-save fa-lg" onclick="$('#form-download').submit();">Download</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-download').dialog('close')">Batal</a>
</div>

<!-- Lihat File -->
<div id="dialog-lihat" class="easyui-dialog" style="width:400px; height:250px; padding: 10px 20px" closed="true" buttons="#btn-lihat">
	<form id="form-lihat" method="post" action="transaksi/inv/lihat.php" target="_blank">
		<div class="form-item">
			<label for="type">No Transaksi</label><br />
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:100%"/>

		</div>
		<div class="form-item">
			<label for="tglkirim">Nama File</label><br />
			<input type="text" name="faktur" id="faktur" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="btn-lihat">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-picture-o fa-lg" onclick="$('#form-lihat').submit();">Lihat</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-lihat').dialog('close')">Batal</a>
</div>

<!-- Create Invoice Internal -->
<div id="dialog-intern" class="easyui-dialog" style="width:500px; height:300px; padding: 10px 20px" closed="true" buttons="#intern-btn">
	<form id="form-intern" method="post">
		<div class="form-item">
			<label for="type">Tanggal &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;No Transaksi</label><br />
			<input type="text" name="notrans" id="notrans" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="kodecust" id="kodecust" class="easyui-textbox" required="true" style="width:49%"/>

		</div>
		<div class="form-item">
			<label for="cofrom">Co From &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;To From</label><br />
			<input type="text" name="cofrom" id="cofrom" class="easyui-textbox" required="true" style="width:50%"/>
			<input type="text" name="tofrom" id="tofrom" class="easyui-textbox" required="true" style="width:49%"/>
		</div>
		<div class="form-item">
			<label for="noresi">Fee</label></br>
			<input type="text" name="mfee" id="mfee" class="easyui-textbox" required="true" style="width:100%"/>
		</div>
	</form>
</div>

<!-- Dialog Button Cetak ke Printer -->
<div id="intern-btn">
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-print fa-lg" onclick="saveintern();">Cetak</a>
	<a href="javascript:void(0)" class="easyui-linkbutton" iconCls="fa fa-ban fa-lg" onclick="javascript:jQuery('#dialog-intern').dialog('close')">Batal</a>
</div>
</body>
