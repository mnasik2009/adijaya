<?
$namafile = $_POST['faktur'];
$nama = "temp/".$namafile;
?>
<html>
<head>
	<title>Menampilkan File PDF</title>
</head>
<body>
	<embed type="application/pdf" src="<?php echo $nama;?>" width="800" height="900"></embed>

</body>
</html>
